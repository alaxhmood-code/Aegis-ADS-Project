﻿# ============================================================
# AEGIS-ADS v11.0 - FINAL FIXED VERSION
# ============================================================
import sys, os, time, threading, smtplib, asyncio, psutil, subprocess, json, re, tempfile
from datetime import datetime
from collections import defaultdict
from contextlib import asynccontextmanager
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from fastapi import FastAPI, Request, WebSocket, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn, logging

from core.models_loader import UnifiedModelLoader
from core.orchestrator import get_orchestrator
import config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("AEGIS")

model_loader = UnifiedModelLoader()
orchestrator = get_orchestrator()

# Global Variables
ws_connections = []
alerts = []
logs_storage = []
pcap_packets = []


def add_to_logs(alert):
    log_entry = {
        "id": len(logs_storage) + 1,
        "timestamp": alert.get('time', datetime.now().isoformat()),
        "src_ip": alert.get('src', 'Unknown'),
        "dst_ip": alert.get('dst', '-'),
        "attack_type": alert.get('attack', 'Unknown'),
        "severity": alert.get('severity', 'MEDIUM'),
        "confidence": alert.get('confidence', 0),
        "action": alert.get('action', 'Logged')
    }
    logs_storage.insert(0, log_entry)
    while len(logs_storage) > 500:
        logs_storage.pop()


# FastAPI App
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("AEGIS-ADS v11.0 LIVE")
    orchestrator.set_loop(asyncio.get_event_loop())
    orchestrator.set_model_loader(model_loader)
    orchestrator.start()
    asyncio.create_task(broadcast_loop())
    yield


app = FastAPI(title="AEGIS-ADS v11.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/reports", StaticFiles(directory="reports"), name="reports")
templates = Jinja2Templates(directory="templates")


# WebSocket Broadcast
async def broadcast_loop():
    while True:
        try:
            if ws_connections:
                stats = orchestrator.get_stats()
                data = {
                    "type": "stats",
                    "packets": stats.get("total_packets", 0),
                    "detections": stats.get("detections", 0),
                    "blocks": stats.get("blocks", 0),
                    "alerts": alerts[:15],
                    "logs": logs_storage[:50]
                }
                dead = []
                for ws in ws_connections:
                    try:
                        await ws.send_json(data)
                    except:
                        dead.append(ws)
                for d in dead:
                    if d in ws_connections:
                        ws_connections.remove(d)
        except Exception as e:
            logger.debug(f"Broadcast error: {e}")
        await asyncio.sleep(1)


@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    await ws.accept()
    ws_connections.append(ws)
    try:
        while True:
            await ws.receive_text()
    except:
        pass


# Pages
@app.get("/")
async def login(r: Request): return templates.TemplateResponse("login.html", {"request": r})
@app.get("/dashboard")
async def dashboard(r: Request): return templates.TemplateResponse("dashboard.html", {"request": r})
@app.get("/firewall")
async def firewall(r: Request): return templates.TemplateResponse("firewall.html", {"request": r})
@app.get("/logs")
async def logs_page(r: Request): return templates.TemplateResponse("logs.html", {"request": r})
@app.get("/models")
async def models_page(r: Request): return templates.TemplateResponse("models_new.html", {"request": r})
@app.get("/devices")
async def devices_page(r: Request): return templates.TemplateResponse("devices.html", {"request": r})
@app.get("/pcap")
async def pcap_page(r: Request): return templates.TemplateResponse("pcap.html", {"request": r})
@app.get("/admin")
async def admin_page(r: Request): return templates.TemplateResponse("admin.html", {"request": r})
@app.get("/settings")
async def settings_page(r: Request): return templates.TemplateResponse("settings.html", {"request": r})
@app.get("/reports")
async def reports_page(r: Request): return templates.TemplateResponse("reports.html", {"request": r})
@app.get("/about")
async def about_page(r: Request): return templates.TemplateResponse("about.html", {"request": r})


# ============================================================
# API Endpoints
# ============================================================
@app.post("/api/auth/login")
async def api_login(data: dict):
    if data.get('username') == 'admin' and data.get('password') == '2005':
        return {"access_token": "token", "username": "admin", "role": "admin"}
    raise HTTPException(401)


@app.get("/api/ips/stats")
async def api_ips_stats():
    return orchestrator.get_stats()


@app.get("/api/ips/blocked")
async def api_ips_blocked():
    return {"blocked_ips": orchestrator.get_blocked_ips(), "count": len(orchestrator.get_blocked_ips())}


@app.post("/api/ips/unblock")
async def api_ips_unblock(request: Request):
    data = await request.json()
    ip = data.get("ip")
    success = orchestrator.unblock_ip(ip)
    return {"success": success, "ip": ip}


@app.post("/api/firewall/block")
async def block_ip(request: Request):
    data = await request.json()
    ip = data.get("ip")
    reason = data.get("reason", "Manual block")
    success = orchestrator.block_ip(ip, reason)
    return {"success": success, "message": f"IP {ip} {'blocked' if success else 'failed'}"}


@app.post("/api/firewall/unblock")
async def unblock_ip(request: Request):
    data = await request.json()
    ip = data.get("ip")
    success = orchestrator.unblock_ip(ip)
    return {"success": success, "message": f"IP {ip} {'unblocked' if success else 'not found'}"}


@app.get("/api/firewall/blocked")
async def get_blocked():
    return {"blocked_ips": orchestrator.get_blocked_ips(), "count": len(orchestrator.get_blocked_ips())}


@app.get("/api/dashboard/stats")
async def api_stats():
    stats = orchestrator.get_stats()
    return {"active_threats": stats.get("detections", 0), "packets": stats.get("total_packets", 0)}


@app.get("/api/models/status")
async def api_models():
    return model_loader.get_status()


@app.get("/api/capture/status")
async def api_capture_status():
    stats = orchestrator.get_stats()
    return {"capture_running": stats.get("is_running", False), "packets": stats.get("total_packets", 0), "detections": stats.get("detections", 0)}


@app.post("/api/capture/start")
async def api_capture_start():
    orchestrator.start()
    return {"status": "started"}


@app.post("/api/capture/stop")
async def api_capture_stop():
    orchestrator.stop()
    return {"status": "stopped"}


@app.get("/api/logs")
async def api_logs():
    return {"threats": logs_storage[:100], "total": len(logs_storage)}


@app.get("/health")
async def health():
    return {"status": "ok", "models": model_loader.is_ready, "orchestrator": orchestrator.running}


# ============================================================
# INTERFACE SELECTION API
# ============================================================
selected_interface_name = None


@app.get("/api/interfaces")
async def get_interfaces_list():
    interfaces = []
    try:
        import psutil
        for iface, addrs in psutil.net_if_addrs().items():
            clean_name = iface
            try:
                clean_name = iface.encode('latin-1').decode('utf-8', errors='ignore')
            except:
                pass
            for addr in addrs:
                if addr.family == 2 and addr.address != '127.0.0.1':
                    interfaces.append({
                        "name": clean_name,
                        "ip": addr.address,
                        "is_hotspot": "192.168.137" in addr.address
                    })
                    break
    except Exception as e:
        logger.error(f"Interface list error: {e}")
    
    if not any(i.get('is_hotspot') for i in interfaces):
        interfaces.append({"name": "الاتصال المحلي* 2", "ip": "192.168.137.1", "is_hotspot": True})
    
    return {"interfaces": interfaces, "selected": selected_interface_name}


@app.post("/api/interfaces/select")
async def select_capture_interface(request: Request):
    global selected_interface_name
    try:
        data = await request.json()
        interface_name = data.get("interface")
    except:
        return {"status": "error", "message": "Invalid request"}
    
    if not interface_name:
        return {"status": "error", "message": "No interface provided"}
    
    selected_interface_name = interface_name
    orchestrator.stop()
    success = orchestrator.start(interface_name=interface_name)
    
    return {"status": "success" if success else "error", "interface": interface_name, "message": f"Switched to {interface_name}"}


@app.get("/api/dns/lookup")
async def dns_lookup(ip: str):
    try:
        import socket
        hostname = socket.gethostbyaddr(ip)[0]
        return {"hostname": hostname, "ip": ip}
    except:
        return {"hostname": ip, "ip": ip}


# ============================================================
# DEVICES API - REAL NETWORK DISCOVERY
# ============================================================
from core.network_discovery import get_network_discovery


@app.get("/api/devices")
async def api_devices():
    """Get real network devices using ARP discovery"""
    discovery = get_network_discovery()
    devices = discovery.scan_network()
    return {"devices": devices, "count": len(devices)}


@app.post("/api/devices/scan")
async def api_scan():
    """Force scan network devices"""
    discovery = get_network_discovery()
    devices = discovery.scan_network(force=True)
    return {"devices": devices, "count": len(devices)}


# ============================================================
# FIREWALL API - KERNEL LEVEL BLOCKING
# ============================================================

# تخزين القواعد المحظورة
firewall_rules = []
firewall_rules_lock = threading.Lock()
rule_id_counter = 0


@app.get("/api/firewall/rules")
async def get_firewall_rules():
    """Get all firewall rules"""
    with firewall_rules_lock:
        return {"rules": firewall_rules, "count": len(firewall_rules)}


@app.post("/api/firewall/rules")
async def add_firewall_rule(request: Request):
    """Add a new firewall rule (block IP)"""
    global rule_id_counter
    try:
        data = await request.json()
        src_ip = data.get("src_ip") or data.get("source") or data.get("ip")
        reason = data.get("reason", "Manual block")
        
        if not src_ip:
            return {"status": "error", "message": "No IP provided"}
        
        # حظر IP عبر Kernel
        from core.kernel_shield import add_to_blacklist
        add_to_blacklist(src_ip)
        
        # إضافة القاعدة إلى القائمة
        with firewall_rules_lock:
            rule_id_counter += 1
            rule = {
                "id": rule_id_counter,
                "src_ip": src_ip,
                "action": "BLOCK",
                "reason": reason,
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            firewall_rules.insert(0, rule)
            
            # حذف القواعد القديمة إذا زادت عن 100
            while len(firewall_rules) > 100:
                firewall_rules.pop()
        
        logger.warning(f"[FIREWALL] 🚫 Blocked {src_ip} - {reason}")
        
        # تحديث الإحصائيات
        from core.orchestrator import get_orchestrator
        orchestrator = get_orchestrator()
        orchestrator.block_ip(src_ip, reason)
        
        return {"status": "success", "rule": rule, "message": f"Blocked {src_ip}"}
        
    except Exception as e:
        logger.error(f"Add rule error: {e}")
        return {"status": "error", "message": str(e)}


@app.delete("/api/firewall/rules/{rule_id}")
async def delete_firewall_rule(rule_id: int):
    """Delete a firewall rule (unblock IP)"""
    try:
        with firewall_rules_lock:
            # البحث عن القاعدة
            rule_to_delete = None
            for rule in firewall_rules:
                if rule.get("id") == rule_id:
                    rule_to_delete = rule
                    break
            
            if not rule_to_delete:
                return {"status": "error", "message": "Rule not found"}
            
            # إزالة القاعدة
            firewall_rules.remove(rule_to_delete)
            
            # إلغاء حظر IP عبر Kernel
            from core.kernel_shield import remove_from_blacklist
            remove_from_blacklist(rule_to_delete["src_ip"])
            
            logger.info(f"[FIREWALL] 🔓 Unblocked {rule_to_delete['src_ip']}")
            
            return {"status": "success", "message": f"Unblocked {rule_to_delete['src_ip']}"}
            
    except Exception as e:
        logger.error(f"Delete rule error: {e}")
        return {"status": "error", "message": str(e)}


@app.post("/api/firewall/panic")
async def panic_mode():
    """Emergency panic - block all non-whitelisted IPs"""
    from core.kernel_shield import add_to_blacklist
    from core.network_discovery import get_network_discovery
    
    discovery = get_network_discovery()
    devices = discovery.scan_network()
    
    blocked_count = 0
    for device in devices:
        ip = device.get("ip")
        if ip and ip != "192.168.137.1":
            add_to_blacklist(ip)
            blocked_count += 1
    
    logger.warning(f"[FIREWALL] 🚨 PANIC MODE - Blocked {blocked_count} devices")
    return {"status": "success", "blocked": blocked_count, "message": f"Panic mode activated, blocked {blocked_count} IPs"}


@app.post("/api/firewall/unpanic")
async def unpanic_mode():
    """Clear all blocks"""
    from core.kernel_shield import clear_blacklist
    count = clear_blacklist()
    
    with firewall_rules_lock:
        firewall_rules.clear()
    
    logger.info(f"[FIREWALL] 🔓 Unpanic mode - Cleared {count} blocks")
    return {"status": "success", "cleared": count, "message": f"Cleared {count} blocked IPs"}


# ============================================================
# REPORTS API
# ============================================================

@app.get("/api/reports/list")
async def api_reports_list():
    """Get list of generated reports"""
    files = []
    try:
        reports_dir = "reports"
        if not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        
        for f in os.listdir(reports_dir):
            if f.endswith(".pdf"):
                filepath = os.path.join(reports_dir, f)
                stat = os.path.getmtime(filepath)
                size = os.path.getsize(filepath)
                files.append({
                    "name": f,
                    "date": datetime.fromtimestamp(stat).strftime("%Y-%m-%d %H:%M:%S"),
                    "size": size,
                    "size_kb": round(size / 1024, 1)
                })
        files.sort(key=lambda x: x["date"], reverse=True)
    except Exception as e:
        logger.error(f"Reports list error: {e}")
    
    return {"files": files, "count": len(files)}


@app.post("/api/reports/generate")
async def api_report_generate():
    """Generate professional security report"""
    try:
        from core.orchestrator import get_orchestrator
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.units import inch
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
        from reportlab.lib.enums import TA_CENTER
        
        orchestrator = get_orchestrator()
        stats = orchestrator.get_stats()
        
        attack_counts = stats.get("attack_counts", {})
        if not attack_counts:
            attack_counts = {"No attacks": 0}
        
        os.makedirs("reports", exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"AEGIS_Report_{timestamp}.pdf"
        filepath = os.path.join("reports", filename)
        
        doc = SimpleDocTemplate(filepath, pagesize=landscape(A4))
        styles = getSampleStyleSheet()
        story = []
        
        # Title style
        title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'],
                                     fontSize=24, textColor=colors.HexColor('#00ff9c'),
                                     alignment=TA_CENTER, spaceAfter=20)
        
        # Cover Page
        story.append(Paragraph("🛡️ AEGIS-ADS", title_style))
        story.append(Paragraph("Advanced AI Security Platform", styles['Heading2']))
        story.append(Spacer(1, 0.5*inch))
        story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
        story.append(Paragraph("Developer: Mohammed Bilal", styles['Normal']))
        story.append(PageBreak())
        
        # Executive Summary
        story.append(Paragraph("Executive Summary", styles['Heading2']))
        
        summary_data = [
            ["Metric", "Value"],
            ["Total Packets", f"{stats.get('total_packets', 0):,}"],
            ["Detections", str(stats.get('detections', 0))],
            ["Blocks", str(stats.get('blocks', 0))],
            ["Blocked IPs", str(stats.get('blocked_ips', 0))],
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#00ff9c')),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a237e')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Threats Table
        story.append(Paragraph("Threat Intelligence", styles['Heading2']))
        
        threat_data = [["Time", "Source IP", "Attack Type", "Confidence"]]
        alerts_list = orchestrator.alert_history if hasattr(orchestrator, 'alert_history') else []
        for alert in alerts_list[:20]:
            threat_data.append([
                alert.get('timestamp', '-'),
                alert.get('src_ip', '-'),
                alert.get('attack_type', '-'),
                f"{alert.get('confidence', 0)}%"
            ])
        
        if len(threat_data) == 1:
            threat_data.append(["No threats", "-", "-", "-"])
        
        threat_table = Table(threat_data, colWidths=[1.2*inch, 1.5*inch, 1.8*inch, 1*inch])
        threat_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#ff3b5c')),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#d32f2f')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
        ]))
        story.append(threat_table)
        
        # Footer
        story.append(Spacer(1, 0.5*inch))
        story.append(Paragraph("="*80, styles['Normal']))
        story.append(Paragraph("Generated by AEGIS-ADS v11.0", styles['Normal']))
        story.append(Paragraph("Developer: Mohammed Bilal", styles['Normal']))
        story.append(Paragraph(f"© 2026 All Rights Reserved", styles['Normal']))
        
        doc.build(story)
        
        return {"status": "generated", "file": filename, "path": f"/reports/{filename}"}
        
    except Exception as e:
        logger.error(f"Report generation error: {e}")
        return {"status": "failed", "error": str(e)}


@app.get("/api/reports/download/{filename}")
async def api_report_download(filename: str):
    """Download a report"""
    filepath = os.path.join("reports", filename)
    if os.path.exists(filepath):
        return FileResponse(filepath, media_type="application/pdf", filename=filename)
    return {"status": "error", "message": "File not found"}


@app.delete("/api/reports/delete/{filename}")
async def api_report_delete(filename: str):
    """Delete a report"""
    filepath = os.path.join("reports", filename)
    if os.path.exists(filepath):
        os.remove(filepath)
        return {"status": "deleted", "message": f"Deleted {filename}"}
    return {"status": "error", "message": "File not found"}


@app.post("/api/reports/email")
async def api_reports_email(request: Request):
    """Email a report"""
    try:
        data = await request.json()
        email_to = data.get("email", "alaxhmood@gmail.com")
        report_file = data.get("file", "")
        
        if not report_file:
            return {"status": "error", "message": "No report specified"}
        
        filepath = os.path.join("reports", report_file)
        if not os.path.exists(filepath):
            return {"status": "error", "message": "Report not found"}
        
        EMAIL_CONFIG = {
            "smtp_server": "smtp.gmail.com",
            "smtp_port": 587,
            "username": "alaxhmood@gmail.com",
            "password": "safh xamu psgh rqgb"
        }
        
        msg = MIMEMultipart()
        msg["Subject"] = f"AEGIS-ADS Security Report - {report_file}"
        msg["From"] = EMAIL_CONFIG["username"]
        msg["To"] = email_to
        
        body = f"AEGIS-ADS Security Report\n\nReport: {report_file}\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        msg.attach(MIMEText(body, "plain"))
        
        with open(filepath, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", f"attachment; filename={report_file}")
            msg.attach(part)
        
        with smtplib.SMTP(EMAIL_CONFIG["smtp_server"], EMAIL_CONFIG["smtp_port"]) as s:
            s.starttls()
            s.login(EMAIL_CONFIG["username"], EMAIL_CONFIG["password"])
            s.send_message(msg)
        
        return {"status": "sent", "email": email_to, "message": f"Report sent to {email_to}"}
        
    except Exception as e:
        logger.error(f"Email error: {e}")
        return {"status": "failed", "error": str(e)}


# ============================================================
# MAIN ENTRY POINT
# ============================================================

# ============================================================
# PROFESSIONAL REPORTS API
# ============================================================
from core.report_engine import get_report_engine

@app.post("/api/reports/generate")
async def api_report_generate(request: Request):
    """Generate professional security report"""
    try:
        data = await request.json()
        report_type = data.get("type", "executive")
        from_date = data.get("from_date")
        to_date = data.get("to_date")
        include_charts = data.get("include_charts", True)
        include_ai = data.get("include_ai", True)
        
        from core.orchestrator import get_orchestrator
        orchestrator = get_orchestrator()
        report_engine = get_report_engine(orchestrator)
        
        result = report_engine.generate_executive_report(report_type)
        
        return {"status": "generated", "file": result["file"], "path": result["path"]}
        
    except Exception as e:
        logger.error(f"Report generation error: {e}")
        return {"status": "failed", "error": str(e)}


    print("=" * 60)
    print("  🛡️ AEGIS-ADS v11.0 - FINAL VERSION")
    print("=" * 60)
    print("  🌐 http://localhost:9999 | admin/2005")
    print("  📡 Capture Engine: WinDivert")
    print("  🧠 ML Engine: XGBoost + DL")
    print("  ⛔ Blocking: Kernel Level")
    print("=" * 60)
    uvicorn.run("main:app", host="0.0.0.0", port=9999, reload=False)
