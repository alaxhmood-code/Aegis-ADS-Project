﻿"""
core/orchestrator.py - Complete orchestrator with chart data
"""

import threading
import logging
import time
from core.capture_engine import CaptureEngine
from core.flow_builder import FlowBuilder
from core.cicids_feature_extractor import get_cicids_extractor
from core.xgboost_detector import get_xgb_detector
from core.real_deep_learning import get_deep_learning
from core.kernel_shield import add_to_blacklist, get_blacklist
from core.async_ai_queue import get_ai_queue

logger = logging.getLogger(__name__)


class Orchestrator:
    _instance = None
    
    WHITELIST_IPS = {"127.0.0.1", "192.168.137.1", "8.8.8.8", "8.8.4.4", "1.1.1.1"}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        
        self.capture = CaptureEngine()
        self.flow_builder = FlowBuilder()
        self.feature_extractor = None
        self.xgb_detector = None
        self.deep_learning = None
        self.ai_queue = None
        self.model_loader = None
        
        self.main_loop = None
        self.running = False
        
        self.packet_count = 0
        self.flow_count = 0
        self.detection_count = 0
        self.block_count = 0
        
        # ✅ Attack tracking for charts
        self.attack_counts = {}
        self.alert_history = []
        self.max_alerts = 20
        self.timeline_data = []  # Store timeline points
        
        self.flow_builder.set_ai_callback(self._on_ai_flow)
    
    def set_loop(self, loop):
        self.main_loop = loop
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        self.feature_extractor = get_cicids_extractor()
        self.xgb_detector = get_xgb_detector(model_loader, self.feature_extractor)
        self.deep_learning = get_deep_learning(model_loader)
        self.ai_queue = get_ai_queue()
        self.ai_queue.start()
        self.ai_queue.set_callback(self._on_ai_result)
        logger.info("✅ AI Pipeline initialized")
    
    def _on_packet(self, packet, src_ip, dst_ip, size, is_icmp):
        try:
            self.packet_count += 1
            src_port = 0
            dst_port = 0
            protocol = 0
            is_syn = is_ack = is_rst = is_fin = False
            
            if hasattr(packet, 'tcp') and packet.tcp:
                protocol = 6
                src_port, dst_port = packet.src_port, packet.dst_port
                is_syn, is_ack, is_rst, is_fin = packet.tcp.syn, packet.tcp.ack, packet.tcp.rst, packet.tcp.fin
            elif hasattr(packet, 'udp') and packet.udp:
                protocol = 17
                src_port, dst_port = packet.src_port, packet.dst_port
            elif is_icmp:
                protocol = 1
            
            self.flow_builder.process_packet(
                src_ip, dst_ip, src_port, dst_port, protocol, size,
                is_icmp, is_syn, is_ack, is_rst, is_fin
            )
        except Exception as e:
            logger.error(f"_on_packet error: {e}")
    
    def _on_ai_flow(self, src_ip, dst_ip, features_10, flow_stats):
        self.flow_count += 1
        self._broadcast_stats()
        
        if src_ip in self.WHITELIST_IPS:
            return
        if src_ip == "192.168.137.1":
            return
        if src_ip in get_blacklist():
            return
        
        task = {'src_ip': src_ip, 'dst_ip': dst_ip, 'flow_stats': flow_stats,
                'xgb_detector': self.xgb_detector, 'deep_learning': self.deep_learning}
        self.ai_queue.submit(task)
    
    def _on_ai_result(self, result):
        if not result:
            return
        
        src_ip = result['src_ip']
        detection = result.get('detection')
        
        if detection and detection.get('is_attack', False):
            self.detection_count += 1
            
            attack_type = detection.get('attack_type', 'Unknown')
            confidence = detection.get('confidence', 0)
            should_block = detection.get('should_block', False)
            
            # ✅ Record attack for pie chart
            self.attack_counts[attack_type] = self.attack_counts.get(attack_type, 0) + 1
            
            # ✅ Add to timeline
            now = time.strftime("%H:%M:%S")
            self.timeline_data.append({"time": now, "count": 1})
            if len(self.timeline_data) > 20:
                self.timeline_data.pop(0)
            
            if should_block:
                self.block_count += 1
                add_to_blacklist(src_ip)
                logger.warning(f"🚨 BLOCKED: {src_ip} - {attack_type} ({confidence:.1f}%)")
            
            # ✅ Store alert for feed
            alert = {
                "type": "alert",
                "timestamp": now,
                "src_ip": src_ip,
                "dst_ip": result.get('dst_ip', ''),
                "attack_type": attack_type,
                "confidence": confidence,
                "severity": "CRITICAL"
            }
            self.alert_history.insert(0, alert)
            if len(self.alert_history) > self.max_alerts:
                self.alert_history.pop()
            
            # ✅ Send alert immediately
            self._send_alert(alert)
        
        # ✅ Always send updated stats
        self._broadcast_stats()
    
    def _send_alert(self, alert):
        """Send alert via WebSocket"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            
            import asyncio
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def _broadcast_stats(self):
        """Send complete stats with chart data"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            # Prepare data for charts
            attack_labels = list(self.attack_counts.keys())
            attack_data = list(self.attack_counts.values())
            
            timeline_labels = [t["time"] for t in self.timeline_data]
            timeline_values = [t["count"] for t in self.timeline_data]
            
            data = {
                "type": "stats",
                "packets": self.packet_count,
                "detections": self.detection_count,
                "blocks": self.block_count,
                "flows": self.flow_count,
                "active_flows": self.flow_count,
                "blocked_ips": len(get_blacklist()),
                # ✅ Chart data
                "attack_labels": attack_labels,
                "attack_data": attack_data,
                "timeline_labels": timeline_labels,
                "timeline_data": timeline_values,
                "alerts": self.alert_history[:10],
                "is_running": self.running
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        if ws in ws_connections:
                            ws_connections.remove(ws)
            
            import asyncio
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except Exception as e:
            logger.debug(f"Broadcast error: {e}")
    
    def start(self, interface_name=None):
        if self.running:
            return True
        
        self.capture.set_callback(self._on_packet)
        result = self.capture.start(interface_name)
        
        if result:
            self.running = True
            logger.warning("🛡️ Orchestrator ACTIVE")
        
        return result
    
    def stop(self):
        self.running = False
        if self.ai_queue:
            self.ai_queue.stop()
        self.capture.stop()
        logger.info("Orchestrator stopped")
    
    def block_ip(self, ip, reason="Manual"):
        add_to_blacklist(ip)
        self.detection_count += 1
        self.block_count += 1
        logger.warning(f"✅ [MANUAL BLOCK] {ip}")
        self._broadcast_stats()
        return True
    
    def unblock_ip(self, ip):
        from core.kernel_shield import remove_from_blacklist
        remove_from_blacklist(ip)
        return True
    
    def get_blocked_ips(self):
        return get_blacklist()
    
    def get_stats(self):
        return {
            "total_packets": self.packet_count,
            "detections": self.detection_count,
            "blocks": self.block_count,
            "active_flows": self.flow_count,
            "blocked_ips": len(get_blacklist()),
            "is_running": self.running,
            "attack_counts": self.attack_counts
        }


def get_orchestrator():
    return Orchestrator()
