﻿"""
core/capture_engine.py - Packet capture with IMMEDIATE Kernel Drop
"""

import threading
import time
import logging
import pydivert
from core.kernel_shield import is_blocked

logger = logging.getLogger(__name__)


class CaptureEngine:
    def __init__(self):
        self.running = False
        self.windivert = None
        self.callback = None
        self.packet_count = 0
    
    def _is_local_ip(self, ip):
        if not ip:
            return False
        return ip.startswith('192.168.137.')
    
    def set_callback(self, callback):
        self.callback = callback
    
    def start(self, interface_name=None):
        if self.running:
            return True
        
        try:
            filter_str = "ip and not loopback"
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            self.running = True
            threading.Thread(target=self._capture_loop, daemon=True).start()
            
            logger.warning("📡 Capture Engine ACTIVE (IMMEDIATE Kernel Drop)")
            return True
        except Exception as e:
            logger.error(f"Capture start failed: {e}")
            return False
    
    def _capture_loop(self):
        while self.running:
            try:
                packet = self.windivert.recv()
                if not packet:
                    continue
                
                src_ip = packet.src_addr
                dst_ip = packet.dst_addr
                
                # ✅ IMMEDIATE KERNEL DROP - No delay
                if is_blocked(src_ip) or is_blocked(dst_ip):
                    # Drop packet immediately - don't even log
                    continue
                
                # Only analyze local traffic
                if not self._is_local_ip(src_ip) and not self._is_local_ip(dst_ip):
                    self.windivert.send(packet)
                    continue
                
                self.packet_count += 1
                packet_size = len(packet.raw)
                is_icmp = hasattr(packet, 'icmp') and packet.icmp
                
                if self.callback:
                    self.callback(packet, src_ip, dst_ip, packet_size, is_icmp)
                
                # Send packet if not blocked
                self.windivert.send(packet)
                
            except OSError as e:
                if hasattr(e, 'winerror') and e.winerror == 995:
                    break
                logger.error(f"Capture error: {e}")
            except Exception as e:
                logger.error(f"Unexpected error: {e}")
    
    def stop(self):
        self.running = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("Capture Engine stopped")
