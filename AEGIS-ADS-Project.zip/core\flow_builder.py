﻿"""
core/flow_builder.py - Flow builder with professional settings
"""

import time
import logging

logger = logging.getLogger(__name__)


class FlowBuilder:
    def __init__(self):
        self.flows = {}
        self.ai_callback = None
        self.min_packets = 25  # Increased from 5
        self.flow_timeout = 10  # seconds
        self.processed_flows = {}
        self.flow_cache_timeout = 10

    def set_ai_callback(self, callback):
        self.ai_callback = callback

    def _flow_key(self, src_ip, dst_ip, src_port, dst_port, protocol):
        return f"{src_ip}:{src_port}-{dst_ip}:{dst_port}-{protocol}"
    
    def _is_flow_processed(self, flow_key):
        now = time.time()
        if flow_key in self.processed_flows:
            old_keys = [k for k, t in self.processed_flows.items() if now - t > self.flow_cache_timeout]
            for k in old_keys:
                del self.processed_flows[k]
            return True
        self.processed_flows[flow_key] = now
        return False

    def process_packet(self, src_ip, dst_ip, src_port, dst_port, protocol,
                       packet_size, is_icmp=False, is_syn=False, is_ack=False,
                       is_rst=False, is_fin=False):
        now = time.time()
        key = self._flow_key(src_ip, dst_ip, src_port, dst_port, protocol)

        if key not in self.flows:
            self.flows[key] = {
                'src_ip': src_ip, 'dst_ip': dst_ip,
                'src_port': src_port, 'dst_port': dst_port, 'protocol': protocol,
                'start_time': now, 'last_seen': now,
                'packets': 0, 'bytes': 0,
                'fwd_packets': 0, 'fwd_bytes': 0, 'fwd_packet_sizes': [],
                'syn_count': 0, 'ack_count': 0, 'rst_count': 0, 'fin_count': 0,
                'icmp_count': 0, 'iat_times': []
            }

        flow = self.flows[key]
        iat = (now - flow['last_seen']) * 1000
        flow['iat_times'].append(iat)
        flow['last_seen'] = now
        flow['packets'] += 1
        flow['bytes'] += packet_size
        flow['fwd_packets'] += 1
        flow['fwd_bytes'] += packet_size
        flow['fwd_packet_sizes'].append(packet_size)
        
        if is_syn:
            flow['syn_count'] += 1
        if is_ack:
            flow['ack_count'] += 1
        if is_rst:
            flow['rst_count'] += 1
        if is_fin:
            flow['fin_count'] += 1
        if is_icmp:
            flow['icmp_count'] += 1

        flow['duration_ms'] = int((now - flow['start_time']) * 1000)

        # Trigger AI only after enough packets
        if flow['packets'] >= self.min_packets:
            flow_key = self._flow_key(flow['src_ip'], flow['dst_ip'], 
                                      flow['src_port'], flow['dst_port'], flow['protocol'])
            
            if not self._is_flow_processed(flow_key) and self.ai_callback:
                logger.info(f"[FLOW BUILDER] Flow ready: {flow['src_ip']} -> {flow['dst_ip']} Packets={flow['packets']}")
                self.ai_callback(flow['src_ip'], flow['dst_ip'], {}, flow.copy())
            
            del self.flows[key]

    def cleanup_old_flows(self):
        now = time.time()
        old_keys = [k for k, f in self.flows.items() if now - f['last_seen'] > self.flow_timeout]
        for k in old_keys:
            del self.flows[k]
        return len(old_keys)
