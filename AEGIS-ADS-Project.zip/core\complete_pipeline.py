﻿"""
core/complete_pipeline.py - Complete AEGIS-ADS Pipeline
NFStream → XGBoost → Decision Engine → Kernel Block
"""

import logging
import threading
import time

from core.flow_engine import get_flow_engine
from core.xgboost_detector import get_xgb_detector
from core.decision_engine import get_decision_engine

logger = logging.getLogger(__name__)

# Global stats
packet_count = 0
detection_count = 0
block_count = 0
flow_count = 0

# WebSocket callback
ws_callback = None
main_loop = None


class CompletePipeline:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self.running = False
        self.flow_engine = None
        self.xgb_detector = None
        self.decision_engine = None
    
    def set_loop(self, loop):
        global main_loop
        main_loop = loop
    
    def set_ws_callback(self, callback):
        global ws_callback
        ws_callback = callback
    
    def start(self, interface_name):
        global packet_count, detection_count, block_count, flow_count
        
        if self.running:
            return True
        
        try:
            logger.info("=" * 60)
            logger.info("🔥 AEGIS-ADS COMPLETE PIPELINE STARTING")
            logger.info("=" * 60)
            
            # Initialize components
            self.flow_engine = get_flow_engine()
            self.xgb_detector = get_xgb_detector()
            self.decision_engine = get_decision_engine()
            
            # Set callback
            self.flow_engine.set_flow_callback(self._on_flow)
            
            # Start flow engine
            self.flow_engine.start(interface_name)
            
            self.running = True
            
            # Start stats broadcast
            threading.Thread(target=self._stats_loop, daemon=True).start()
            
            logger.warning("✅ COMPLETE PIPELINE ACTIVE")
            logger.info("   Flow Engine: RUNNING")
            logger.info("   XGBoost Detector: READY")
            logger.info("   Decision Engine: READY")
            logger.info("=" * 60)
            
            return True
            
        except Exception as e:
            logger.error(f"Pipeline start failed: {e}")
            return False
    
    def _on_flow(self, features):
        """Called when a flow is received"""
        global detection_count, block_count, flow_count
        
        try:
            flow_count += 1
            
            src_ip = features.get('src_ip', '')
            dst_ip = features.get('dst_ip', '')
            
            # Skip local traffic
            if src_ip.startswith('127.') or dst_ip.startswith('127.'):
                return
            
            # Check if already blocked
            if self.decision_engine.is_blocked(src_ip):
                return
            
            # Run XGBoost detection
            detection = self.xgb_detector.predict(features)
            
            if detection and detection.get('is_attack'):
                detection_count += 1
                
                # Make decision
                decision = self.decision_engine.decide(src_ip, dst_ip, detection)
                
                if decision['action'] == 'block':
                    block_count += 1
                    self.decision_engine.block_ip(src_ip, decision['reason'])
                    logger.warning(f"🚨 BLOCKED: {src_ip} - {detection.get('attack_type', 'Unknown')}")
                    self._broadcast_alert(src_ip, dst_ip, detection)
            
            # Broadcast stats every 10 flows
            if flow_count % 10 == 0:
                self._broadcast_stats()
                
        except Exception as e:
            logger.error(f"Flow callback error: {e}")
    
    def _broadcast_stats(self):
        global packet_count, detection_count, block_count, flow_count
        
        if ws_callback:
            try:
                ws_callback({
                    "type": "stats",
                    "packets": packet_count,
                    "detections": detection_count,
                    "blocks": block_count,
                    "flows": flow_count,
                    "blocked_ips": self.decision_engine.get_blocked_ips()
                })
            except:
                pass
    
    def _broadcast_alert(self, src_ip, dst_ip, detection):
        if ws_callback:
            try:
                ws_callback({
                    "type": "alert",
                    "timestamp": time.strftime("%H:%M:%S"),
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "attack_type": detection.get('attack_type', 'Unknown'),
                    "confidence": detection.get('confidence', 0),
                    "severity": "CRITICAL"
                })
            except:
                pass
    
    def _stats_loop(self):
        while self.running:
            time.sleep(1)
            self._broadcast_stats()
    
    def stop(self):
        self.running = False
        if self.flow_engine:
            self.flow_engine.stop()
        logger.info("🛑 Pipeline stopped")
    
    def block_ip(self, ip, reason="Manual"):
        return self.decision_engine.block_ip(ip, reason)
    
    def unblock_ip(self, ip):
        return self.decision_engine.unblock_ip(ip)
    
    def get_blocked_ips(self):
        return self.decision_engine.get_blocked_ips()
    
    def get_stats(self):
        global packet_count, detection_count, block_count, flow_count
        return {
            "total_packets": packet_count,
            "detections": detection_count,
            "blocks": block_count,
            "active_flows": flow_count,
            "blocked_ips": len(self.decision_engine.get_blocked_ips()),
            "is_running": self.running
        }


_pipeline = None

def get_pipeline():
    global _pipeline
    if _pipeline is None:
        _pipeline = CompletePipeline()
    return _pipeline
