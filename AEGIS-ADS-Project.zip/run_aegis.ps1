﻿# run_aegis.ps1 - تشغيل AEGIS-ADS مع صلاحيات كاملة
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  🛡️ AEGIS-ADS v11.0 - تشغيل مع صلاحيات مسؤول" -ForegroundColor White
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# التحقق من الصلاحيات
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "⚠️ يرجى تشغيل PowerShell كمسؤول!" -ForegroundColor Red
    Write-Host "🔄 أعد التشغيل كمسؤول" -ForegroundColor Yellow
    pause
    exit
}

Write-Host "✅ صلاحيات المسؤول مؤكدة" -ForegroundColor Green
Write-Host "✅ Windows Firewall: جاهز" -ForegroundColor Green
Write-Host ""

cd "C:\Users\ComputerWorld\PycharmProjects\AEGIS-ADS-v11-FastAPI pro\AEGIS-ADS-v11-FastAPI"

# إنشاء threshold.pkl
python -c "import joblib; joblib.dump(0.75, 'models/threshold.pkl')" 2>$null

# تشغيل السيرفر
Write-Host "🚀 تشغيل AEGIS-ADS..." -ForegroundColor Cyan
Write-Host "🌐 http://localhost:9999 | admin/2005" -ForegroundColor White
Write-Host ""

uvicorn main:app --host 0.0.0.0 --port 9999
