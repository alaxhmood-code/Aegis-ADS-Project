﻿"""
test_models_full.py - اختبار شامل لجميع نماذج AEGIS-ADS
"""

import sys
import os
import numpy as np

sys.path.insert(0, os.getcwd())

print("="*70)
print("🛡️ AEGIS-ADS - Full Model Test")
print("="*70)

try:
    from core.models_loader import UnifiedModelLoader
    
    # إنشاء كائن loader
    print("\n📦 Creating UnifiedModelLoader...")
    loader = UnifiedModelLoader(models_dir='models')
    
    # عرض حالة النماذج
    print("\n📊 Model Status:")
    print(f"   ├─ Random Forest (L1): {'✅ ACTIVE' if loader.rf_model else '❌ INACTIVE'}")
    print(f"   ├─ XGBoost (L2): {'✅ ACTIVE' if loader.xgb_model else '❌ INACTIVE'}")
    print(f"   ├─ Deep Learning (L3): {'✅ ACTIVE' if loader.dl_model else '❌ INACTIVE'}")
    print(f"   ├─ AEGIS Scaler (78): {'✅' if loader.aegis_scaler else '❌'}")
    print(f"   ├─ MinMax Scaler (10): {'✅' if loader.minmax_scaler else '❌'}")
    print(f"   ├─ Label Encoder: {'✅' if loader.label_encoder else '❌'}")
    print(f"   └─ Threshold: {loader.threshold}")
    
    # عرض الميزات
    if loader.feature_names:
        print(f"\n📋 Features: {len(loader.feature_names)} features loaded")
        print(f"   First 5: {loader.feature_names[:5]}")
    
    # عرض أنواع الهجمات
    if loader.attack_types:
        print(f"\n🎯 Attack Types: {len(loader.attack_types)} types")
        attack_list = list(loader.attack_types.keys()) if isinstance(loader.attack_types, dict) else list(loader.attack_types)
        print(f"   Sample: {attack_list[:5]}")
    
    # اختبار التنبؤ بميزات وهمية
    print("\n🧪 Testing prediction with dummy features...")
    
    # ميزات وهمية (10 ميزات لـ XGBoost)
    dummy_features_10 = np.random.randn(1, 10).astype(np.float32)
    
    if loader.xgb_model and loader.minmax_scaler:
        try:
            # تطبيع
            scaled = loader.minmax_scaler.transform(dummy_features_10)
            # تنبؤ
            pred = loader.xgb_model.predict(scaled)[0]
            
            # الحصول على اسم الهجوم
            attack_name = "UNKNOWN"
            if loader.label_encoder:
                try:
                    attack_name = loader.label_encoder.inverse_transform([pred])[0]
                except:
                    attack_name = f"Class_{pred}"
            
            print(f"   ✅ XGBoost prediction successful!")
            print(f"      Predicted class: {pred} ({attack_name})")
        except Exception as e:
            print(f"   ⚠️ XGBoost prediction error: {e}")
    else:
        print("   ⚠️ XGBoost model not available for testing")
    
    print("\n" + "="*70)
    print("✅ All models loaded successfully!")
    print("="*70)
    
except ImportError as e:
    print(f"❌ Import error: {e}")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
