﻿# Release Notes - AEGIS-ADS v11.0

## 🎯 الإصدار الأول (Initial Release)

### ✅ الميزات المكتملة

#### طبقة الالتقاط (Capture Layer)
- [x] Npcap integration for packet capture
- [x] Fragment reassembly (Nmap -f bypass)
- [x] TCP state tracking (SYN/ACK/FIN/RST)
- [x] Direction-aware flow separation

#### طبقة استخراج الميزات (Feature Extraction)
- [x] 78 CICIDS2017-compatible features
- [x] NFStream integration
- [x] Real-time flow analysis

#### طبقة النماذج (ML/DL Models)
- [x] XGBoost (10 features, 15 classes)
- [x] Random Forest (78 features) - Backup
- [x] DistilBERT deep learning (requires download)
- [x] UnifiedModelLoader for all models

#### طبقة اتخاذ القرار (Decision Layer)
- [x] Multi-factor risk scoring (4 factors)
- [x] Async AI queue with worker pool
- [x] Configurable threshold (default: 0.75)

#### طبقة الحظر (Blocking Layer)
- [x] WinDivert integration (kernel-level)
- [x] Windows Firewall management
- [x] IP blacklisting with auto-expiry

#### واجهة المستخدم (Web Interface)
- [x] FastAPI backend
- [x] WebSocket for real-time alerts
- [x] Dashboard with live statistics
- [x] Firewall rules management

### 📦 النماذج (تحميل منفصل)

| الملف | الحجم | الرابط |
|-------|-------|--------|
| model.safetensors | 255 MB | [Google Drive] |
| xgb_classifier.pkl | 3.76 MB | [Google Drive] |
| xgb_classifier.json | 3.21 MB | [Google Drive] |

### 🚀 خطوات التشغيل

1. استنساخ المستودع
2. تحميل النماذج الكبيرة
3. تثبيت Npcap
4. تشغيل `python main.py`

### 📞 الدعم

للاستفسارات: alaxhmood@gmail.com
