﻿"""
core/cic_flow_monitor.py - CICFlowMeter Live Monitor (FIXED)
"""

import threading
import asyncio
import logging
import time
import subprocess
import os
import numpy as np
from datetime import datetime

logger = logging.getLogger(__name__)


class CICFlowMonitor:
    def __init__(self):
        self.running = False
        self.main_loop = None
        self.model_loader = None
        self.process = None
        self.csv_path = "cic_flows.csv"
        self.last_position = 0
        self.blocked_ips = set()
        self.flows_processed = 0
        self.detections = 0
        self.blocks = 0
        self.interface_index = None
        self.csv_header = None
        self._stop_event = threading.Event()
    
    def set_loop(self, loop):
        self.main_loop = loop
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected to CICFlowMonitor")
    
    def _get_hotspot_interface_index(self):
        """Find Hotspot interface index"""
        try:
            result = subprocess.run(['tshark', '-D'], capture_output=True, text=True, encoding='utf-8', errors='ignore')
            for line in result.stdout.split('\n'):
                if '192.168.137.1' in line or 'الاتصال المحلي* 2' in line:
                    parts = line.split('.')
                    if parts and parts[0].isdigit():
                        idx = int(parts[0])
                        logger.info(f"✅ Found Hotspot interface: {idx}")
                        return idx
        except Exception as e:
            logger.error(f"Interface detection error: {e}")
        
        # Default to index 4
        logger.info("Using default interface index: 4")
        return 4
    
    def start(self, interface_name=None):
        if self.running:
            return True
        
        try:
            # Find interface
            self.interface_index = self._get_hotspot_interface_index()
            logger.info(f"Using interface index: {self.interface_index}")
            
            # Start CICFlowMeter
            cmd = ['cicflowmeter', '-i', str(self.interface_index), '-c', self.csv_path]
            logger.info(f"Starting: {' '.join(cmd)}")
            
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='ignore'
            )
            
            self.running = True
            self._stop_event.clear()
            
            # Start CSV watcher
            threading.Thread(target=self._watch_csv, daemon=True).start()
            
            logger.warning("🛡️ CICFlowMonitor ACTIVE")
            return True
        except Exception as e:
            logger.error(f"Start failed: {e}")
            return False
    
    def _watch_csv(self):
        """Watch CSV file for new lines"""
        logger.info("📡 Watching CSV for new flows...")
        
        # Wait for CSV file to be created
        wait_count = 0
        while self.running and not os.path.exists(self.csv_path) and wait_count < 30:
            time.sleep(1)
            wait_count += 1
        
        if not self.running:
            return
        
        logger.info(f"✅ CSV file found: {self.csv_path}")
        
        # Read existing content
        try:
            with open(self.csv_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                if lines:
                    self.csv_header = lines[0].strip().split(',')
                    self.last_position = len(''.join(lines))
                    logger.info(f"CSV header found, {len(lines)-1} existing lines")
        except Exception as e:
            logger.debug(f"Initial read error: {e}")
            self.last_position = 0
        
        while self.running and not self._stop_event.is_set():
            try:
                if os.path.exists(self.csv_path):
                    with open(self.csv_path, 'r', encoding='utf-8', errors='ignore') as f:
                        f.seek(self.last_position)
                        new_lines = f.readlines()
                        self.last_position = f.tell()
                        
                        for line in new_lines:
                            if line.strip() and not line.startswith('Flow ID'):
                                self._process_line(line)
            except Exception as e:
                logger.debug(f"CSV read error: {e}")
            
            time.sleep(1)
    
    def _process_line(self, line):
        try:
            parts = line.strip().split(',')
            if len(parts) < 10:
                return
            
            # Extract source IP (try different positions)
            src_ip = None
            for idx in [1, 2, 3]:
                if idx < len(parts):
                    ip = parts[idx].strip('"')
                    if '.' in ip and len(ip.split('.')) == 4:
                        if ip.startswith('192.168.137'):
                            src_ip = ip
                            break
            
            if not src_ip or src_ip in self.blocked_ips:
                return
            
            self.flows_processed += 1
            
            # Extract features
            def safe_float(idx):
                try:
                    if idx < len(parts):
                        return float(parts[idx].strip('"'))
                    return 0.0
                except:
                    return 0.0
            
            features = np.array([[
                safe_float(7),   # Flow Duration
                safe_float(8),   # Total Fwd Packets
                safe_float(10),  # Total Length of Fwd Packets
                safe_float(14),  # Fwd Packet Length Mean
                safe_float(18),  # Bwd Packet Length Mean
                safe_float(20),  # Flow Bytes/s
                safe_float(21),  # Flow Packets/s
                safe_float(47),  # SYN Flag Count
                safe_float(48),  # ACK Flag Count
                safe_float(55),  # Average Packet Size
            ]], dtype=np.float32)
            
            self._run_ai(src_ip, features)
            
            if self.flows_processed % 10 == 0:
                logger.info(f"[CIC] Processed {self.flows_processed} flows, {self.detections} detections")
                self._broadcast_stats()
                
        except Exception as e:
            logger.debug(f"Process error: {e}")
    
    def _run_ai(self, src_ip, features):
        if not self.model_loader:
            return
        try:
            if self.model_loader.minmax_scaler:
                features = self.model_loader.minmax_scaler.transform(features)
            
            result = self.model_loader.predict_l2(features)
            
            if isinstance(result, dict):
                attack = result.get('attack_type', 'Normal')
                conf = result.get('confidence', 0)
                is_attack = attack.upper() not in ['NORMAL', 'BENIGN'] and conf > 60
            else:
                is_attack = False
            
            if is_attack:
                self.detections += 1
                self.blocks += 1
                self.blocked_ips.add(src_ip)
                logger.warning(f"🚨 AI BLOCKED: {src_ip} -> {attack} ({conf:.1f}%)")
                self._broadcast_alert(src_ip, attack, conf)
                self._broadcast_stats()
        except Exception as e:
            logger.debug(f"AI error: {e}")
    
    def _broadcast_stats(self):
        if not self.main_loop:
            return
        try:
            from main import ws_connections
            data = {
                "type": "stats",
                "packets": self.flows_processed * 10,
                "detections": self.detections,
                "blocks": self.blocks,
                "flows": self.flows_processed
            }
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        pass
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def _broadcast_alert(self, src_ip, attack_type, confidence):
        if not self.main_loop:
            return
        try:
            from main import ws_connections
            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "attack_type": attack_type,
                "confidence": confidence,
                "severity": "CRITICAL"
            }
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def stop(self):
        self.running = False
        self._stop_event.set()
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except:
                self.process.kill()
        logger.info("🛑 CICFlowMonitor Stopped")
    
    def block_ip(self, ip, reason="Manual"):
        if ip and ip not in self.blocked_ips and ip not in ["undefined", "-", "None", ""]:
            self.blocked_ips.add(ip)
            self.detections += 1
            self.blocks += 1
            logger.warning(f"✅ [MANUAL BLOCK] {ip}")
            self._broadcast_stats()
            return True
        return False
    
    def unblock_ip(self, ip):
        if ip in self.blocked_ips:
            self.blocked_ips.discard(ip)
            return True
        return False
    
    def get_blocked_ips(self):
        return list(self.blocked_ips)
    
    def get_stats(self):
        return {
            "total_packets": self.flows_processed * 10,
            "detections": self.detections,
            "blocks": self.blocks,
            "blocked_ips": len(self.blocked_ips),
            "active_flows": self.flows_processed,
            "is_running": self.running
        }


def get_monitor():
    return CICFlowMonitor()
