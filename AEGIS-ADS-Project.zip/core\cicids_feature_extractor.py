﻿"""
core/cicids_feature_extractor.py - 10 features matching XGBoost model
"""

import numpy as np
import pandas as pd
import joblib
import logging

logger = logging.getLogger(__name__)

# Load feature names from features.pkl (first 10 only)
try:
    ALL_FEATURES = joblib.load('models/features.pkl')
    FEATURE_NAMES = ALL_FEATURES[:10]
    logger.info(f"✅ Loaded {len(FEATURE_NAMES)} feature names")
except Exception as e:
    logger.error(f"Failed to load features.pkl: {e}")
    FEATURE_NAMES = [
        'Destination Port', 'Flow Duration', 'Total Fwd Packets', 'Total Backward Packets',
        'Total Length of Fwd Packets', 'Total Length of Bwd Packets', 'Fwd Packet Length Max',
        'Fwd Packet Length Min', 'Fwd Packet Length Mean', 'Fwd Packet Length Std'
    ]


class CICIDSFeatureExtractor:
    def __init__(self):
        self.feature_names = FEATURE_NAMES
        self.num_features = len(self.feature_names)
        logger.info(f"✅ Feature Extractor initialized with {self.num_features} features")

    def extract_from_flow(self, flow_stats):
        features = {}

        # 1. Destination Port
        features['Destination Port'] = flow_stats.get('dst_port', 0)

        # 2. Flow Duration (ms)
        features['Flow Duration'] = flow_stats.get('duration_ms', 0)

        # 3. Total Fwd Packets
        features['Total Fwd Packets'] = flow_stats.get('fwd_packets', 0)

        # 4. Total Backward Packets
        features['Total Backward Packets'] = flow_stats.get('bwd_packets', 0)

        # 5. Total Length of Fwd Packets
        features['Total Length of Fwd Packets'] = flow_stats.get('fwd_bytes', 0)

        # 6. Total Length of Bwd Packets
        features['Total Length of Bwd Packets'] = flow_stats.get('bwd_bytes', 0)

        # 7. Fwd Packet Length Max
        fwd_sizes = flow_stats.get('fwd_packet_sizes', [])
        features['Fwd Packet Length Max'] = max(fwd_sizes) if fwd_sizes else 0

        # 8. Fwd Packet Length Min
        features['Fwd Packet Length Min'] = min(fwd_sizes) if fwd_sizes else 0

        # 9. Fwd Packet Length Mean
        features['Fwd Packet Length Mean'] = sum(fwd_sizes) / len(fwd_sizes) if fwd_sizes else 0

        # 10. Fwd Packet Length Std
        if len(fwd_sizes) > 1:
            mean = features['Fwd Packet Length Mean']
            variance = sum((x - mean) ** 2 for x in fwd_sizes) / len(fwd_sizes)
            features['Fwd Packet Length Std'] = variance ** 0.5
        else:
            features['Fwd Packet Length Std'] = 0

        df = pd.DataFrame([features])
        df = df[self.feature_names]

        return df

    def get_feature_names(self):
        return self.feature_names


def get_cicids_extractor():
    return CICIDSFeatureExtractor()
