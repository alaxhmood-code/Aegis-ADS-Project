﻿"""
core/flow_engine.py - AEGIS-ADS Flow Engine
Converts raw packets to Flows with statistical features
"""

import time
import logging
import threading
from collections import defaultdict

logger = logging.getLogger(__name__)

# Try to import NFStream
try:
    from nfstream import NFStreamer
    NFSTREAM_AVAILABLE = True
    logger.info("✅ NFStream available")
except ImportError:
    NFSTREAM_AVAILABLE = False
    logger.error("❌ NFStream not installed. Run: pip install nfstream")
    raise

# Global storage
flows_cache = {}
flows_lock = threading.Lock()
packet_counter = 0
flow_counter = 0


def extract_flow_features(flow):
    """
    Extract 48+ features from NFStream flow for AI models
    """
    features = {
        # Basic flow identifiers
        "src_ip": flow.src_ip,
        "dst_ip": flow.dst_ip,
        "src_port": flow.src_port,
        "dst_port": flow.dst_port,
        "protocol": flow.protocol,
        
        # Packet counts
        "bidirectional_packets": flow.bidirectional_packets,
        "bidirectional_bytes": flow.bidirectional_bytes,
        "src2dst_packets": flow.src2dst_packets,
        "src2dst_bytes": flow.src2dst_bytes,
        "dst2src_packets": flow.dst2src_packets,
        "dst2src_bytes": flow.dst2src_bytes,
        
        # Timing
        "duration_ms": flow.bidirectional_duration_ms,
        "first_seen_ms": flow.bidirectional_first_seen_ms,
        "last_seen_ms": flow.bidirectional_last_seen_ms,
        
        # Packet size statistics
        "min_ps": flow.bidirectional_min_ps,
        "max_ps": flow.bidirectional_max_ps,
        "mean_ps": flow.bidirectional_mean_ps,
        "stddev_ps": flow.bidirectional_stddev_ps,
        
        "src2dst_min_ps": flow.src2dst_min_ps,
        "src2dst_max_ps": flow.src2dst_max_ps,
        "src2dst_mean_ps": flow.src2dst_mean_ps,
        "src2dst_stddev_ps": flow.src2dst_stddev_ps,
        
        "dst2src_min_ps": flow.dst2src_min_ps,
        "dst2src_max_ps": flow.dst2src_max_ps,
        "dst2src_mean_ps": flow.dst2src_mean_ps,
        "dst2src_stddev_ps": flow.dst2src_stddev_ps,
        
        # Inter-arrival time statistics
        "min_piat_ms": flow.bidirectional_min_piat_ms,
        "max_piat_ms": flow.bidirectional_max_piat_ms,
        "mean_piat_ms": flow.bidirectional_mean_piat_ms,
        "stddev_piat_ms": flow.bidirectional_stddev_piat_ms,
        
        "src2dst_min_piat_ms": flow.src2dst_min_piat_ms,
        "src2dst_max_piat_ms": flow.src2dst_max_piat_ms,
        "src2dst_mean_piat_ms": flow.src2dst_mean_piat_ms,
        "src2dst_stddev_piat_ms": flow.src2dst_stddev_piat_ms,
        
        "dst2src_min_piat_ms": flow.dst2src_min_piat_ms,
        "dst2src_max_piat_ms": flow.dst2src_max_piat_ms,
        "dst2src_mean_piat_ms": flow.dst2src_mean_piat_ms,
        "dst2src_stddev_piat_ms": flow.dst2src_stddev_piat_ms,
        
        # TCP Flags
        "syn_count": getattr(flow, "bidirectional_syn_packets", 0),
        "ack_count": getattr(flow, "bidirectional_ack_packets", 0),
        "rst_count": getattr(flow, "bidirectional_rst_packets", 0),
        "fin_count": getattr(flow, "bidirectional_fin_packets", 0),
        "psh_count": getattr(flow, "bidirectional_psh_packets", 0),
        "urg_count": getattr(flow, "bidirectional_urg_packets", 0),
        
        # L7 Application info
        "application_name": getattr(flow, "application_name", "unknown"),
        "application_category": getattr(flow, "application_category_name", "unknown"),
    }
    
    return features


def features_to_vector_78(features):
    """
    Convert features dictionary to 78-dim vector for RandomForest
    """
    import numpy as np
    
    vector = np.zeros(78, dtype=np.float32)
    
    # Fill basic features
    vector[0] = features.get("src_port", 0)
    vector[1] = features.get("dst_port", 0)
    vector[2] = features.get("protocol", 0)
    vector[3] = features.get("bidirectional_packets", 0)
    vector[4] = features.get("bidirectional_bytes", 0)
    vector[5] = features.get("src2dst_packets", 0)
    vector[6] = features.get("src2dst_bytes", 0)
    vector[7] = features.get("dst2src_packets", 0)
    vector[8] = features.get("dst2src_bytes", 0)
    vector[9] = features.get("duration_ms", 0)
    
    # Packet size stats
    vector[10] = features.get("min_ps", 0)
    vector[11] = features.get("max_ps", 0)
    vector[12] = features.get("mean_ps", 0)
    vector[13] = features.get("stddev_ps", 0)
    
    # TCP flags
    vector[14] = features.get("syn_count", 0)
    vector[15] = features.get("ack_count", 0)
    vector[16] = features.get("rst_count", 0)
    vector[17] = features.get("fin_count", 0)
    
    return vector.reshape(1, -1)


class FlowEngine:
    """Real-time flow engine using NFStream"""
    
    def __init__(self):
        self.running = False
        self.interface = None
        self.on_flow_callback = None
        self.on_detection_callback = None
    
    def set_flow_callback(self, callback):
        """Called for every flow with features"""
        self.on_flow_callback = callback
    
    def set_detection_callback(self, callback):
        """Called when attack detected"""
        self.on_detection_callback = callback
    
    def start(self, interface_name):
        if self.running:
            return
        
        self.interface = interface_name
        self.running = True
        
        threading.Thread(target=self._capture_loop, daemon=True).start()
        logger.warning(f"🔥 Flow Engine started on: {interface_name}")
    
    def stop(self):
        self.running = False
    
    def _capture_loop(self):
        global packet_counter, flow_counter
        
        try:
            streamer = NFStreamer(
                source=self.interface,
                statistical_analysis=True,
                promiscuous_mode=True,
                idle_timeout=15,
                active_timeout=60,
                n_dissections=20,
                snapshot_length=1536
            )
            
            for flow in streamer:
                if not self.running:
                    break
                
                try:
                    flow_counter += 1
                    packet_counter += flow.bidirectional_packets
                    
                    features = extract_flow_features(flow)
                    
                    # Store in cache
                    flow_key = (flow.src_ip, flow.dst_ip, flow.src_port, flow.dst_port, flow.protocol)
                    with flows_lock:
                        flows_cache[flow_key] = features
                    
                    logger.debug(f"[FLOW] {flow.src_ip}:{flow.src_port} -> {flow.dst_ip}:{flow.dst_port} | "
                               f"Packets: {flow.bidirectional_packets} | Bytes: {flow.bidirectional_bytes}")
                    
                    # Callback for AI processing
                    if self.on_flow_callback:
                        self.on_flow_callback(features)
                    
                except Exception as e:
                    logger.error(f"Flow processing error: {e}")
                    
        except Exception as e:
            logger.error(f"NFStream error: {e}")


_engine = None

def get_flow_engine():
    global _engine
    if _engine is None:
        _engine = FlowEngine()
    return _engine
