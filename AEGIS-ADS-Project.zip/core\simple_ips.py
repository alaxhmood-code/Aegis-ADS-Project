﻿"""
core/simple_ips.py - AEGIS-ADS SIMPLE IPS WITH AI PIPELINE (FULLY FIXED)
"""

import threading
import asyncio
import logging
import time
import numpy as np
import pandas as pd
from datetime import datetime

logger = logging.getLogger(__name__)

blocked_ips = set()
blocked_ips_lock = threading.Lock()
packet_count = 0
detection_count = 0
block_count = 0

# Flow tracking
flows = {}
flows_lock = threading.Lock()

# Feature names for scaler (must match training)
FEATURE_NAMES = [
    'packets', 'bytes', 'duration_ms', 'packet_rate', 'byte_rate',
    'icmp_count', 'syn_count', 'ack_count', 'rst_count', 'avg_packet_size'
]


class SimpleIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self.running = False
        self.main_loop = None
        self.windivert = None
        self.model_loader = None
        self._started = False
        self.pipeline_state = {"l1": "idle", "l2": "idle", "l3": "idle"}
        self.last_alert_time = 0
    
    def set_loop(self, loop):
        self.main_loop = loop
        logger.info("✅ Main loop set for WebSocket")
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected")
    
    def _get_flow_key(self, src_ip, dst_ip, src_port, dst_port, protocol):
        if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
            return (dst_ip, src_ip, dst_port, src_port, protocol)
        return (src_ip, dst_ip, src_port, dst_port, protocol)
    
    def _extract_features_df(self, flow):
        """Extract 10 features as DataFrame with proper column names"""
        duration = flow['last_seen'] - flow['first_seen']
        packet_rate = flow['packets'] / duration if duration > 0 else 0
        byte_rate = flow['bytes'] / duration if duration > 0 else 0
        avg_packet_size = flow['bytes'] / flow['packets'] if flow['packets'] > 0 else 0
        
        # Create DataFrame with exact column names
        data = {
            'packets': float(flow['packets']),
            'bytes': float(flow['bytes']),
            'duration_ms': float(duration * 1000),
            'packet_rate': float(packet_rate),
            'byte_rate': float(byte_rate),
            'icmp_count': float(flow.get('icmp_count', 0)),
            'syn_count': float(flow.get('syn_count', 0)),
            'ack_count': 0.0,
            'rst_count': 0.0,
            'avg_packet_size': float(avg_packet_size)
        }
        
        return pd.DataFrame([data])
    
    def _run_ai_pipeline(self, src_ip, flow):
        """Run AI detection on flow"""
        if not self.model_loader or not self.model_loader.xgb_model:
            return None
        
        try:
            self.pipeline_state["l1"] = "running"
            self._broadcast_stats()
            
            # Extract features as DataFrame
            features_df = self._extract_features_df(flow)
            
            # Apply scaler if available
            if self.model_loader.minmax_scaler:
                # Use DataFrame with column names
                features_scaled = self.model_loader.minmax_scaler.transform(features_df)
            else:
                features_scaled = features_df.values
            
            self.pipeline_state["l2"] = "running"
            
            # XGBoost prediction
            pred = self.model_loader.xgb_model.predict(features_scaled)[0]
            
            # Get probability
            if hasattr(self.model_loader.xgb_model, 'predict_proba'):
                proba = self.model_loader.xgb_model.predict_proba(features_scaled)[0]
                confidence = float(max(proba)) * 100
            else:
                confidence = 50.0
            
            # Decode attack type
            attack_type = "Unknown"
            if self.model_loader.label_encoder:
                try:
                    attack_type = self.model_loader.label_encoder.inverse_transform([pred])[0]
                except:
                    attack_type = str(pred)
            
            # Determine if attack
            is_attack = attack_type.upper() not in ['BENIGN', 'NORMAL', '0'] and confidence > 55
            
            self.pipeline_state["l3"] = "running" if is_attack else "idle"
            
            if is_attack:
                logger.info(f"[AI] 🎯 Detection: {attack_type} from {src_ip} ({confidence:.1f}%)")
            
            self.pipeline_state["l1"] = "idle"
            self.pipeline_state["l2"] = "idle"
            if not is_attack:
                self.pipeline_state["l3"] = "idle"
            
            return {'is_attack': is_attack, 'attack_type': attack_type, 'confidence': confidence}
            
        except Exception as e:
            logger.debug(f"AI error: {e}")
            self.pipeline_state["l1"] = "idle"
            self.pipeline_state["l2"] = "idle"
            return None
    
    def start(self, interface_name=None):
        global packet_count, detection_count, block_count
        
        if self._started:
            return True
        
        try:
            import pydivert
            
            logger.info("=" * 50)
            logger.info("🔥 SIMPLE IPS WITH AI STARTING")
            logger.info("=" * 50)
            
            filter_str = "ip and not loopback"
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            self.running = True
            self._started = True
            
            packet_count = 0
            detection_count = 0
            block_count = 0
            
            with flows_lock:
                flows.clear()
            
            threading.Thread(target=self._capture_loop, daemon=True).start()
            threading.Thread(target=self._stats_loop, daemon=True).start()
            
            logger.warning("🛡️ SIMPLE IPS WITH AI ACTIVE")
            logger.info("=" * 50)
            
            return True
        except Exception as e:
            logger.error(f"Start failed: {e}")
            return False
    
    def _stats_loop(self):
        while self.running:
            time.sleep(1)
            self._broadcast_stats()
    
    def _capture_loop(self):
        global packet_count, detection_count, block_count
        
        logger.info("📡 Capturing packets with AI...")
        
        try:
            for packet in self.windivert:
                if not self.running:
                    break
                
                packet_count += 1
                
                src_ip = packet.src_addr if hasattr(packet, 'src_addr') else None
                dst_ip = packet.dst_addr if hasattr(packet, 'dst_addr') else None
                src_port = packet.src_port if hasattr(packet, 'src_port') else 0
                dst_port = packet.dst_port if hasattr(packet, 'dst_port') else 0
                packet_size = len(packet.raw) if hasattr(packet, 'raw') else 64
                
                is_icmp = hasattr(packet, 'icmp') and packet.icmp
                is_syn = hasattr(packet, 'tcp') and packet.tcp and packet.tcp.syn
                protocol = 1 if is_icmp else 6 if hasattr(packet, 'tcp') else 17 if hasattr(packet, 'udp') else 0
                
                if not src_ip:
                    self.windivert.send(packet)
                    continue
                
                # Skip localhost
                if src_ip.startswith('127.') or dst_ip.startswith('127.'):
                    self.windivert.send(packet)
                    continue
                
                # Check if blocked
                with blocked_ips_lock:
                    if src_ip in blocked_ips:
                        continue
                
                # Update flow
                flow_key = self._get_flow_key(src_ip, dst_ip, src_port, dst_port, protocol)
                
                with flows_lock:
                    if flow_key not in flows:
                        flows[flow_key] = {
                            'packets': 0, 'bytes': 0, 'icmp_count': 0,
                            'syn_count': 0, 'first_seen': time.time(), 'last_seen': time.time()
                        }
                    flow = flows[flow_key]
                    flow['packets'] += 1
                    flow['bytes'] += packet_size
                    flow['last_seen'] = time.time()
                    if is_icmp:
                        flow['icmp_count'] += 1
                    if is_syn:
                        flow['syn_count'] += 1
                
                # AI PIPELINE every 10 packets
                if flow['packets'] >= 10 and flow['packets'] % 10 == 0:
                    ai_result = self._run_ai_pipeline(src_ip, flow)
                    
                    if ai_result and ai_result.get('is_attack'):
                        detection_count += 1
                        block_count += 1
                        with blocked_ips_lock:
                            blocked_ips.add(src_ip)
                        
                        alert_msg = f"🚨 AI BLOCKED: {src_ip} - {ai_result.get('attack_type')} ({ai_result.get('confidence', 0):.1f}%)"
                        logger.warning(alert_msg)
                        self._broadcast_alert(src_ip, dst_ip, ai_result.get('attack_type'), ai_result.get('confidence'))
                        self._broadcast_stats()
                        continue
                
                # Send packet
                self.windivert.send(packet)
                
                if packet_count % 100 == 0:
                    self._broadcast_stats()
                    
        except OSError as e:
            if hasattr(e, 'winerror') and e.winerror == 995:
                logger.info("WinDivert stopped normally")
            else:
                logger.error(f"Error: {e}")
        except Exception as e:
            logger.error(f"Capture error: {e}")
        finally:
            self.running = False
            self._started = False
    
    def _broadcast_stats(self):
        global packet_count, detection_count, block_count
        
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            data = {
                "type": "stats",
                "packets": packet_count,
                "detections": detection_count,
                "blocks": block_count,
                "pipeline": self.pipeline_state,
                "flows": len(flows)
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def _broadcast_alert(self, src_ip, dst_ip, attack_type, confidence):
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "attack_type": attack_type,
                "confidence": confidence,
                "severity": "CRITICAL"
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def stop(self):
        self.running = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("🛑 IPS Stopped")
    
    def block_ip(self, ip, reason="Manual"):
        global block_count, detection_count
        
        if not ip or ip in ["undefined", "-", "None", ""]:
            return False
        
        with blocked_ips_lock:
            if ip not in blocked_ips:
                blocked_ips.add(ip)
                block_count += 1
                detection_count += 1
                logger.warning(f"✅ [MANUAL BLOCK] {ip}")
                self._broadcast_stats()
                return True
        return False
    
    def unblock_ip(self, ip):
        with blocked_ips_lock:
            if ip in blocked_ips:
                blocked_ips.discard(ip)
                return True
        return False
    
    def get_blocked_ips(self):
        with blocked_ips_lock:
            return list(blocked_ips)
    
    def get_stats(self):
        global packet_count, detection_count, block_count
        return {
            "total_packets": packet_count,
            "detections": detection_count,
            "blocks": block_count,
            "blocked_ips": len(blocked_ips),
            "blocked_ips_list": list(blocked_ips),
            "is_running": self.running,
            "active_flows": len(flows),
            "pipeline": self.pipeline_state
        }


def get_ips():
    return SimpleIPS()
