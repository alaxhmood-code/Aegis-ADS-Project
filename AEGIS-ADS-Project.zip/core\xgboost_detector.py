﻿"""
core/xgboost_detector.py - XGBoost with aggressive detection
"""

import logging
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class XGBoostDetector:
    def __init__(self, model_loader, feature_extractor):
        self.model_loader = model_loader
        self.feature_extractor = feature_extractor
        self.detection_count = 0
        
        # ✅ AGGRESSIVE THRESHOLDS - Lower to catch more attacks
        self.BLOCK_THRESHOLD = 55      # Block if >55%
        self.ATTACK_THRESHOLD = 45      # Attack if >45%
        
        self.ATTACK_CLASSES = [
            "DoS", "DDoS", "PortScan", "Botnet", "FTP-Patator", "SSH-Patator",
            "Web Attack", "Infiltration", "Heartbleed", "Brute Force", "ICMP",
            "GoldenEye", "Hulk", "Slowloris", "Slowhttptest"
        ]

    def detect_from_flow(self, flow_stats):
        if not self.model_loader or not self.model_loader.xgb_model:
            return {'is_attack': False, 'attack_type': 'Unknown', 'confidence': 0, 'should_block': False}
        
        try:
            features_df = self.feature_extractor.extract_from_flow(flow_stats)
            features_scaled = features_df.values
            
            if self.model_loader.minmax_scaler:
                try:
                    features_scaled = self.model_loader.minmax_scaler.transform(features_df)
                except:
                    pass
            
            pred = int(self.model_loader.xgb_model.predict(features_scaled)[0])
            
            if hasattr(self.model_loader.xgb_model, 'predict_proba'):
                proba = self.model_loader.xgb_model.predict_proba(features_scaled)[0]
                confidence = float(max(proba)) * 100
            else:
                confidence = 50.0
            
            attack_type = "Unknown"
            if self.model_loader.label_encoder:
                try:
                    attack_type = self.model_loader.label_encoder.inverse_transform([pred])[0]
                except:
                    attack_type = str(pred)
            
            # ✅ ICMP flood detection - immediate block
            icmp_count = flow_stats.get('icmp_count', 0)
            if icmp_count >= 10:  # Lower threshold from 30 to 10
                attack_type = "ICMP_FLOOD"
                confidence = min(98, confidence + 40)
                logger.warning(f"[XGBoost] 🚨 ICMP_FLOOD detected: {icmp_count} ICMP packets")
                return {
                    'is_attack': True,
                    'attack_type': attack_type,
                    'confidence': 90,
                    'should_block': True
                }
            
            # ✅ ANY suspicious traffic with decent confidence = ATTACK
            is_attack = False
            
            # Check if it's a known attack type
            for attack in self.ATTACK_CLASSES:
                if attack.lower() in attack_type.lower():
                    is_attack = True
                    break
            
            # Also treat high packet count as suspicious
            packets = flow_stats.get('packets', 0)
            if packets > 50 and confidence > 40:
                is_attack = True
                if attack_type == "Unknown":
                    attack_type = "HIGH_TRAFFIC"
            
            # ✅ AGGRESSIVE BLOCK
            if is_attack or confidence >= self.ATTACK_THRESHOLD:
                should_block = confidence >= self.BLOCK_THRESHOLD or icmp_count >= 10
                
                if should_block:
                    self.detection_count += 1
                    logger.warning(f"[XGBoost] 🚨 BLOCK: {attack_type} ({confidence:.1f}%) - Packets: {packets}, ICMP: {icmp_count}")
                else:
                    logger.info(f"[XGBoost] ⚠️ ATTACK: {attack_type} ({confidence:.1f}%) - Packets: {packets}")
                
                return {
                    'is_attack': True,
                    'attack_type': attack_type,
                    'confidence': confidence,
                    'should_block': should_block
                }
            else:
                return {
                    'is_attack': False,
                    'attack_type': 'BENIGN',
                    'confidence': confidence,
                    'should_block': False
                }
            
        except Exception as e:
            logger.error(f"XGBoost error: {e}")
            return {'is_attack': False, 'attack_type': 'Error', 'confidence': 0, 'should_block': False}


def get_xgb_detector(model_loader, feature_extractor):
    return XGBoostDetector(model_loader, feature_extractor)
