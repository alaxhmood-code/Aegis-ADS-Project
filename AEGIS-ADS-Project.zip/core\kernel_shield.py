﻿"""
core/kernel_shield.py - Permanent Kernel Level Blocking
"""

import threading
import logging
import subprocess
import time

logger = logging.getLogger(__name__)

# Persistent blacklist (لا تنتهي صلاحيتها)
blacklist = set()
blacklist_lock = threading.Lock()


def add_to_blacklist(ip: str, permanent=True):
    """Add IP to kernel blacklist - PERMANENT block"""
    with blacklist_lock:
        blacklist.add(ip)
    
    # ✅ Windows Firewall - Permanent rule
    try:
        rule_name = f"AEGIS_PERMANENT_BLOCK_{ip.replace('.', '_')}"
        
        # Delete existing rule if any
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule_name}"],
            capture_output=True, shell=True
        )
        
        # Add permanent block rule
        result = subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule",
             f"name={rule_name}",
             "dir=in",
             "action=block",
             f"remoteip={ip}",
             "protocol=any",
             "enable=yes"],
            capture_output=True, shell=True
        )
        
        if result.returncode == 0:
            logger.warning(f"[KERNEL] ✅ PERMANENT BLOCK: {ip}")
        else:
            logger.error(f"[KERNEL] Firewall error: {result.stderr}")
            
    except Exception as e:
        logger.error(f"Firewall error: {e}")
    
    # ✅ Also add to Windows Filtering Platform via PowerShell
    try:
        ps_command = f'New-NetFirewallRule -DisplayName "AEGIS_BLOCK_{ip}" -Direction Inbound -RemoteAddress {ip} -Action Block -Protocol Any'
        subprocess.run(["powershell", "-Command", ps_command], capture_output=True, shell=True)
    except:
        pass


def remove_from_blacklist(ip: str):
    """Remove IP from blacklist"""
    with blacklist_lock:
        blacklist.discard(ip)
    
    try:
        rule_name = f"AEGIS_PERMANENT_BLOCK_{ip.replace('.', '_')}"
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "delete", "rule", f"name={rule_name}"],
            capture_output=True, shell=True
        )
        
        ps_command = f'Remove-NetFirewallRule -DisplayName "AEGIS_BLOCK_{ip}"'
        subprocess.run(["powershell", "-Command", ps_command], capture_output=True, shell=True)
        
        logger.info(f"[KERNEL] 🔓 Unblocked {ip}")
    except:
        pass


def is_blocked(ip: str) -> bool:
    with blacklist_lock:
        return ip in blacklist


def get_blacklist():
    with blacklist_lock:
        return list(blacklist)


def clear_blacklist():
    """Clear all blocked IPs"""
    with blacklist_lock:
        for ip in list(blacklist):
            remove_from_blacklist(ip)
        blacklist.clear()
    return True
