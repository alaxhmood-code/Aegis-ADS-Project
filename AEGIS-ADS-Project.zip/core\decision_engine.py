﻿"""
core/decision_engine.py - Real decision engine with Windows Firewall blocking
"""

import logging
import subprocess
import threading
import time

logger = logging.getLogger(__name__)


class DecisionEngine:
    def __init__(self):
        self.blocked_ips = {}
        self.block_duration = 300  # 5 minutes
        self._lock = threading.Lock()
    
    def _block_with_netsh(self, ip, reason):
        """Execute Windows Firewall block using netsh"""
        try:
            rule_name = f"AEGIS_BLOCK_{ip.replace('.', '_')}"
            
            # Add firewall rule
            cmd = [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}",
                "dir=in",
                "action=block",
                f"remoteip={ip}",
                "protocol=any"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
            
            if result.returncode == 0:
                logger.warning(f"[FIREWALL] ✅ Blocked {ip} - {reason}")
                return True
            else:
                logger.error(f"[FIREWALL] Failed to block {ip}: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"[FIREWALL] Error blocking {ip}: {e}")
            return False
    
    def _unblock_with_netsh(self, ip):
        """Remove Windows Firewall block rule"""
        try:
            rule_name = f"AEGIS_BLOCK_{ip.replace('.', '_')}"
            
            cmd = [
                "netsh", "advfirewall", "firewall", "delete", "rule",
                f"name={rule_name}"
            ]
            
            subprocess.run(cmd, capture_output=True, text=True, shell=True)
            logger.info(f"[FIREWALL] 🔓 Unblocked {ip}")
            return True
            
        except Exception as e:
            logger.error(f"[FIREWALL] Error unblocking {ip}: {e}")
            return False
    
    def decide(self, src_ip, dst_ip, detection_result):
        """Make final decision and execute block if needed"""
        if not detection_result:
            return {'action': 'ignore', 'reason': 'no detection'}
        
        is_attack = detection_result.get('is_attack', False)
        attack_type = detection_result.get('attack_type', 'Unknown')
        confidence = detection_result.get('confidence', 0)
        should_block = detection_result.get('should_block', False)
        
        # Skip whitelisted IPs
        if src_ip in ["8.8.8.8", "8.8.4.4", "1.1.1.1", "192.168.137.1", "127.0.0.1"]:
            return {'action': 'ignore', 'reason': 'whitelisted'}
        
        # Check if already blocked
        with self._lock:
            if src_ip in self.blocked_ips:
                return {'action': 'already_blocked', 'reason': f'Previously blocked: {attack_type}'}
        
        # REAL BLOCK DECISION
        if is_attack and should_block and confidence >= 75:
            # Execute firewall block
            success = self._block_with_netsh(src_ip, f"{attack_type} ({confidence:.1f}%)")
            
            if success:
                with self._lock:
                    self.blocked_ips[src_ip] = {
                        'timestamp': time.time(),
                        'attack': attack_type,
                        'confidence': confidence,
                        'expires': time.time() + self.block_duration
                    }
                
                logger.warning(f"🚨 DECISION: BLOCK {src_ip} - {attack_type} ({confidence:.1f}%)")
                
                return {
                    'action': 'block',
                    'reason': attack_type,
                    'confidence': confidence,
                    'firewall_rule_added': True
                }
            else:
                return {
                    'action': 'block_failed',
                    'reason': f'Firewall error: {attack_type}',
                    'confidence': confidence
                }
        
        elif is_attack:
            return {
                'action': 'monitor',
                'reason': f'Low confidence: {attack_type} ({confidence:.1f}%)',
                'confidence': confidence
            }
        
        else:
            return {'action': 'allow', 'reason': 'normal traffic', 'confidence': 100 - confidence}
    
    def is_blocked(self, ip):
        with self._lock:
            if ip in self.blocked_ips:
                if time.time() > self.blocked_ips[ip]['expires']:
                    # Auto unblock after duration
                    self._unblock_with_netsh(ip)
                    del self.blocked_ips[ip]
                    return False
                return True
        return False
    
    def block_ip(self, ip, reason="Manual"):
        if ip in ["8.8.8.8", "8.8.4.4", "1.1.1.1", "192.168.137.1"]:
            return False
        
        success = self._block_with_netsh(ip, reason)
        if success:
            with self._lock:
                self.blocked_ips[ip] = {
                    'timestamp': time.time(),
                    'attack': reason,
                    'confidence': 100,
                    'expires': time.time() + self.block_duration
                }
        return success
    
    def unblock_ip(self, ip):
        self._unblock_with_netsh(ip)
        with self._lock:
            if ip in self.blocked_ips:
                del self.blocked_ips[ip]
        return True
    
    def get_blocked_ips(self):
        with self._lock:
            return list(self.blocked_ips.keys())


def get_decision_engine():
    return DecisionEngine()
