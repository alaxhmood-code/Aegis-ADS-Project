﻿"""
core/report_engine.py - Professional Report Engine for AEGIS-ADS
"""

import os
import io
import logging
from datetime import datetime, timedelta
from collections import defaultdict

logger = logging.getLogger(__name__)

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
except ImportError:
    plt = None
    logger.warning("matplotlib not installed. Charts will be disabled.")

try:
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.units import inch, cm
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, 
                                    TableStyle, PageBreak, Image)
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
except ImportError:
    logger.error("reportlab not installed. Please install: pip install reportlab")
    raise

logger = logging.getLogger(__name__)


class ProfessionalReportGenerator:
    """Professional Security Report Generator"""
    
    def __init__(self, orchestrator):
        self.orchestrator = orchestrator
        
        # Color palette - Professional SOC style
        self.colors = {
            'primary': colors.HexColor('#00ff9c'),
            'secondary': colors.HexColor('#00c2ff'),
            'danger': colors.HexColor('#ff3b5c'),
            'warning': colors.HexColor('#ff9f1c'),
            'dark': colors.HexColor('#1a1f3a'),
            'darker': colors.HexColor('#0a0e27'),
            'text': colors.HexColor('#e8edf5'),
            'muted': colors.HexColor('#8a9ab0'),
        }
    
    def create_pie_chart(self, data, labels, title):
        """Create pie chart as image"""
        if not plt:
            return None
        
        try:
            plt.style.use('dark_background')
            fig, ax = plt.subplots(figsize=(6, 4))
            fig.patch.set_facecolor('#1a1f3a')
            ax.set_facecolor('#1a1f3a')
            
            colors_list = ['#ff3b5c', '#ff9f1c', '#00c2ff', '#00ff9c', '#9d4edd']
            wedges, texts, autotexts = ax.pie(data, labels=labels, autopct='%1.1f%%',
                                              colors=colors_list[:len(data)])
            for text in texts:
                text.set_color('white')
            for autotext in autotexts:
                autotext.set_color('white')
            
            ax.set_title(title, color='white', fontsize=14, pad=20)
            
            buf = io.BytesIO()
            plt.savefig(buf, format='png', dpi=150, bbox_inches='tight', facecolor='#1a1f3a')
            buf.seek(0)
            plt.close()
            return buf
        except Exception as e:
            logger.error(f"Chart creation error: {e}")
            return None
    
    def calculate_threat_level(self, stats):
        """Calculate global threat level"""
        detections = stats.get('detections', 0)
        blocks = stats.get('blocks', 0)
        blocked_ips = stats.get('blocked_ips', 0)
        
        score = min(100, (detections * 5) + (blocks * 3) + (blocked_ips * 2))
        
        if score >= 70:
            level = "HIGH RISK"
            color = self.colors['danger']
        elif score >= 40:
            level = "MEDIUM RISK"
            color = self.colors['warning']
        else:
            level = "LOW RISK"
            color = self.colors['primary']
        
        return score, level, color
    
    def generate_executive_report(self, report_type="executive"):
        """Generate professional executive report"""
        
        stats = self.orchestrator.get_stats()
        attack_counts = stats.get("attack_counts", {})
        if not attack_counts:
            attack_counts = {"No Attacks": 0}
        
        # Calculate threat level
        threat_score, threat_level, threat_color = self.calculate_threat_level(stats)
        
        # Create reports directory
        os.makedirs("reports", exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"AEGIS_{report_type.upper()}_Report_{timestamp}.pdf"
        filepath = os.path.join("reports", filename)
        
        # Create PDF
        doc = SimpleDocTemplate(filepath, pagesize=landscape(A4),
                                leftMargin=1.5*cm, rightMargin=1.5*cm,
                                topMargin=1.5*cm, bottomMargin=1.5*cm)
        styles = getSampleStyleSheet()
        story = []
        
        # Custom styles
        title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                     fontSize=32, textColor=self.colors['primary'],
                                     alignment=TA_CENTER, spaceAfter=20)
        header_style = ParagraphStyle('Header', parent=styles['Heading2'],
                                      fontSize=18, textColor=self.colors['secondary'],
                                      spaceAfter=10, spaceBefore=10)
        normal_style = ParagraphStyle('Normal', parent=styles['Normal'],
                                      fontSize=10, textColor=self.colors['text'],
                                      alignment=TA_LEFT)
        
        # ============================================================
        # COVER PAGE
        # ============================================================
        story.append(Paragraph("🛡️ AEGIS-ADS", title_style))
        story.append(Paragraph("Advanced AI Security Platform", header_style))
        story.append(Spacer(1, 0.8*inch))
        
        # Report type badge
        type_style = ParagraphStyle('Type', parent=styles['Normal'],
                                    fontSize=14, textColor=self.colors['danger'],
                                    alignment=TA_CENTER)
        story.append(Paragraph(f"<b>{report_type.upper()} REPORT</b>", type_style))
        story.append(Spacer(1, 0.5*inch))
        
        # Threat level
        level_style = ParagraphStyle('ThreatLevel', parent=styles['Normal'],
                                     fontSize=16, textColor=threat_color,
                                     alignment=TA_CENTER)
        story.append(Paragraph(f"<b>GLOBAL THREAT LEVEL: {threat_level}</b>", level_style))
        story.append(Paragraph(f"<b>Score: {threat_score}/100</b>", level_style))
        story.append(Spacer(1, 0.5*inch))
        
        # Classification
        story.append(Paragraph("<i>Classification: CONFIDENTIAL</i>", normal_style))
        story.append(Spacer(1, 0.3*inch))
        story.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", normal_style))
        story.append(Paragraph("Generated by: AEGIS AI Engine", normal_style))
        story.append(Paragraph("Developer: Mohammed Bilal", normal_style))
        story.append(PageBreak())
        
        # ============================================================
        # EXECUTIVE SUMMARY
        # ============================================================
        story.append(Paragraph("Executive Summary", header_style))
        
        summary_text = f"""
        This report provides a comprehensive security analysis of the monitored network.
        During the reporting period, the AEGIS-ADS AI engine detected and analyzed 
        {stats.get('detections', 0)} security threats, successfully blocking {stats.get('blocks', 0)} attacks.
        The system is currently operating with {stats.get('active_flows', 0)} active network flows.
        """
        story.append(Paragraph(summary_text, normal_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Statistics table
        summary_data = [
            ["Metric", "Value", "Status"],
            ["Total Packets", f"{stats.get('total_packets', 0):,}", "NORMAL"],
            ["Threats Detected", str(stats.get('detections', 0)), "WARNING" if stats.get('detections', 0) > 0 else "NORMAL"],
            ["Attacks Blocked", str(stats.get('blocks', 0)), "SUCCESS" if stats.get('blocks', 0) > 0 else "NORMAL"],
            ["Blocked IPs", str(stats.get('blocked_ips', 0)), "WARNING" if stats.get('blocked_ips', 0) > 0 else "NORMAL"],
            ["Active Flows", str(stats.get('active_flows', 0)), "NORMAL"],
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 1, self.colors['primary']),
            ('BACKGROUND', (0, 0), (-1, 0), self.colors['dark']),
            ('TEXTCOLOR', (0, 0), (-1, 0), self.colors['primary']),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        story.append(summary_table)
        story.append(Spacer(1, 0.3*inch))
        
        # ============================================================
        # ATTACK DISTRIBUTION CHART
        # ============================================================
        if attack_counts and len(attack_counts) > 0:
            story.append(Paragraph("Attack Distribution Analysis", header_style))
            
            labels = list(attack_counts.keys())
            data = list(attack_counts.values())
            if data and sum(data) > 0:
                chart_buf = self.create_pie_chart(data, labels, "Attacks by Type")
                if chart_buf:
                    story.append(Image(chart_buf, width=5*inch, height=3.5*inch))
                    story.append(Spacer(1, 0.2*inch))
        
        # ============================================================
        # THREAT INTELLIGENCE TABLE
        # ============================================================
        story.append(Paragraph("Threat Intelligence", header_style))
        
        threat_data = [["Time", "Source IP", "Destination", "Attack Type", "Confidence", "Action"]]
        alerts_list = self.orchestrator.alert_history if hasattr(self.orchestrator, 'alert_history') else []
        
        for alert in alerts_list[:15]:
            threat_data.append([
                alert.get('timestamp', '-'),
                alert.get('src_ip', '-'),
                alert.get('dst_ip', '-'),
                alert.get('attack_type', '-'),
                f"{alert.get('confidence', 0)}%",
                "BLOCKED"
            ])
        
        if len(threat_data) == 1:
            threat_data.append(["No threats detected", "-", "-", "-", "-", "-"])
        
        threat_table = Table(threat_data, colWidths=[1*inch, 1.2*inch, 1.2*inch, 1.5*inch, 0.8*inch, 0.8*inch])
        threat_table.setStyle(TableStyle([
            ('GRID', (0, 0), (-1, -1), 1, self.colors['danger']),
            ('BACKGROUND', (0, 0), (-1, 0), self.colors['danger']),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('WORDWRAP', (0, 0), (-1, -1), True),
        ]))
        story.append(threat_table)
        story.append(PageBreak())
        
        # ============================================================
        # FOOTER / SIGNATURE
        # ============================================================
        story.append(Spacer(1, 0.5*inch))
        story.append(Paragraph("="*80, normal_style))
        story.append(Paragraph("<b>Generated by AEGIS-ADS v11.0 Security Platform</b>", normal_style))
        story.append(Paragraph("AI Cyber Defense System", normal_style))
        story.append(Paragraph("Developer: Mohammed Bilal", normal_style))
        story.append(Paragraph(f"© 2026 AEGIS Cybersecurity Systems - All Rights Reserved", normal_style))
        
        # Build PDF
        doc.build(story)
        
        return {"status": "success", "file": filename, "path": f"/reports/{filename}"}


def get_report_engine(orchestrator):
    return ProfessionalReportGenerator(orchestrator)
