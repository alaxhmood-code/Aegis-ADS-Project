﻿"""
core/advanced_ips.py - AEGIS-ADS Advanced IPS
Kernel Level Packet Interception + Flow Engine + AI Pipeline
"""

import threading
import asyncio
import logging
import time
import struct
from collections import defaultdict
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, Set, Tuple

logger = logging.getLogger(__name__)

# ============================================================
# Data Structures
# ============================================================

@dataclass
class Flow:
    """تمثيل تدفق الشبكة (5-tuple)"""
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: int
    
    # Counters
    packets: int = 0
    bytes: int = 0
    src2dst_packets: int = 0
    src2dst_bytes: int = 0
    dst2src_packets: int = 0
    dst2src_bytes: int = 0
    
    # TCP Flags
    syn_count: int = 0
    ack_count: int = 0
    rst_count: int = 0
    fin_count: int = 0
    psh_count: int = 0
    urg_count: int = 0
    
    # Timing
    first_seen: float = 0
    last_seen: float = 0
    
    # Packet sizes
    packet_sizes: list = field(default_factory=list)
    inter_arrival_times: list = field(default_factory=list)
    last_packet_time: float = 0
    
    # AI Results
    is_attack: bool = False
    attack_type: str = "NORMAL"
    confidence: float = 0.0
    
    def get_key(self) -> Tuple:
        return (self.src_ip, self.dst_ip, self.src_port, self.dst_port, self.protocol)
    
    def get_duration(self) -> float:
        return self.last_seen - self.first_seen if self.first_seen else 0
    
    def get_packet_rate(self) -> float:
        dur = self.get_duration()
        return self.packets / dur if dur > 0 else 0
    
    def get_byte_rate(self) -> float:
        dur = self.get_duration()
        return self.bytes / dur if dur > 0 else 0
    
    def get_avg_packet_size(self) -> float:
        return self.bytes / self.packets if self.packets > 0 else 0
    
    def get_min_packet_size(self) -> int:
        return min(self.packet_sizes) if self.packet_sizes else 0
    
    def get_max_packet_size(self) -> int:
        return max(self.packet_sizes) if self.packet_sizes else 0
    
    def get_stddev_packet_size(self) -> float:
        if len(self.packet_sizes) < 2:
            return 0
        mean = self.get_avg_packet_size()
        variance = sum((x - mean) ** 2 for x in self.packet_sizes) / len(self.packet_sizes)
        return variance ** 0.5


# ============================================================
# Global State
# ============================================================

blocked_ips: Set[str] = set()
blocked_flows: Set[Tuple] = set()
active_flows: Dict[Tuple, Flow] = {}
flows_lock = threading.Lock()

WHITELIST = {
    "127.0.0.1", "192.168.137.1", "192.168.43.1",
    "8.8.8.8", "8.8.4.4", "1.1.1.1"
}


# ============================================================
# Feature Extractor (78 features for RandomForest)
# ============================================================

def extract_78_features(flow: Flow) -> list:
    """استخراج 78 ميزة متوافقة مع CICIDS2017"""
    features = []
    
    # Basic features (1-10)
    features.append(flow.src_port)
    features.append(flow.dst_port)
    features.append(flow.protocol)
    features.append(flow.packets)
    features.append(flow.bytes)
    features.append(flow.src2dst_packets)
    features.append(flow.src2dst_bytes)
    features.append(flow.dst2src_packets)
    features.append(flow.dst2src_bytes)
    features.append(flow.get_duration() * 1000)  # ms
    
    # Packet size stats (11-18)
    features.append(flow.get_min_packet_size())
    features.append(flow.get_max_packet_size())
    features.append(flow.get_avg_packet_size())
    features.append(flow.get_stddev_packet_size())
    
    # TCP Flags (19-30)
    features.append(flow.syn_count)
    features.append(flow.ack_count)
    features.append(flow.rst_count)
    features.append(flow.fin_count)
    features.append(flow.psh_count)
    features.append(flow.urg_count)
    
    # Rates (31-34)
    features.append(flow.get_packet_rate())
    features.append(flow.get_byte_rate())
    
    # Padding to 78 features (for compatibility)
    while len(features) < 78:
        features.append(0.0)
    
    return features


# ============================================================
# Advanced IPS Class
# ============================================================

class AdvancedIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        
        self.running = False
        self.packet_count = 0
        self.flow_count = 0
        self.detection_count = 0
        self.block_count = 0
        
        self.main_loop = None
        self.windivert = None
        self.model_loader = None
        
        self._started = False
    
    def set_loop(self, loop):
        self.main_loop = loop
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected to Advanced IPS")
    
    def start(self, interface_name=None):
        if self._started:
            return True
        
        try:
            import pydivert
            
            logger.info("=" * 60)
            logger.info("🚀 AEGIS-ADS Advanced IPS Starting")
            logger.info("=" * 60)
            
            # Filter: capture all IP traffic except loopback
            filter_str = "ip and not loopback"
            
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            self.running = True
            self._started = True
            
            # Start capture thread
            threading.Thread(target=self._capture_loop, daemon=True).start()
            
            # Start cleanup thread (remove old flows)
            threading.Thread(target=self._cleanup_loop, daemon=True).start()
            
            logger.warning("🛡️ ADVANCED IPS ACTIVE (Kernel Level)")
            logger.info(f"   Filter: {filter_str}")
            logger.info("   Flow Engine: ENABLED")
            logger.info("   AI Pipeline: READY")
            logger.info("=" * 60)
            
            return True
            
        except Exception as e:
            logger.error(f"Advanced IPS start failed: {e}")
            return False
    
    def _capture_loop(self):
        """Main packet capture and processing loop"""
        logger.info("📡 Capturing packets...")
        
        for packet in self.windivert:
            if not self.running:
                break
            
            try:
                self.packet_count += 1
                
                # Extract packet info
                src_ip = packet.src_addr
                dst_ip = packet.dst_addr
                src_port = packet.src_port or 0
                dst_port = packet.dst_port or 0
                
                # Get protocol
                protocol = 0
                if packet.tcp:
                    protocol = 6
                elif packet.udp:
                    protocol = 17
                elif packet.icmp:
                    protocol = 1
                
                # Create flow key (bidirectional)
                if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
                    flow_key = (dst_ip, src_ip, dst_port, src_port, protocol)
                    direction = "dst2src"
                else:
                    flow_key = (src_ip, dst_ip, src_port, dst_port, protocol)
                    direction = "src2dst"
                
                # Check if IP is blocked
                if src_ip in blocked_ips or dst_ip in blocked_ips:
                    # Drop packet silently
                    continue
                
                # Check if flow is blocked
                if flow_key in blocked_flows:
                    continue
                
                # Update or create flow
                now = time.time()
                packet_size = len(packet)
                
                with flows_lock:
                    if flow_key not in active_flows:
                        active_flows[flow_key] = Flow(
                            src_ip=src_ip, dst_ip=dst_ip,
                            src_port=src_port, dst_port=dst_port,
                            protocol=protocol,
                            first_seen=now, last_seen=now,
                            last_packet_time=now
                        )
                        self.flow_count += 1
                    
                    flow = active_flows[flow_key]
                    flow.last_seen = now
                    flow.packets += 1
                    flow.bytes += packet_size
                    flow.packet_sizes.append(packet_size)
                    
                    # Calculate inter-arrival time
                    if flow.last_packet_time > 0:
                        iat = (now - flow.last_packet_time) * 1000  # ms
                        flow.inter_arrival_times.append(iat)
                    flow.last_packet_time = now
                    
                    # Direction-specific counters
                    if direction == "src2dst":
                        flow.src2dst_packets += 1
                        flow.src2dst_bytes += packet_size
                    else:
                        flow.dst2src_packets += 1
                        flow.dst2src_bytes += packet_size
                    
                    # TCP Flags
                    if packet.tcp:
                        if packet.tcp.syn:
                            flow.syn_count += 1
                        if packet.tcp.ack:
                            flow.ack_count += 1
                        if packet.tcp.rst:
                            flow.rst_count += 1
                        if packet.tcp.fin:
                            flow.fin_count += 1
                        if packet.tcp.psh:
                            flow.psh_count += 1
                        if packet.tcp.urg:
                            flow.urg_count += 1
                
                # Run AI detection every N packets
                if flow.packets % 10 == 0 and flow.packets >= 10:
                    self._run_ai_detection(flow, flow_key)
                
                # Allow packet (send it)
                self.windivert.send(packet)
                
                # Update dashboard every 100 packets
                if self.packet_count % 100 == 0:
                    self._broadcast_stats()
                    
            except Exception as e:
                logger.error(f"Packet processing error: {e}")
                try:
                    self.windivert.send(packet)
                except:
                    pass
    
    def _run_ai_detection(self, flow: Flow, flow_key: Tuple):
        """Run AI pipeline on the flow"""
        if not self.model_loader:
            return
        
        try:
            # Extract 78 features for RandomForest
            features_78 = extract_78_features(flow)
            
            # Convert to numpy array
            import numpy as np
            features_array = np.array(features_78).reshape(1, -1)
            
            # L1: RandomForest binary classification
            is_attack, confidence = self.model_loader.predict_l1(features_array)
            
            if not is_attack:
                return
            
            # L2: XGBoost attack classification
            # Need 10 features for XGBoost
            features_10 = np.array([[
                flow.packets, flow.bytes, flow.get_duration(),
                flow.get_packet_rate(), flow.get_byte_rate(),
                flow.syn_count, flow.ack_count, flow.rst_count,
                flow.fin_count, flow.get_avg_packet_size()
            ]])
            
            l2_result = self.model_loader.predict_l2(features_10)
            
            # L3: Deep learning decision
            l3_result = self.model_loader.predict_l3(None)
            
            # Final decision: block if high confidence
            if l2_result['confidence'] > 70:
                attack_type = l2_result['attack_type']
                
                logger.warning(f"[🚨 {attack_type}] {flow.src_ip}:{flow.src_port} -> {flow.dst_ip}:{flow.dst_port}")
                logger.warning(f"   Confidence: {l2_result['confidence']:.1f}%")
                logger.warning(f"   Packets: {flow.packets} | Bytes: {flow.bytes}")
                
                # Block the IP
                self._block_ip(flow.src_ip, attack_type)
                
                # Block the flow
                with flows_lock:
                    blocked_flows.add(flow_key)
                
                self.detection_count += 1
                self.block_count += 1
                
                # Broadcast alert
                self._broadcast_alert(flow.src_ip, flow.dst_ip, attack_type, l2_result['confidence'])
                
        except Exception as e:
            logger.error(f"AI detection error: {e}")
    
    def _block_ip(self, ip: str, reason: str):
        """Block IP at kernel level"""
        if ip in WHITELIST:
            return
        
        with flows_lock:
            blocked_ips.add(ip)
            
            # Also block all flows from this IP
            for key, flow in list(active_flows.items()):
                if flow.src_ip == ip:
                    blocked_flows.add(key)
        
        logger.warning(f"⛔ KERNEL BLOCK: {ip} ({reason})")
    
    def _cleanup_loop(self):
        """Remove old flows periodically"""
        while self.running:
            time.sleep(60)  # every minute
            now = time.time()
            timeout = 60  # 60 seconds idle timeout
            
            with flows_lock:
                old_keys = [key for key, flow in active_flows.items() 
                           if now - flow.last_seen > timeout]
                for key in old_keys:
                    del active_flows[key]
                if old_keys:
                    logger.debug(f"Cleaned {len(old_keys)} old flows")
    
    def _broadcast_stats(self):
        """Broadcast statistics to dashboard"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            data = {
                "type": "stats",
                "packets": self.packet_count,
                "detections": self.detection_count,
                "blocks": self.block_count,
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def _broadcast_alert(self, src_ip: str, dst_ip: str, attack_type: str, confidence: float):
        """Broadcast alert to dashboard"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "attack_type": attack_type,
                "severity": "CRITICAL",
                "confidence": confidence
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def stop(self):
        self.running = False
        self._started = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("🛑 Advanced IPS Stopped")
    
    def block_ip(self, ip: str, reason: str = "Manual"):
        if ip in WHITELIST:
            return False
        self._block_ip(ip, reason)
        self._broadcast_stats()
        return True
    
    def unblock_ip(self, ip: str):
        with flows_lock:
            if ip in blocked_ips:
                blocked_ips.discard(ip)
                # Also unblock flows
                for key, flow in list(active_flows.items()):
                    if flow.src_ip == ip:
                        blocked_flows.discard(key)
                return True
        return False
    
    def get_blocked_ips(self):
        with flows_lock:
            return list(blocked_ips)
    
    def get_stats(self):
        with flows_lock:
            return {
                "total_packets": self.packet_count,
                "detections": self.detection_count,
                "blocks": self.block_count,
                "blocked_ips": len(blocked_ips),
                "active_flows": len(active_flows),
                "is_running": self.running
            }


def get_ips():
    return AdvancedIPS()
