﻿# run_aegis_admin.ps1
# تشغيل AEGIS-ADS مع صلاحيات مسؤول لتفعيل WinDivert

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  🛡️ AEGIS-ADS v11.0 - التشغيل مع WinDivert" -ForegroundColor White
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# التحقق من صلاحيات المسؤول
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "⚠️ يرجى تشغيل PowerShell كمسؤول لتفعيل WinDivert!" -ForegroundColor Red
    Write-Host "🔄 أعد تشغيل PowerShell كمسؤول أو استخدم run_aegis_admin.bat" -ForegroundColor Yellow
    pause
    exit
}

Write-Host "✅ تم التحقق من صلاحيات المسؤول" -ForegroundColor Green
Write-Host "✅ WinDivert Kernel IPS: ACTIVE" -ForegroundColor Green
Write-Host ""

cd "C:\Users\ComputerWorld\PycharmProjects\AEGIS-ADS-v11-FastAPI pro\AEGIS-ADS-v11-FastAPI"

# إيقاف العمليات القديمة
Get-Process -Name python -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

Write-Host "🚀 تشغيل AEGIS-ADS v11.0..." -ForegroundColor Cyan
Write-Host "🌐 http://localhost:9999 | admin/2005" -ForegroundColor White
Write-Host ""

uvicorn main:app --host 0.0.0.0 --port 9999
