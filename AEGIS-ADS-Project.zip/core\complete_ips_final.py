﻿"""
core/complete_ips_final.py - AEGIS-ADS FINAL COMPLETE IPS
Full AI Pipeline + Kernel Block + Device Info + No Loop
"""

import threading
import asyncio
import logging
import time
import numpy as np
import socket
import ctypes
import sys
from collections import defaultdict
from datetime import datetime

# Check admin rights on Windows
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    print("⚠️ WARNING: Not running as Administrator!")
    print("WinDivert may not work correctly. Please run as Admin.")

try:
    from scapy.all import IP, IPv6, TCP, UDP, ICMP
except ImportError:
    print("Installing scapy...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "scapy"])
    from scapy.all import IP, IPv6, TCP, UDP, ICMP

logger = logging.getLogger(__name__)

# ============================================================
# Global State
# ============================================================

blocked_ips = {}  # ip -> {timestamp, reason, attack, confidence}
blocked_flows = set()
blocked_ips_lock = threading.Lock()

flows = {}
flows_lock = threading.Lock()

# Device cache for hostname resolution
device_cache = {}

WHITELIST = {
    "127.0.0.1", "192.168.137.1", "8.8.8.8", "8.8.4.4", "192.168.43.1", "1.1.1.1"
}

# Statistics
packet_count = 0
detection_count = 0
block_count = 0
ai_calls = 0

# ============================================================
# Helper Functions
# ============================================================

def get_hostname(ip):
    """Get hostname from IP address with caching"""
    if ip in device_cache:
        return device_cache[ip]
    
    try:
        hostname = socket.gethostbyaddr(ip)[0]
        device_cache[ip] = hostname
        return hostname
    except:
        device_cache[ip] = ip
        return ip


# ============================================================
# Flow Class
# ============================================================

class Flow:
    __slots__ = ('src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                 'packets', 'bytes', 'src2dst_packets', 'src2dst_bytes',
                 'dst2src_packets', 'dst2src_bytes', 'syn_count', 'ack_count',
                 'rst_count', 'fin_count', 'first_seen', 'last_seen',
                 'packet_sizes', 'iat_times', 'last_packet_time', 'last_ai_check')
    
    def __init__(self, src_ip, dst_ip, src_port, dst_port, protocol, now):
        self.src_ip = src_ip
        self.dst_ip = dst_ip
        self.src_port = src_port
        self.dst_port = dst_port
        self.protocol = protocol
        self.packets = 1
        self.bytes = 0
        self.src2dst_packets = 0
        self.src2dst_bytes = 0
        self.dst2src_packets = 0
        self.dst2src_bytes = 0
        self.syn_count = 0
        self.ack_count = 0
        self.rst_count = 0
        self.fin_count = 0
        self.first_seen = now
        self.last_seen = now
        self.packet_sizes = []
        self.iat_times = []
        self.last_packet_time = now
        self.last_ai_check = now
    
    def get_duration(self):
        return self.last_seen - self.first_seen
    
    def get_packet_rate(self):
        dur = self.get_duration()
        return self.packets / dur if dur > 0 else 0
    
    def get_byte_rate(self):
        dur = self.get_duration()
        return self.bytes / dur if dur > 0 else 0
    
    def get_avg_packet_size(self):
        return self.bytes / self.packets if self.packets > 0 else 0


# ============================================================
# Feature Extractor (78 features)
# ============================================================

def extract_features_78(flow):
    """استخراج 78 ميزة متوافقة مع RandomForest"""
    features = []
    
    # Basic (10 features)
    features.append(float(flow.src_port))
    features.append(float(flow.dst_port))
    features.append(float(flow.protocol))
    features.append(float(flow.packets))
    features.append(float(flow.bytes))
    features.append(float(flow.src2dst_packets))
    features.append(float(flow.src2dst_bytes))
    features.append(float(flow.dst2src_packets))
    features.append(float(flow.dst2src_bytes))
    features.append(flow.get_duration() * 1000)
    
    # Packet size stats (4 features)
    if flow.packet_sizes:
        features.append(float(min(flow.packet_sizes)))
        features.append(float(max(flow.packet_sizes)))
        features.append(float(sum(flow.packet_sizes) / len(flow.packet_sizes)))
        if len(flow.packet_sizes) > 1:
            mean = features[-1]
            variance = sum((x - mean) ** 2 for x in flow.packet_sizes) / len(flow.packet_sizes)
            features.append(float(variance ** 0.5))
        else:
            features.append(0.0)
    else:
        features.extend([0.0, 0.0, 0.0, 0.0])
    
    # TCP Flags (6 features)
    features.append(float(flow.syn_count))
    features.append(float(flow.ack_count))
    features.append(float(flow.rst_count))
    features.append(float(flow.fin_count))
    
    # Rates (2 features)
    features.append(float(flow.get_packet_rate()))
    features.append(float(flow.get_byte_rate()))
    
    # Pad to 78 features
    while len(features) < 78:
        features.append(0.0)
    
    return np.array(features, dtype=np.float32).reshape(1, -1)


def extract_features_10(flow):
    """Extract 10 features for XGBoost"""
    return np.array([[
        float(flow.packets), float(flow.bytes), float(flow.get_duration()),
        float(flow.get_packet_rate()), float(flow.get_byte_rate()),
        float(flow.syn_count), float(flow.ack_count), float(flow.rst_count),
        float(flow.fin_count), float(flow.get_avg_packet_size())
    ]], dtype=np.float32)


# ============================================================
# Complete IPS Class
# ============================================================

class CompleteIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        
        self.running = False
        self.main_loop = None
        self.windivert = None
        self.model_loader = None
        self._started = False
    
    def set_loop(self, loop):
        self.main_loop = loop
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected to Complete IPS")
    
    def start(self, interface_name=None):
        global packet_count, detection_count, block_count
        
        if self._started:
            return True
        
        try:
            import pydivert
            
            logger.info("=" * 60)
            logger.info("🔥 AEGIS-ADS COMPLETE IPS FINAL STARTING")
            logger.info("=" * 60)
            
            # ✅ CRITICAL FIX: Add 'not impostor' to prevent loop
            filter_str = "ip and not loopback and not impostor"
            
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            self.running = True
            self._started = True
            
            # Reset counters
            packet_count = 0
            detection_count = 0
            block_count = 0
            
            # Start capture thread
            threading.Thread(target=self._capture_loop, daemon=True).start()
            
            # Start cleanup thread
            threading.Thread(target=self._cleanup_loop, daemon=True).start()
            
            logger.warning("🛡️ COMPLETE IPS ACTIVE - Kernel Level")
            logger.info(f"   Filter: {filter_str}")
            logger.info("   AI Pipeline: READY")
            logger.info("   Real Blocking: ENABLED")
            logger.info("   Loop Prevention: ACTIVE")
            logger.info("=" * 60)
            
            # Initial broadcast
            self._broadcast_stats()
            
            return True
            
        except Exception as e:
            logger.error(f"Complete IPS start failed: {e}")
            return False
    
    def _capture_loop(self):
        global packet_count, detection_count, block_count, ai_calls
        
        logger.info("📡 Capturing packets - AI Pipeline Active")
        
        for packet in self.windivert:
            if not self.running:
                break
            
            try:
                packet_count += 1
                
                # Extract packet info
                src_ip = packet.src_addr
                dst_ip = packet.dst_addr
                src_port = packet.src_port or 0
                dst_port = packet.dst_port or 0
                raw_data = packet.raw
                packet_size = len(raw_data)
                
                # ✅ IPv4 and IPv6 support
                scapy_pkt = None
                try:
                    scapy_pkt = IP(raw_data)
                except:
                    try:
                        scapy_pkt = IPv6(raw_data)
                    except:
                        # Not IP packet, just forward
                        self.windivert.send(packet)
                        continue
                
                # Get protocol
                protocol = 0
                if packet.tcp:
                    protocol = 6
                elif packet.udp:
                    protocol = 17
                elif packet.icmp:
                    protocol = 1
                
                # =================================================
                # CHECK BLOCKED IPs (Kernel Level Drop)
                # =================================================
                with blocked_ips_lock:
                    if src_ip in blocked_ips:
                        # ✅ KERNEL DROP - Real blocking (no send)
                        logger.debug(f"⛔ KERNEL DROP: {src_ip}")
                        continue
                    if dst_ip in blocked_ips:
                        continue
                
                # =================================================
                # FLOW MANAGEMENT
                # =================================================
                # Create bidirectional flow key
                if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
                    flow_key = (dst_ip, src_ip, dst_port, src_port, protocol)
                    direction = "dst2src"
                else:
                    flow_key = (src_ip, dst_ip, src_port, dst_port, protocol)
                    direction = "src2dst"
                
                # Check if flow is blocked
                if flow_key in blocked_flows:
                    continue
                
                now = time.time()
                
                with flows_lock:
                    if flow_key not in flows:
                        flows[flow_key] = Flow(src_ip, dst_ip, src_port, dst_port, protocol, now)
                    
                    flow = flows[flow_key]
                    flow.last_seen = now
                    flow.packets += 1
                    flow.bytes += packet_size
                    flow.packet_sizes.append(packet_size)
                    
                    # Keep only last 100 packet sizes for memory
                    if len(flow.packet_sizes) > 100:
                        flow.packet_sizes = flow.packet_sizes[-100:]
                    
                    # Inter-arrival time
                    if flow.last_packet_time > 0:
                        iat = (now - flow.last_packet_time) * 1000
                        flow.iat_times.append(iat)
                    flow.last_packet_time = now
                    
                    # Direction counters
                    if direction == "src2dst":
                        flow.src2dst_packets += 1
                        flow.src2dst_bytes += packet_size
                    else:
                        flow.dst2src_packets += 1
                        flow.dst2src_bytes += packet_size
                    
                    # TCP Flags
                    if packet.tcp:
                        if packet.tcp.syn:
                            flow.syn_count += 1
                        if packet.tcp.ack:
                            flow.ack_count += 1
                        if packet.tcp.rst:
                            flow.rst_count += 1
                        if packet.tcp.fin:
                            flow.fin_count += 1
                
                # =================================================
                # AI PIPELINE - Rate limited check
                # =================================================
                # ✅ Check if enough packets and time since last check
                if flow.packets >= 5 and (now - flow.last_ai_check) > 1.0:
                    with flows_lock:
                        flow.last_ai_check = now
                    self._run_ai_pipeline(flow, flow_key)
                
                # =================================================
                # ALLOW PACKET (send back to network)
                # =================================================
                self.windivert.send(packet)
                
                # Update dashboard every 100 packets
                if packet_count % 100 == 0:
                    self._broadcast_stats()
                    
            except Exception as e:
                logger.error(f"Packet error: {e}")
                try:
                    self.windivert.send(packet)
                except:
                    pass
    
    def _run_ai_pipeline(self, flow, flow_key):
        global detection_count, block_count, ai_calls
        
        if not self.model_loader:
            return
        
        try:
            ai_calls += 1
            
            # Extract features
            features_78 = extract_features_78(flow)
            
            # L1: RandomForest
            result = self.model_loader.predict_l1(features_78)
            
            # Handle different return types
            if isinstance(result, tuple):
                is_attack, confidence = result
            elif isinstance(result, (np.ndarray, list)):
                is_attack = bool(result[0]) if len(result) > 0 else False
                confidence = float(result[1]) if len(result) > 1 else 0.0
            else:
                is_attack = bool(result)
                confidence = 0.0
            
            if not is_attack:
                return
            
            logger.info(f"[L1] Suspicious: {flow.src_ip} ({confidence:.1f}%)")
            
            # L2: XGBoost
            features_10 = extract_features_10(flow)
            l2_result = self.model_loader.predict_l2(features_10)
            
            if isinstance(l2_result, dict):
                attack_type = l2_result.get('attack_type', 'Unknown')
                l2_confidence = l2_result.get('confidence', 0)
            else:
                attack_type = str(l2_result)
                l2_confidence = 0.0
            
            if l2_confidence < 50:
                return
            
            logger.warning(f"[L2] Attack: {attack_type} ({l2_confidence:.1f}%)")
            
            # L3: Deep Learning
            l3_result = self.model_loader.predict_l3(None)
            
            # =================================================
            # FINAL DECISION - KERNEL BLOCK
            # =================================================
            detection_count += 1
            block_count += 1
            
            # Block the IP with details
            with blocked_ips_lock:
                blocked_ips[flow.src_ip] = {
                    "timestamp": time.time(),
                    "reason": attack_type,
                    "attack": attack_type,
                    "confidence": l2_confidence,
                    "packets": flow.packets,
                    "bytes": flow.bytes
                }
            
            # Block the flow
            blocked_flows.add(flow_key)
            
            logger.warning(f"🚨 BLOCKED: {flow.src_ip}")
            logger.warning(f"   Attack: {attack_type}")
            logger.warning(f"   Confidence: {l2_confidence:.1f}%")
            logger.warning(f"   Packets: {flow.packets} | Bytes: {flow.bytes}")
            
            # Broadcast alert
            self._broadcast_alert(flow.src_ip, flow.dst_ip, attack_type, l2_confidence)
            
            # Update stats
            self._broadcast_stats()
            
        except Exception as e:
            logger.error(f"AI Pipeline error: {e}")
    
    def _cleanup_loop(self):
        """Remove old flows and auto-unblock old IPs"""
        while self.running:
            time.sleep(30)
            now = time.time()
            
            # Clean old flows
            with flows_lock:
                old_keys = [k for k, f in flows.items() if now - f.last_seen > 60]
                for k in old_keys:
                    del flows[k]
                if old_keys:
                    logger.debug(f"Cleaned {len(old_keys)} flows")
            
            # Auto-unblock old IPs (after 5 minutes)
            with blocked_ips_lock:
                old_ips = [ip for ip, data in blocked_ips.items() 
                          if now - data["timestamp"] > 300]  # 5 minutes
                for ip in old_ips:
                    del blocked_ips[ip]
                    logger.info(f"[AUTO-UNBLOCK] {ip}")
    
    def _broadcast_stats(self):
        """Broadcast to dashboard"""
        global packet_count, detection_count, block_count
        
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            data = {
                "type": "stats",
                "packets": packet_count,
                "detections": detection_count,
                "blocks": block_count,
                "blocked_ips_count": len(blocked_ips)
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except Exception as e:
            logger.debug(f"Broadcast error: {e}")
    
    def _broadcast_alert(self, src_ip, dst_ip, attack_type, confidence):
        """Broadcast alert to dashboard"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "attack_type": attack_type,
                "severity": "CRITICAL",
                "confidence": confidence,
                "hostname": get_hostname(src_ip)
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def stop(self):
        self.running = False
        self._started = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("🛑 Complete IPS Stopped")
    
    def block_ip(self, ip, reason="Manual"):
        if not ip or ip == "undefined" or ip == "-" or ip == "None":
            logger.warning(f"[BLOCK] Invalid IP: {ip}")
            return False
        
        if ip in WHITELIST:
            logger.warning(f"[BLOCK] Cannot block whitelisted IP: {ip}")
            return False
        
        global block_count, detection_count
        
        with blocked_ips_lock:
            if ip not in blocked_ips:
                blocked_ips[ip] = {
                    "timestamp": time.time(),
                    "reason": reason,
                    "attack": "MANUAL_BLOCK",
                    "confidence": 100,
                    "packets": 0,
                    "bytes": 0
                }
                block_count += 1
                detection_count += 1
                logger.warning(f"✅ [MANUAL BLOCK] {ip} - {reason}")
                self._broadcast_stats()
                self._broadcast_alert(ip, "manual", "MANUAL_BLOCK", 100)
                return True
        return False
    
    def unblock_ip(self, ip):
        with blocked_ips_lock:
            if ip in blocked_ips:
                del blocked_ips[ip]
                logger.info(f"[UNBLOCK] {ip}")
                return True
        return False
    
    def get_blocked_ips(self):
        with blocked_ips_lock:
            return list(blocked_ips.keys())
    
    def get_stats(self):
        global packet_count, detection_count, block_count, ai_calls
        
        with blocked_ips_lock:
            return {
                "total_packets": packet_count,
                "detections": detection_count,
                "blocks": block_count,
                "blocked_ips": len(blocked_ips),
                "active_flows": len(flows),
                "ai_calls": ai_calls,
                "is_running": self.running
            }


def get_ips():
    return CompleteIPS()
