﻿"""
core/feature_extractor.py - 78 Features CICIDS2017 Compatible
"""

import numpy as np
import logging

logger = logging.getLogger(__name__)

# 78 feature names as defined in features.pkl
FEATURE_NAMES = [
    'Destination Port', 'Flow Duration', 'Total Fwd Packets', 'Total Backward Packets',
    'Total Length of Fwd Packets', 'Total Length of Bwd Packets', 'Fwd Packet Length Max',
    'Fwd Packet Length Min', 'Fwd Packet Length Mean', 'Fwd Packet Length Std',
    'Bwd Packet Length Max', 'Bwd Packet Length Min', 'Bwd Packet Length Mean',
    'Bwd Packet Length Std', 'Flow Bytes/s', 'Flow Packets/s', 'Flow IAT Mean',
    'Flow IAT Std', 'Flow IAT Max', 'Flow IAT Min', 'Fwd IAT Total', 'Fwd IAT Mean',
    'Fwd IAT Std', 'Fwd IAT Max', 'Fwd IAT Min', 'Bwd IAT Total', 'Bwd IAT Mean',
    'Bwd IAT Std', 'Bwd IAT Max', 'Bwd IAT Min', 'Fwd PSH Flags', 'Bwd PSH Flags',
    'Fwd URG Flags', 'Bwd URG Flags', 'Fwd Header Length', 'Bwd Header Length',
    'Fwd Packets/s', 'Bwd Packets/s', 'Min Packet Length', 'Max Packet Length',
    'Packet Length Mean', 'Packet Length Std', 'Packet Length Variance', 'FIN Flag Count',
    'SYN Flag Count', 'RST Flag Count', 'PSH Flag Count', 'ACK Flag Count', 'URG Flag Count',
    'CWE Flag Count', 'ECE Flag Count', 'Down/Up Ratio', 'Average Packet Size',
    'Avg Fwd Segment Size', 'Avg Bwd Segment Size', 'Fwd Header Length.1',
    'Fwd Avg Bytes/Bulk', 'Fwd Avg Packets/Bulk', 'Fwd Avg Bulk Rate',
    'Bwd Avg Bytes/Bulk', 'Bwd Avg Packets/Bulk', 'Bwd Avg Bulk Rate',
    'Subflow Fwd Packets', 'Subflow Fwd Bytes', 'Subflow Bwd Packets', 'Subflow Bwd Bytes',
    'Init_Win_bytes_forward', 'Init_Win_bytes_backward', 'act_data_pkt_fwd',
    'min_seg_size_forward', 'Active Mean', 'Active Std', 'Active Max', 'Active Min',
    'Idle Mean', 'Idle Std', 'Idle Max', 'Idle Min'
]


class FeatureExtractor:
    """Extract 78 CICIDS-compatible features from flow data"""
    
    def __init__(self):
        self.feature_names = FEATURE_NAMES
    
    def extract_from_flow(self, flow):
        """
        Extract 78 features from flow dictionary
        
        Args:
            flow: dict with keys (packets, bytes, duration_ms, icmp_count, syn_count,
                   packet_sizes, src_port, dst_port, protocol)
        
        Returns:
            np.array of shape (1, 78)
        """
        features = np.zeros(78, dtype=np.float32)
        
        # Basic features (indices 0-9)
        features[0] = flow.get('dst_port', 0)  # Destination Port
        features[1] = flow.get('duration_ms', 0)  # Flow Duration
        features[2] = flow.get('packets', 0)  # Total Fwd Packets
        features[3] = 0  # Total Backward Packets (simplified)
        features[4] = flow.get('bytes', 0)  # Total Length of Fwd Packets
        features[5] = 0  # Total Length of Bwd Packets
        
        # Packet size stats
        packet_sizes = flow.get('packet_sizes', [])
        if packet_sizes:
            features[6] = max(packet_sizes)  # Fwd Packet Length Max
            features[7] = min(packet_sizes)  # Fwd Packet Length Min
            features[8] = sum(packet_sizes) / len(packet_sizes)  # Mean
            if len(packet_sizes) > 1:
                variance = sum((x - features[8]) ** 2 for x in packet_sizes) / len(packet_sizes)
                features[9] = variance ** 0.5  # Std
        
        # Flow rates (indices 14-15)
        duration_sec = flow.get('duration_ms', 1) / 1000
        features[14] = flow.get('bytes', 0) / duration_sec if duration_sec > 0 else 0  # Flow Bytes/s
        features[15] = flow.get('packets', 0) / duration_sec if duration_sec > 0 else 0  # Flow Packets/s
        
        # TCP Flags (indices 44-48)
        features[44] = 0  # FIN Flag Count
        features[45] = flow.get('syn_count', 0)  # SYN Flag Count
        features[46] = 0  # RST Flag Count
        features[47] = 0  # PSH Flag Count
        features[48] = 0  # ACK Flag Count
        
        # Other
        features[52] = flow.get('avg_packet_size', 0)  # Average Packet Size
        features[53] = flow.get('avg_packet_size', 0)  # Avg Fwd Segment Size
        
        return features.reshape(1, -1)
    
    def extract_10_features_for_xgb(self, flow):
        """Extract 10 features for XGBoost"""
        duration_sec = flow.get('duration_ms', 1) / 1000
        packet_rate = flow.get('packets', 0) / duration_sec if duration_sec > 0 else 0
        byte_rate = flow.get('bytes', 0) / duration_sec if duration_sec > 0 else 0
        
        return np.array([[
            float(flow.get('packets', 0)),
            float(flow.get('bytes', 0)),
            float(flow.get('duration_ms', 0)),
            float(packet_rate),
            float(byte_rate),
            float(flow.get('icmp_count', 0)),
            float(flow.get('syn_count', 0)),
            0.0,  # ack_count
            0.0,  # rst_count
            float(flow.get('avg_packet_size', 0))
        ]], dtype=np.float32)


def get_feature_extractor():
    return FeatureExtractor()
