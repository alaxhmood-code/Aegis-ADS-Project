﻿"""
Unified Model Loader - Loads ALL models (RF + XGBoost + Deep Learning)
Handles: .pkl, .json, .safetensors formats
"""
import os, json, logging
import joblib, numpy as np

logger = logging.getLogger(__name__)

class UnifiedModelLoader:
    """Loads and manages all AI models"""
    
    def __init__(self, models_dir='models'):
        self.models_dir = models_dir
        
        # Classic ML models
        self.rf_model = None          # L1: Random Forest (78 features)
        self.xgb_model = None         # L2: XGBoost (10 features)
        self.dl_model = None          # L3: Deep Learning (safetensors)
        
        # Scalers
        self.aegis_scaler = None      # StandardScaler (78)
        self.minmax_scaler = None     # MinMaxScaler (10)
        
        # Encoders & config
        self.label_encoder = None
        self.threshold = 0.3
        self.feature_names = None
        self.attack_types = None
        self.tokenizer = None
        
        # Load all
        self.load_all()
    
    def load_all(self):
        """Load all models with error handling"""
        models = {
            'rf_model': ('aegis_ids_rf_model.pkl', 'L1 Random Forest'),
            'xgb_model': ('xgb_classifier.pkl', 'L2 XGBoost'),
            'aegis_scaler': ('aegis_ids_scaler.pkl', 'StandardScaler (78)'),
            'minmax_scaler': ('scaler.pkl', 'MinMaxScaler (10)'),
            'label_encoder': ('label_encoder.pkl', 'Label Encoder'),
            'feature_names': ('features.pkl', 'Feature Names'),
            'attack_types': ('attack_types.pkl', 'Attack Types'),
            'threshold': ('threshold.pkl', 'Threshold'),
        }
        
        for attr, (filename, desc) in models.items():
            path = os.path.join(self.models_dir, filename)
            try:
                if os.path.exists(path) and os.path.getsize(path) > 100:
                    setattr(self, attr, joblib.load(path))
                    logger.info(f"✅ {desc} loaded")
                else:
                    logger.warning(f"⚠️ {desc} file too small or missing: {path}")
            except Exception as e:
                logger.error(f"❌ Failed to load {desc}: {e}")
        
        # Deep Learning model
        self._load_deep_learning()
        
        # Tokenizer
        self._load_tokenizer()
        
        # Summary
        logger.info(f"📊 Models ready: RF={self.rf_model is not None}, XGB={self.xgb_model is not None}, DL={self.dl_model is not None}")
    
    def _load_deep_learning(self):
        """Load safetensors Deep Learning model"""
        try:
            from safetensors import safe_open
            path = os.path.join(self.models_dir, 'model.safetensors')
            if os.path.exists(path) and os.path.getsize(path) > 1000000:  # > 1MB
                tensors = {}
                with safe_open(path, framework="pt") as f:
                    for key in f.keys():
                        tensors[key] = f.get_tensor(key)
                self.dl_model = tensors
                logger.info(f"✅ Deep Learning model loaded ({len(tensors)} tensors, {os.path.getsize(path)/1024/1024:.1f} MB)")
        except ImportError:
            logger.warning("⚠️ safetensors not installed, DL model skipped")
        except Exception as e:
            logger.warning(f"⚠️ DL model not loaded: {e}")
    
    def _load_tokenizer(self):
        """Load tokenizer config"""
        try:
            path = os.path.join(self.models_dir, 'tokenizer_config.json')
            if os.path.exists(path):
                with open(path) as f:
                    self.tokenizer = json.load(f)
                logger.info("✅ Tokenizer loaded")
        except:
            pass
    
    @property
    def is_ready(self):
        return self.rf_model is not None and self.xgb_model is not None
    
    def predict_l1(self, features_78: np.ndarray):
        """
        Layer 1: Random Forest Binary Classification
        Returns: (is_attack: bool, confidence: float)
        """
        if self.rf_model is None:
            return False, 0.0
        try:
            if self.aegis_scaler:
                features_78 = self.aegis_scaler.transform(features_78)
            probs = self.rf_model.predict_proba(features_78)[0]
            is_attack = len(probs) > 1 and probs[1] > 0.3
            return is_attack, float(max(probs)) * 100
        except Exception as e:
            logger.error(f"L1 prediction error: {e}")
            return False, 0.0
    
    def predict_l2(self, features_10: np.ndarray):
        """
        Layer 2: XGBoost Attack Classification
        Returns: dict with attack_type and confidence
        """
        if self.xgb_model is None:
            return {"attack_type": "Unknown", "confidence": 0.0}
        try:
            if self.minmax_scaler:
                features_10 = self.minmax_scaler.transform(features_10)
            pred = int(self.xgb_model.predict(features_10)[0])
            probs = self.xgb_model.predict_proba(features_10)[0]
            confidence = float(max(probs)) * 100
            
            attack_name = "Unknown"
            if self.label_encoder:
                try:
                    attack_name = str(self.label_encoder.inverse_transform([pred])[0])
                except:
                    attack_name = str(pred)
            
            if attack_name.upper() == "BENIGN":
                attack_name = "Normal"
            
            return {"attack_type": attack_name, "confidence": confidence}
        except Exception as e:
            logger.error(f"L2 prediction error: {e}")
            return {"attack_type": "Error", "confidence": 0.0}
    
    def predict_l3(self, features):
        """
        Layer 3: Deep Learning Analysis
        """
        if self.dl_model is None:
            return {"dl_analysis": "unavailable"}
        try:
            return {"dl_analysis": "model_loaded", "tensors": len(self.dl_model)}
        except:
            return {"dl_analysis": "error"}
    
    def get_status(self):
        return {
            "rf_model": self.rf_model is not None,
            "xgb_model": self.xgb_model is not None,
            "dl_model": self.dl_model is not None,
            "aegis_scaler": self.aegis_scaler is not None,
            "minmax_scaler": self.minmax_scaler is not None,
            "label_encoder": self.label_encoder is not None,
            "threshold": str(self.threshold),
            "attack_types_count": len(self.attack_types) if self.attack_types else 0
        }


