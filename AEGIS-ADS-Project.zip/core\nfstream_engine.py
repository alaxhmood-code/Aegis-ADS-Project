﻿"""
core/nfstream_engine.py - Advanced NFStream Engine for Real IPS
"""

import threading
import time
import logging
from collections import defaultdict
import numpy as np

logger = logging.getLogger(__name__)

class AdvancedNFStreamEngine:
    """Advanced NFStream-based flow feature extraction"""
    
    def __init__(self):
        self.flows = defaultdict(lambda: {
            'packets': 0,
            'bytes': 0,
            'src_port': 0,
            'dst_port': 0,
            'protocol': 0,
            'bidirectional_packets': 0,
            'bidirectional_bytes': 0,
            'src2dst_packets': 0,
            'src2dst_bytes': 0,
            'dst2src_packets': 0,
            'dst2src_bytes': 0,
            'min_ps': 0,
            'max_ps': 0,
            'mean_ps': 0,
            'stddev_ps': 0,
            'first_seen': 0,
            'last_seen': 0,
            'duration': 0,
            'syn_count': 0,
            'ack_count': 0,
            'rst_count': 0,
            'fin_count': 0,
            'urg_count': 0,
            'psh_count': 0,
            'is_anomaly': False,
            'attack_score': 0,
            'attack_type': 'NORMAL',
            'threat_level': 'LOW'
        })
        self.callbacks = []
        self.lock = threading.Lock()
        
    def update_flow(self, packet):
        """Update flow with packet data - Thread safe"""
        try:
            src = packet.src_addr
            dst = packet.dst_addr
            sport = getattr(packet, 'src_port', 0)
            dport = getattr(packet, 'dst_port', 0)
            proto = getattr(packet, 'protocol', 'UNKNOWN')
            length = getattr(packet, 'length', 64)
            now = time.time()
            
            # Create flow key (bidirectional)
            if src > dst:
                key = f"{dst}:{dport}-{src}:{sport}"
            else:
                key = f"{src}:{sport}-{dst}:{dport}"
            
            with self.lock:
                flow = self.flows[key]
                
                # Initialize if new flow
                if flow['first_seen'] == 0:
                    flow['first_seen'] = now
                    flow['src_port'] = sport
                    flow['dst_port'] = dport
                    flow['protocol'] = proto
                
                # Update counters
                flow['packets'] += 1
                flow['bytes'] += length
                flow['last_seen'] = now
                flow['duration'] = now - flow['first_seen']
                
                # Direction-specific counters
                if src == key.split('-')[0].split(':')[0]:
                    flow['src2dst_packets'] += 1
                    flow['src2dst_bytes'] += length
                else:
                    flow['dst2src_packets'] += 1
                    flow['dst2src_bytes'] += length
                
                # Bidirectional
                flow['bidirectional_packets'] = flow['src2dst_packets'] + flow['dst2src_packets']
                flow['bidirectional_bytes'] = flow['src2dst_bytes'] + flow['dst2src_bytes']
                
                # TCP flags
                if hasattr(packet, 'tcp') and packet.tcp:
                    if packet.tcp.syn:
                        flow['syn_count'] += 1
                    if packet.tcp.ack:
                        flow['ack_count'] += 1
                    if packet.tcp.rst:
                        flow['rst_count'] += 1
                    if packet.tcp.fin:
                        flow['fin_count'] += 1
                    if packet.tcp.urg:
                        flow['urg_count'] += 1
                    if packet.tcp.psh:
                        flow['psh_count'] += 1
                
                # Packet size stats
                if flow['packets'] == 1:
                    flow['min_ps'] = length
                    flow['max_ps'] = length
                    flow['mean_ps'] = length
                else:
                    flow['min_ps'] = min(flow['min_ps'], length)
                    flow['max_ps'] = max(flow['max_ps'], length)
                    flow['mean_ps'] = (flow['mean_ps'] * (flow['packets'] - 1) + length) / flow['packets']
                
                # Calculate real-time attack score
                flow['attack_score'], flow['attack_type'], flow['threat_level'] = self._calculate_attack_metrics(flow)
                flow['is_anomaly'] = flow['attack_score'] > 25
                
                # Call callbacks for anomaly detection
                if flow['is_anomaly']:
                    for callback in self.callbacks:
                        try:
                            callback(key, flow)
                        except:
                            pass
                
                return flow
                
        except Exception as e:
            logger.error(f"NFStream update error: {e}")
            return None
    
    def _calculate_attack_metrics(self, flow):
        """Calculate comprehensive attack metrics"""
        score = 0
        attack_type = "NORMAL"
        threat_level = "LOW"
        
                # 1. DDoS / Flood Detection - مع معايير أكثر صرامة
        if flow['duration'] > 0:
            packet_rate = flow['packets'] / max(flow['duration'], 0.001)
            # فقط إذا كان المعدل مرتفعاً جداً والمدة قصيرة
            if packet_rate > 300 and flow['duration'] < 2:
                score += 60
                attack_type = "DDOS_FLOOD"
                threat_level = "CRITICAL"
            elif packet_rate > 150 and flow['duration'] < 3:
                score += 40
                attack_type = "HIGH_TRAFFIC"
                threat_level = "HIGH"
        
        # 2. SYN Flood Detection - مع SYN ratio
        if flow['packets'] > 30:
            syn_ratio = flow['syn_count'] / flow['packets']
            if syn_ratio > 0.7 and flow['duration'] < 5:
                score += 55
                attack_type = "SYN_FLOOD"
                threat_level = "CRITICAL"
            elif syn_ratio > 0.5:
                score += 30
                attack_type = "SYN_SCAN"
                threat_level = "MEDIUM"
        
        # 3. Port Scan Detection
        if flow['bidirectional_packets'] < 10 and flow['packets'] > 25:
            score += 45
            attack_type = "PORT_SCAN"
            threat_level = "HIGH"
        
        # 4. ICMP Flood - فقط لبروتوكول ICMP
        if flow['protocol'] == 'ICMP' and flow['packets'] > 100 and flow['duration'] < 2:
            score += 65
            attack_type = "ICMP_FLOOD"
            threat_level = "CRITICAL"
        if flow['dst_port'] in [22, 23, 3389, 21, 1433, 3306] and flow['packets'] > 30:
            score += 35
            attack_type = "BRUTE_FORCE"
            threat_level = "HIGH"
        
        return min(100, score), attack_type, threat_level
    
    def register_callback(self, callback):
        """Register callback for anomaly detection"""
        self.callbacks.append(callback)
    
    def cleanup_old_flows(self, timeout=60):
        """Remove old flows"""
        now = time.time()
        with self.lock:
            to_delete = []
            for key, flow in self.flows.items():
                if now - flow['last_seen'] > timeout:
                    to_delete.append(key)
            for key in to_delete:
                del self.flows[key]
            if to_delete:
                logger.debug(f"Cleaned up {len(to_delete)} old flows")
    
    def get_active_flows_count(self):
        with self.lock:
            return len(self.flows)

_nfstream_engine = None

def get_nfstream_engine():
    global _nfstream_engine
    if _nfstream_engine is None:
        _nfstream_engine = AdvancedNFStreamEngine()
    return _nfstream_engine

