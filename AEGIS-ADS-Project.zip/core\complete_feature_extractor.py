﻿"""
core/complete_feature_extractor.py - 78 CICIDS2017 Features
"""

import numpy as np
import logging

logger = logging.getLogger(__name__)

FEATURE_NAMES = [f'Feature_{i}' for i in range(78)]


class CompleteFeatureExtractor:
    def __init__(self):
        self.feature_names = FEATURE_NAMES
    
    def extract_from_flow(self, flow_stats):
        features = np.zeros(78, dtype=np.float32)
        
        # Basic
        features[0] = flow_stats.get('dst_port', 0)
        features[1] = flow_stats.get('duration_ms', 0)
        features[2] = flow_stats.get('fwd_packets', 0)
        features[3] = flow_stats.get('bwd_packets', 0)
        features[4] = flow_stats.get('fwd_bytes', 0)
        features[5] = flow_stats.get('bwd_bytes', 0)
        
        # Packet size stats
        fwd_sizes = flow_stats.get('fwd_packet_sizes', [])
        if fwd_sizes:
            features[6] = max(fwd_sizes)
            features[7] = min(fwd_sizes)
            features[8] = sum(fwd_sizes) / len(fwd_sizes)
            if len(fwd_sizes) > 1:
                mean = features[8]
                variance = sum((x - mean) ** 2 for x in fwd_sizes) / len(fwd_sizes)
                features[9] = variance ** 0.5
        
        bwd_sizes = flow_stats.get('bwd_packet_sizes', [])
        if bwd_sizes:
            features[10] = max(bwd_sizes)
            features[11] = min(bwd_sizes)
            features[12] = sum(bwd_sizes) / len(bwd_sizes)
            if len(bwd_sizes) > 1:
                mean = features[12]
                variance = sum((x - mean) ** 2 for x in bwd_sizes) / len(bwd_sizes)
                features[13] = variance ** 0.5
        
        # TCP Flags
        features[44] = flow_stats.get('syn_count', 0)
        features[45] = flow_stats.get('ack_count', 0)
        features[46] = flow_stats.get('rst_count', 0)
        features[47] = flow_stats.get('fin_count', 0)
        
        return features.reshape(1, -1)
    
    def extract_10_features_fallback(self, flow_stats):
        duration = flow_stats.get('duration_ms', 1) / 1000
        total_packets = flow_stats.get('packets', 0)
        total_bytes = flow_stats.get('bytes', 0)
        packet_rate = total_packets / duration if duration > 0 else 0
        byte_rate = total_bytes / duration if duration > 0 else 0
        avg_packet_size = total_bytes / total_packets if total_packets > 0 else 0
        
        return np.array([[
            float(total_packets),
            float(total_bytes),
            float(flow_stats.get('duration_ms', 0)),
            float(packet_rate),
            float(byte_rate),
            float(flow_stats.get('icmp_count', 0)),
            float(flow_stats.get('syn_count', 0)),
            float(flow_stats.get('ack_count', 0)),
            float(flow_stats.get('rst_count', 0)),
            float(avg_packet_size)
        ]], dtype=np.float32)


def get_feature_extractor():
    """Create FeatureExtractor instance"""
    return CompleteFeatureExtractor()
