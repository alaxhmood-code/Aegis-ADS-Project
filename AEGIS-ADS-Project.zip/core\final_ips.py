﻿"""
core/final_ips.py - AEGIS-ADS FINAL IPS - FIXED VERSION
"""

import threading
import asyncio
import logging
import time
import numpy as np
from collections import defaultdict
from datetime import datetime

logger = logging.getLogger(__name__)

# ============================================================
# Global State
# ============================================================

blocked_ips = set()
blocked_flows = set()
blocked_ips_lock = threading.Lock()

flows = {}
flows_lock = threading.Lock()

WHITELIST = {
    "127.0.0.1", "192.168.137.1", "8.8.8.8", "8.8.4.4"
}

# ============================================================
# Flow Class
# ============================================================

class Flow:
    __slots__ = ('src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                 'packets', 'bytes', 'src2dst_packets', 'src2dst_bytes',
                 'dst2src_packets', 'dst2src_bytes', 'syn_count', 'ack_count',
                 'rst_count', 'fin_count', 'first_seen', 'last_seen',
                 'packet_sizes', 'iat_times', 'last_packet_time')
    
    def __init__(self, src_ip, dst_ip, src_port, dst_port, protocol, now):
        self.src_ip = src_ip
        self.dst_ip = dst_ip
        self.src_port = src_port
        self.dst_port = dst_port
        self.protocol = protocol
        self.packets = 1
        self.bytes = 0
        self.src2dst_packets = 0
        self.src2dst_bytes = 0
        self.dst2src_packets = 0
        self.dst2src_bytes = 0
        self.syn_count = 0
        self.ack_count = 0
        self.rst_count = 0
        self.fin_count = 0
        self.first_seen = now
        self.last_seen = now
        self.packet_sizes = []
        self.iat_times = []
        self.last_packet_time = now
    
    def get_key(self):
        return (self.src_ip, self.dst_ip, self.src_port, self.dst_port, self.protocol)
    
    def get_duration(self):
        return self.last_seen - self.first_seen
    
    def get_packet_rate(self):
        dur = self.get_duration()
        return self.packets / dur if dur > 0 else 0
    
    def get_byte_rate(self):
        dur = self.get_duration()
        return self.bytes / dur if dur > 0 else 0
    
    def get_avg_packet_size(self):
        return self.bytes / self.packets if self.packets > 0 else 0


# ============================================================
# Feature Extractor (78 features)
# ============================================================

def extract_features_78(flow):
    """استخراج 78 ميزة متوافقة مع RandomForest"""
    features = []
    
    # Basic (10 features)
    features.append(float(flow.src_port))
    features.append(float(flow.dst_port))
    features.append(float(flow.protocol))
    features.append(float(flow.packets))
    features.append(float(flow.bytes))
    features.append(float(flow.src2dst_packets))
    features.append(float(flow.src2dst_bytes))
    features.append(float(flow.dst2src_packets))
    features.append(float(flow.dst2src_bytes))
    features.append(flow.get_duration() * 1000)
    
    # Packet size stats (4 features)
    if flow.packet_sizes:
        features.append(float(min(flow.packet_sizes)))
        features.append(float(max(flow.packet_sizes)))
        features.append(float(sum(flow.packet_sizes) / len(flow.packet_sizes)))
        if len(flow.packet_sizes) > 1:
            mean = features[-1]
            variance = sum((x - mean) ** 2 for x in flow.packet_sizes) / len(flow.packet_sizes)
            features.append(float(variance ** 0.5))
        else:
            features.append(0.0)
    else:
        features.extend([0.0, 0.0, 0.0, 0.0])
    
    # TCP Flags (6 features)
    features.append(float(flow.syn_count))
    features.append(float(flow.ack_count))
    features.append(float(flow.rst_count))
    features.append(float(flow.fin_count))
    
    # Rates (2 features)
    features.append(float(flow.get_packet_rate()))
    features.append(float(flow.get_byte_rate()))
    
    # Pad to 78 features
    while len(features) < 78:
        features.append(0.0)
    
    return np.array(features, dtype=np.float32).reshape(1, -1)


# ============================================================
# Final IPS Class
# ============================================================

class FinalIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        
        self.running = False
        self.packet_count = 0
        self.detection_count = 0
        self.block_count = 0
        self.ai_calls = 0
        self.error_count = 0
        
        self.main_loop = None
        self.windivert = None
        self.model_loader = None
        
        self._started = False
    
    def set_loop(self, loop):
        self.main_loop = loop
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected to Final IPS")
    
    def start(self, interface_name=None):
        if self._started:
            return True
        
        try:
            import pydivert
            
            logger.info("=" * 60)
            logger.info("🔥 AEGIS-ADS FINAL IPS STARTING")
            logger.info("=" * 60)
            
            # Filter: capture all IP traffic except loopback
            filter_str = "ip and not loopback"
            
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            self.running = True
            self._started = True
            
            # Start capture thread
            threading.Thread(target=self._capture_loop, daemon=True).start()
            
            # Start cleanup thread
            threading.Thread(target=self._cleanup_loop, daemon=True).start()
            
            logger.warning("🛡️ FINAL IPS ACTIVE - Kernel Level")
            logger.info(f"   Filter: {filter_str}")
            logger.info("   AI Pipeline: READY")
            logger.info("   Real Blocking: ENABLED")
            logger.info("=" * 60)
            
            return True
            
        except Exception as e:
            logger.error(f"Final IPS start failed: {e}")
            return False
    
    def _capture_loop(self):
        """Main packet capture with AI processing"""
        logger.info("📡 Capturing packets - AI Pipeline Active")
        
        for packet in self.windivert:
            if not self.running:
                break
            
            try:
                self.packet_count += 1
                
                src_ip = packet.src_addr
                dst_ip = packet.dst_addr
                src_port = packet.src_port or 0
                dst_port = packet.dst_port or 0
                
                # ✅ FIX: Use packet.raw for size, not len(packet)
                packet_size = len(packet.raw)
                
                # Get protocol
                protocol = 0
                if packet.tcp:
                    protocol = 6
                elif packet.udp:
                    protocol = 17
                elif packet.icmp:
                    protocol = 1
                
                # =================================================
                # CHECK BLOCKED IPs (Kernel Level)
                # =================================================
                with blocked_ips_lock:
                    if src_ip in blocked_ips or dst_ip in blocked_ips:
                        # DROP PACKET - Real Kernel Block
                        continue
                
                # =================================================
                # FLOW MANAGEMENT
                # =================================================
                # Create bidirectional flow key
                if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
                    flow_key = (dst_ip, src_ip, dst_port, src_port, protocol)
                    direction = "dst2src"
                else:
                    flow_key = (src_ip, dst_ip, src_port, dst_port, protocol)
                    direction = "src2dst"
                
                # Check if flow is blocked
                if flow_key in blocked_flows:
                    continue
                
                now = time.time()
                
                with flows_lock:
                    if flow_key not in flows:
                        flows[flow_key] = Flow(src_ip, dst_ip, src_port, dst_port, protocol, now)
                    
                    flow = flows[flow_key]
                    flow.last_seen = now
                    flow.packets += 1
                    flow.bytes += packet_size
                    flow.packet_sizes.append(packet_size)
                    
                    # IAT calculation
                    if flow.last_packet_time > 0:
                        iat = (now - flow.last_packet_time) * 1000
                        flow.iat_times.append(iat)
                    flow.last_packet_time = now
                    
                    # Direction counters
                    if direction == "src2dst":
                        flow.src2dst_packets += 1
                        flow.src2dst_bytes += packet_size
                    else:
                        flow.dst2src_packets += 1
                        flow.dst2src_bytes += packet_size
                    
                    # TCP Flags
                    if packet.tcp:
                        if packet.tcp.syn:
                            flow.syn_count += 1
                        if packet.tcp.ack:
                            flow.ack_count += 1
                        if packet.tcp.rst:
                            flow.rst_count += 1
                        if packet.tcp.fin:
                            flow.fin_count += 1
                
                # =================================================
                # AI PIPELINE - Every 20 packets
                # =================================================
                if flow.packets % 20 == 0 and flow.packets >= 20:
                    self._run_ai_pipeline(flow, flow_key)
                
                # =================================================
                # ALLOW PACKET (if not blocked)
                # =================================================
                self.windivert.send(packet)
                
                # Update dashboard every 100 packets
                if self.packet_count % 100 == 0:
                    self._broadcast_stats()
                    
            except Exception as e:
                self.error_count += 1
                if self.error_count < 10:  # Limit log spam
                    logger.error(f"Packet error: {e}")
                try:
                    # Still send packet to avoid breaking connectivity
                    self.windivert.send(packet)
                except:
                    pass
    
    def _run_ai_pipeline(self, flow, flow_key):
        """Execute AI pipeline on flow"""
        if not self.model_loader:
            return
        
        try:
            self.ai_calls += 1
            
            # Extract 78 features for RandomForest
            features_78 = extract_features_78(flow)
            
            # =================================================
            # L1: RandomForest (Fast Binary Filter)
            # =================================================
            is_attack, confidence = self.model_loader.predict_l1(features_78)
            
            if not is_attack:
                return
            
            logger.info(f"[L1] Suspicious flow: {flow.src_ip} (confidence: {confidence:.1f}%)")
            
            # =================================================
            # L2: XGBoost (Attack Classifier)
            # =================================================
            features_10 = np.array([[
                float(flow.packets), float(flow.bytes), float(flow.get_duration()),
                float(flow.get_packet_rate()), float(flow.get_byte_rate()),
                float(flow.syn_count), float(flow.ack_count), float(flow.rst_count),
                float(flow.fin_count), float(flow.get_avg_packet_size())
            ]], dtype=np.float32)
            
            l2_result = self.model_loader.predict_l2(features_10)
            
            # Use threshold 0.5 for now (since threshold.pkl is missing)
            if l2_result['confidence'] < 50:
                return
            
            logger.warning(f"[L2] Attack detected: {l2_result['attack_type']} ({l2_result['confidence']:.1f}%)")
            
            # =================================================
            # L3: Deep Learning (Final Decision)
            # =================================================
            l3_result = self.model_loader.predict_l3(None)
            
            # =================================================
            # FINAL DECISION - KERNEL BLOCK
            # =================================================
            self.detection_count += 1
            self.block_count += 1
            
            # Block the IP
            with blocked_ips_lock:
                blocked_ips.add(flow.src_ip)
            
            # Block the flow
            blocked_flows.add(flow_key)
            
            logger.warning(f"🚨 FINAL DECISION: BLOCK {flow.src_ip}")
            logger.warning(f"   Attack: {l2_result['attack_type']}")
            logger.warning(f"   Confidence: {l2_result['confidence']:.1f}%")
            logger.warning(f"   Packets: {flow.packets} | Bytes: {flow.bytes}")
            
            # Broadcast alert
            self._broadcast_alert(flow.src_ip, flow.dst_ip, l2_result['attack_type'], l2_result['confidence'])
            
        except Exception as e:
            logger.error(f"AI Pipeline error: {e}")
    
    def _cleanup_loop(self):
        """Remove old flows"""
        while self.running:
            time.sleep(30)
            now = time.time()
            with flows_lock:
                old_keys = [k for k, f in flows.items() if now - f.last_seen > 60]
                for k in old_keys:
                    del flows[k]
                if old_keys:
                    logger.debug(f"Cleaned {len(old_keys)} flows")
    
    def _broadcast_stats(self):
        """Broadcast to dashboard"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            data = {
                "type": "stats",
                "packets": self.packet_count,
                "detections": self.detection_count,
                "blocks": self.block_count,
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def _broadcast_alert(self, src_ip, dst_ip, attack_type, confidence):
        """Broadcast alert to dashboard"""
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            
            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "attack_type": attack_type,
                "severity": "CRITICAL",
                "confidence": confidence
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def stop(self):
        self.running = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("🛑 Final IPS Stopped")
    
    def block_ip(self, ip, reason="Manual"):
        if ip in WHITELIST:
            return False
        with blocked_ips_lock:
            if ip not in blocked_ips:
                blocked_ips.add(ip)
                self.block_count += 1
                self.detection_count += 1
                logger.warning(f"[MANUAL BLOCK] {ip} - {reason}")
                self._broadcast_stats()
                return True
        return False
    
    def unblock_ip(self, ip):
        with blocked_ips_lock:
            if ip in blocked_ips:
                blocked_ips.discard(ip)
                return True
        return False
    
    def get_blocked_ips(self):
        with blocked_ips_lock:
            return list(blocked_ips)
    
    def get_stats(self):
        with blocked_ips_lock:
            return {
                "total_packets": self.packet_count,
                "detections": self.detection_count,
                "blocks": self.block_count,
                "blocked_ips": len(blocked_ips),
                "active_flows": len(flows),
                "ai_calls": self.ai_calls,
                "is_running": self.running
            }


def get_ips():
    return FinalIPS()
