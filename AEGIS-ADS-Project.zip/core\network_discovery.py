﻿"""
core/network_discovery.py - REAL NETWORK DISCOVERY
"""

import subprocess
import re
import socket
import threading
import time


class NetworkDiscovery:

    def __init__(self):
        self.devices = {}
        self.lock = threading.Lock()

    def resolve_hostname(self, ip):
        try:
            return socket.gethostbyaddr(ip)[0]
        except:
            return ip

    def scan_network(self, force=False):

        devices = {}

        try:
            result = subprocess.run(
                "arp -a",
                capture_output=True,
                text=True,
                shell=True,
                encoding="cp1256",
                errors="ignore"
            )

            print("\n=========== ARP TABLE ===========")
            print(result.stdout)
            print("=================================\n")

            for line in result.stdout.splitlines():
                parts = line.split()

                if len(parts) < 2:
                    continue

                ip_match = re.match(r"(\d+\.\d+\.\d+\.\d+)", parts[0])

                if not ip_match:
                    continue

                ip = ip_match.group(1)

                if not ip.startswith("192.168.137."):
                    continue

                if ip in ["192.168.137.1", "192.168.137.255"]:
                    continue

                mac = parts[1]

                devices[ip] = {
                    "ip": ip,
                    "mac": mac,
                    "vendor": "Detected",
                    "hostname": self.resolve_hostname(ip),
                    "status": "active",
                    "last_seen": time.time()
                }

            with self.lock:
                self.devices = devices

            print(f"[DISCOVERY] Found {len(devices)} devices")

        except Exception as e:
            print(f"[DISCOVERY ERROR] {e}")

        return list(self.devices.values())


_discovery = None


def get_network_discovery():
    global _discovery
    if _discovery is None:
        _discovery = NetworkDiscovery()
    return _discovery
