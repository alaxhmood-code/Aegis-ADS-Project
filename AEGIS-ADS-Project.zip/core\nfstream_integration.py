﻿"""
core/nfstream_integration.py - NFStream Live Flow Engine for AEGIS-ADS
"""
import threading
import time
import logging
import numpy as np
from collections import defaultdict
from datetime import datetime

logger = logging.getLogger(__name__)

class NFStreamIntegration:
    """يدير التدفقات الحية ويستخرج 78 ميزة حقيقية"""
    
    def __init__(self, model_loader):
        self.model_loader = model_loader
        self.flows = {}
        self.lock = threading.Lock()
        self.packet_count = 0
        self.detection_count = 0
        self.block_count = 0
        self.main_loop = None
        self.ws_callback = None
        
        # قائمة الاستثناءات الآمنة
        self.whitelist = {"192.168.137.1", "127.0.0.1", "192.168.1.1", "8.8.8.8", "8.8.4.4"}
        
    def set_loop(self, loop):
        """تمرير Event Loop الرئيسي لـ FastAPI"""
        self.main_loop = loop
        
    def set_ws_callback(self, callback):
        """تعيين دالة إرسال للـ WebSocket"""
        self.ws_callback = callback
        
    def extract_78_features(self, flow):
        """استخراج 78 ميزة من NFStream Flow"""
        try:
            features = [
                flow.get('src_port', 0), flow.get('dst_port', 0), flow.get('protocol', 0),
                flow.get('duration', 0), flow.get('packets', 0), flow.get('bytes', 0),
                flow.get('src2dst_packets', 0), flow.get('src2dst_bytes', 0),
                flow.get('dst2src_packets', 0), flow.get('dst2src_bytes', 0),
                flow.get('min_ps', 0), flow.get('max_ps', 0), flow.get('mean_ps', 0), flow.get('stddev_ps', 0),
                flow.get('min_piat', 0), flow.get('max_piat', 0), flow.get('mean_piat', 0), flow.get('stddev_piat', 0),
                flow.get('syn_count', 0), flow.get('ack_count', 0), flow.get('rst_count', 0),
                flow.get('fin_count', 0), flow.get('urg_count', 0), flow.get('psh_count', 0)
            ]
            # Padding to 78 features
            while len(features) < 78:
                features.append(0.0)
            return np.array(features, dtype=np.float32).reshape(1, -1)
        except Exception as e:
            logger.debug(f"Feature extraction error: {e}")
            return np.zeros((1, 78), dtype=np.float32)
    
    def process_flow(self, flow_dict):
        """معالجة التدفق وتشغيل AI Pipeline"""
        src_ip = flow_dict.get('src_ip', '')
        dst_ip = flow_dict.get('dst_ip', '')
        
        # تجاهل الـ Whitelist
        if src_ip in self.whitelist or dst_ip in self.whitelist:
            return None
            
        # تجاهل Localhost و VMware
        if src_ip.startswith('127.') or dst_ip.startswith('192.168.174.'):
            return None
            
        features = self.extract_78_features(flow_dict)
        
        if self.model_loader and self.model_loader.rf_model:
            try:
                # تطبيق StandardScaler إذا وجد
                if self.model_loader.aegis_scaler:
                    features = self.model_loader.aegis_scaler.transform(features)
                
                prediction = self.model_loader.rf_model.predict(features)[0]
                proba = self.model_loader.rf_model.predict_proba(features)[0]
                confidence = float(max(proba)) * 100
                
                if prediction == 1 and confidence > 60:
                    self.detection_count += 1
                    return {
                        'src_ip': src_ip,
                        'dst_ip': dst_ip,
                        'attack': True,
                        'confidence': confidence,
                        'should_block': confidence > 80
                    }
            except Exception as e:
                logger.error(f"AI Prediction error: {e}")
                
        return None
