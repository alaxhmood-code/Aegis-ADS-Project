﻿"""
core/final_ips_fixed.py - AEGIS-ADS FINAL FIXED IPS
"""

import threading
import asyncio
import logging
import time
import numpy as np
import socket
from datetime import datetime

logger = logging.getLogger(__name__)

# Global State
blocked_ips = {}
blocked_flows = set()
blocked_ips_lock = threading.Lock()
flows = {}
flows_lock = threading.Lock()
device_cache = {}

WHITELIST = {"127.0.0.1", "192.168.137.1", "8.8.8.8", "8.8.4.4", "192.168.43.1"}

packet_count = 0
detection_count = 0
block_count = 0
ai_calls = 0


def get_hostname(ip):
    if ip in device_cache:
        return device_cache[ip]
    try:
        hostname = socket.gethostbyaddr(ip)[0]
        device_cache[ip] = hostname
        return hostname
    except:
        device_cache[ip] = ip
        return ip


class Flow:
    __slots__ = ('src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                 'packets', 'bytes', 'src2dst_packets', 'src2dst_bytes',
                 'dst2src_packets', 'dst2src_bytes', 'syn_count', 'ack_count',
                 'rst_count', 'fin_count', 'first_seen', 'last_seen',
                 'packet_sizes', 'iat_times', 'last_packet_time', 'last_ai_check')
    
    def __init__(self, src_ip, dst_ip, src_port, dst_port, protocol, now):
        self.src_ip = src_ip
        self.dst_ip = dst_ip
        self.src_port = src_port
        self.dst_port = dst_port
        self.protocol = protocol
        self.packets = 1
        self.bytes = 0
        self.src2dst_packets = 0
        self.src2dst_bytes = 0
        self.dst2src_packets = 0
        self.dst2src_bytes = 0
        self.syn_count = 0
        self.ack_count = 0
        self.rst_count = 0
        self.fin_count = 0
        self.first_seen = now
        self.last_seen = now
        self.packet_sizes = []
        self.iat_times = []
        self.last_packet_time = now
        self.last_ai_check = now
    
    def get_duration(self):
        return self.last_seen - self.first_seen
    
    def get_packet_rate(self):
        dur = self.get_duration()
        return self.packets / dur if dur > 0 else 0
    
    def get_byte_rate(self):
        dur = self.get_duration()
        return self.bytes / dur if dur > 0 else 0
    
    def get_avg_packet_size(self):
        return self.bytes / self.packets if self.packets > 0 else 0


def extract_features_78(flow):
    features = []
    features.append(float(flow.src_port))
    features.append(float(flow.dst_port))
    features.append(float(flow.protocol))
    features.append(float(flow.packets))
    features.append(float(flow.bytes))
    features.append(float(flow.src2dst_packets))
    features.append(float(flow.src2dst_bytes))
    features.append(float(flow.dst2src_packets))
    features.append(float(flow.dst2src_bytes))
    features.append(flow.get_duration() * 1000)
    
    if flow.packet_sizes:
        features.append(float(min(flow.packet_sizes)))
        features.append(float(max(flow.packet_sizes)))
        features.append(float(sum(flow.packet_sizes) / len(flow.packet_sizes)))
        if len(flow.packet_sizes) > 1:
            mean = features[-1]
            variance = sum((x - mean) ** 2 for x in flow.packet_sizes) / len(flow.packet_sizes)
            features.append(float(variance ** 0.5))
        else:
            features.append(0.0)
    else:
        features.extend([0.0, 0.0, 0.0, 0.0])
    
    features.append(float(flow.syn_count))
    features.append(float(flow.ack_count))
    features.append(float(flow.rst_count))
    features.append(float(flow.fin_count))
    features.append(float(flow.get_packet_rate()))
    features.append(float(flow.get_byte_rate()))
    
    while len(features) < 78:
        features.append(0.0)
    
    return np.array(features, dtype=np.float32).reshape(1, -1)


def extract_features_10(flow):
    return np.array([[
        float(flow.packets), float(flow.bytes), float(flow.get_duration()),
        float(flow.get_packet_rate()), float(flow.get_byte_rate()),
        float(flow.syn_count), float(flow.ack_count), float(flow.rst_count),
        float(flow.fin_count), float(flow.get_avg_packet_size())
    ]], dtype=np.float32)


class FinalIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self.running = False
        self.main_loop = None
        self.windivert = None
        self.model_loader = None
        self._started = False
    
    def set_loop(self, loop):
        self.main_loop = loop
    
    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected")
    
    def start(self, interface_name=None):
        global packet_count, detection_count, block_count
        
        if self._started:
            return True
        
        try:
            import pydivert
            
            logger.info("=" * 60)
            logger.info("🔥 AEGIS-ADS FINAL IPS FIXED STARTING")
            logger.info("=" * 60)
            
            filter_str = "ip and not loopback and not impostor"
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            self.running = True
            self._started = True
            
            packet_count = 0
            detection_count = 0
            block_count = 0
            
            threading.Thread(target=self._capture_loop, daemon=True).start()
            threading.Thread(target=self._cleanup_loop, daemon=True).start()
            
            logger.warning("🛡️ FINAL IPS ACTIVE - Kernel Level")
            logger.info("=" * 60)
            
            self._broadcast_stats()
            return True
            
        except Exception as e:
            logger.error(f"Start failed: {e}")
            return False
    
    def _capture_loop(self):
        global packet_count
        
        logger.info("📡 Capturing packets...")
        
        for packet in self.windivert:
            if not self.running:
                break
            
            try:
                packet_count += 1
                
                src_ip = packet.src_addr
                dst_ip = packet.dst_addr
                src_port = packet.src_port or 0
                dst_port = packet.dst_port or 0
                packet_size = len(packet.raw)
                
                protocol = 0
                if packet.tcp:
                    protocol = 6
                elif packet.udp:
                    protocol = 17
                elif packet.icmp:
                    protocol = 1
                
                # Check blocked IPs
                with blocked_ips_lock:
                    if src_ip in blocked_ips or dst_ip in blocked_ips:
                        continue
                
                # Flow management
                if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
                    flow_key = (dst_ip, src_ip, dst_port, src_port, protocol)
                    direction = "dst2src"
                else:
                    flow_key = (src_ip, dst_ip, src_port, dst_port, protocol)
                    direction = "src2dst"
                
                if flow_key in blocked_flows:
                    continue
                
                now = time.time()
                
                with flows_lock:
                    if flow_key not in flows:
                        flows[flow_key] = Flow(src_ip, dst_ip, src_port, dst_port, protocol, now)
                    
                    flow = flows[flow_key]
                    flow.last_seen = now
                    flow.packets += 1
                    flow.bytes += packet_size
                    flow.packet_sizes.append(packet_size)
                    
                    if len(flow.packet_sizes) > 100:
                        flow.packet_sizes = flow.packet_sizes[-100:]
                    
                    if flow.last_packet_time > 0:
                        iat = (now - flow.last_packet_time) * 1000
                        flow.iat_times.append(iat)
                    flow.last_packet_time = now
                    
                    if direction == "src2dst":
                        flow.src2dst_packets += 1
                        flow.src2dst_bytes += packet_size
                    else:
                        flow.dst2src_packets += 1
                        flow.dst2src_bytes += packet_size
                    
                    if packet.tcp:
                        if packet.tcp.syn:
                            flow.syn_count += 1
                        if packet.tcp.ack:
                            flow.ack_count += 1
                        if packet.tcp.rst:
                            flow.rst_count += 1
                        if packet.tcp.fin:
                            flow.fin_count += 1
                
                # AI Pipeline every 10 packets
                if flow.packets >= 5 and (now - flow.last_ai_check) > 1.0:
                    with flows_lock:
                        flow.last_ai_check = now
                    self._run_ai_pipeline(flow, flow_key)
                
                # Send packet
                self.windivert.send(packet)
                
                if packet_count % 100 == 0:
                    self._broadcast_stats()
                    
            except Exception as e:
                logger.error(f"Packet error: {e}")
                try:
                    self.windivert.send(packet)
                except:
                    pass
    
    def _run_ai_pipeline(self, flow, flow_key):
        global detection_count, block_count, ai_calls
        
        if not self.model_loader:
            return
        
        try:
            ai_calls += 1
            features_78 = extract_features_78(flow)
            
            # L1 RandomForest
            try:
                result = self.model_loader.predict_l1(features_78)
                if isinstance(result, tuple):
                    is_attack, confidence = result
                else:
                    is_attack = bool(result)
                    confidence = 0.0
            except Exception as e:
                logger.debug(f"L1 error: {e}")
                is_attack = False
            
            if not is_attack:
                return
            
            logger.info(f"[L1] Suspicious: {flow.src_ip}")
            
            # L2 XGBoost
            features_10 = extract_features_10(flow)
            try:
                l2_result = self.model_loader.predict_l2(features_10)
                if isinstance(l2_result, dict):
                    attack_type = l2_result.get('attack_type', 'Unknown')
                    l2_confidence = l2_result.get('confidence', 0)
                else:
                    attack_type = str(l2_result)
                    l2_confidence = 50
            except Exception as e:
                logger.debug(f"L2 error: {e}")
                attack_type = "SUSPICIOUS"
                l2_confidence = 50
            
            if l2_confidence < 50:
                return
            
            logger.warning(f"[L2] Attack: {attack_type} ({l2_confidence:.1f}%)")
            
            # FINAL DECISION - BLOCK
            detection_count += 1
            block_count += 1
            
            with blocked_ips_lock:
                blocked_ips[flow.src_ip] = {
                    "timestamp": time.time(),
                    "attack": attack_type,
                    "confidence": l2_confidence
                }
            
            blocked_flows.add(flow_key)
            
            logger.warning(f"🚨 BLOCKED: {flow.src_ip} - {attack_type}")
            self._broadcast_alert(flow.src_ip, flow.dst_ip, attack_type, l2_confidence)
            self._broadcast_stats()
            
        except Exception as e:
            logger.error(f"AI Pipeline error: {e}")
    
    def _cleanup_loop(self):
        while self.running:
            time.sleep(30)
            now = time.time()
            with flows_lock:
                old_keys = [k for k, f in flows.items() if now - f.last_seen > 60]
                for k in old_keys:
                    del flows[k]
            
            with blocked_ips_lock:
                old_ips = [ip for ip, data in blocked_ips.items() if now - data["timestamp"] > 300]
                for ip in old_ips:
                    del blocked_ips[ip]
    
    def _broadcast_stats(self):
        global packet_count, detection_count, block_count
        
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            data = {
                "type": "stats",
                "packets": packet_count,
                "detections": detection_count,
                "blocks": block_count
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def _broadcast_alert(self, src_ip, dst_ip, attack_type, confidence):
        if not self.main_loop:
            return
        
        try:
            from main import ws_connections
            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "attack_type": attack_type,
                "confidence": confidence,
                "hostname": get_hostname(src_ip)
            }
            
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass
            
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass
    
    def stop(self):
        self.running = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
    
    def block_ip(self, ip, reason="Manual"):
        global block_count, detection_count
        
        if not ip or ip in ["undefined", "-", "None", ""]:
            logger.warning(f"[BLOCK] Invalid IP: {ip}")
            return False
        
        if ip in WHITELIST:
            logger.warning(f"[BLOCK] Cannot block whitelisted IP: {ip}")
            return False
        
        with blocked_ips_lock:
            if ip not in blocked_ips:
                blocked_ips[ip] = {
                    "timestamp": time.time(),
                    "attack": "MANUAL_BLOCK",
                    "confidence": 100
                }
                block_count += 1
                detection_count += 1
                logger.warning(f"✅ [MANUAL BLOCK] {ip}")
                self._broadcast_stats()
                self._broadcast_alert(ip, "manual", "MANUAL_BLOCK", 100)
                return True
        return False
    
    def unblock_ip(self, ip):
        with blocked_ips_lock:
            if ip in blocked_ips:
                del blocked_ips[ip]
                return True
        return False
    
    def get_blocked_ips(self):
        with blocked_ips_lock:
            return list(blocked_ips.keys())
    
    def get_stats(self):
        global packet_count, detection_count, block_count, ai_calls
        with blocked_ips_lock:
            return {
                "total_packets": packet_count,
                "detections": detection_count,
                "blocks": block_count,
                "blocked_ips": len(blocked_ips),
                "active_flows": len(flows),
                "ai_calls": ai_calls,
                "is_running": self.running
            }


def get_ips():
    return FinalIPS()
