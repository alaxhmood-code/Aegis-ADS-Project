﻿"""
core/real_ips.py - AEGIS-ADS Real IPS with NFStream + WinDivert
"""
import threading
import time
import logging
import asyncio
import sys
from datetime import datetime

# تعيين الترميز
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')

logger = logging.getLogger(__name__)

# قائمة الحظر
blacklist = set()
blacklist_lock = threading.Lock()

WHITELIST = {"192.168.137.1", "127.0.0.1", "8.8.8.8", "8.8.4.4"}

class RealIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self.running = False
        self.packet_count = 0
        self.detection_count = 0
        self.block_count = 0
        self.main_loop = None
        self.current_interface = None
        self.nfstreamer = None
        self.windivert = None
        self._started = False

    def set_loop(self, loop):
        self.main_loop = loop

    def set_model_loader(self, model_loader):
        logger.info("✅ AI Models connected to Real IPS")

    def _get_english_interface_name(self, arabic_name):
        """تحويل الاسم العربي إلى الاسم الإنجليزي للواجهة"""
        interface_map = {
            "الاتصال المحلي* 2": "Local Area Connection* 2",
            "شبكة Wi-Fi": "Wi-Fi",
            "اتصال المحلي* 2": "Local Area Connection* 2"
        }
        return interface_map.get(arabic_name, arabic_name)

    def start(self, interface_name=None):
        if self._started:
            return True
        
        if interface_name:
            self.current_interface = interface_name
        
        if not self.current_interface:
            self.current_interface = "Wi-Fi"
        
        # محاولة تحويل الاسم إلى إنجليزي
        english_name = self._get_english_interface_name(self.current_interface)
        
        try:
            self.running = True
            self._started = True
            
            # محاولة استخدام NFStream أولاً
            if self._start_nfstream(english_name):
                logger.warning(f"[REAL IPS] NFStream ACTIVE ON: {self.current_interface}")
            else:
                # الرجوع إلى WinDivert
                self._start_windivert()
            
            return True
        except Exception as e:
            logger.error(f"[IPS] Start failed: {e}")
            return False

    def _start_nfstream(self, interface_name):
        """تشغيل NFStream للالتقاط الحقيقي"""
        try:
            from nfstream import NFStreamer
            
            logger.info(f"Starting NFStream on: {interface_name}")
            
            self.nfstreamer = NFStreamer(
                source=interface_name,
                statistical_analysis=True,
                promiscuous_mode=True,
                idle_timeout=10,
                active_timeout=30,
                n_dissections=20,
                snapshot_length=1500
            )
            
            # تشغيل في خيط منفصل
            threading.Thread(target=self._nfstream_loop, daemon=True).start()
            return True
        except Exception as e:
            logger.error(f"NFStream failed: {e}")
            return False

    def _nfstream_loop(self):
        """حلقة NFStream لمعالجة التدفقات"""
        if not self.nfstreamer:
            return
            
        logger.info("NFStream loop started - waiting for traffic...")
        
        for flow in self.nfstreamer:
            if not self.running:
                break
            
            # تحديث عدد الحزم
            self.packet_count += flow.bidirectional_packets
            
            # تجاهل الحركة المحلية
            if flow.src_ip.startswith('127.') or flow.dst_ip.startswith('127.'):
                continue
            if flow.src_ip.startswith('192.168.174.') or flow.dst_ip.startswith('192.168.174.'):
                continue
            
            # كشف الهجمات
            is_attack = False
            attack_type = ""
            
            # 1. DDoS / Flood Detection
            if flow.bidirectional_packets > 100 and flow.bidirectional_duration_ms < 2000:
                is_attack = True
                attack_type = "DDoS_FLOOD"
            
            # 2. Port Scan Detection
            elif flow.dst_port in [22, 23, 3389, 3306, 1433, 445, 139] and flow.bidirectional_packets < 15:
                is_attack = True
                attack_type = "PORT_SCAN"
            
            # 3. ICMP Flood
            elif flow.protocol == 1 and flow.bidirectional_packets > 50:
                is_attack = True
                attack_type = "ICMP_FLOOD"
            
            # 4. SYN Flood
            elif flow.bidirectional_syn_packets > 50 and flow.bidirectional_packets < 100:
                is_attack = True
                attack_type = "SYN_FLOOD"
            
            if is_attack:
                self.detection_count += 1
                src_ip = flow.src_ip
                
                # حظر IP المخالف
                if src_ip not in WHITELIST and src_ip not in blacklist:
                    with blacklist_lock:
                        blacklist.add(src_ip)
                        self.block_count += 1
                    
                    logger.warning(f"[🚨 {attack_type}] {src_ip} -> {flow.dst_ip}:{flow.dst_port} | Packets: {flow.bidirectional_packets}")
                    self._broadcast_alert(src_ip, flow.dst_ip, attack_type)
            
            # تحديث الواجهة كل 10 تدفقات
            if flow.id % 10 == 0:
                self._broadcast_update()

    def _start_windivert(self):
        """تشغيل WinDivert كبديل"""
        try:
            import pydivert
            
            # فلتر متقدم: تجنب Loopback
            filter_str = "ip and not loopback"
            
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()
            
            threading.Thread(target=self._windivert_loop, daemon=True).start()
            logger.warning(f"[REAL IPS] WinDivert ACTIVE with filter: {filter_str}")
        except Exception as e:
            logger.error(f"WinDivert failed: {e}")

    def _windivert_loop(self):
        """حلقة WinDivert لمعالجة الحزم"""
        if not self.windivert:
            return
            
        logger.info("WinDivert loop started...")
        
        for packet in self.windivert:
            if not self.running:
                break
            
            self.packet_count += 1
            
            # تجاهل Loopback
            if packet.src_addr.startswith('127.') or packet.dst_addr.startswith('127.'):
                self.windivert.send(packet)
                continue
            
            # التحقق من الحظر
            with blacklist_lock:
                if packet.src_addr in blacklist:
                    # إسقاط الحزمة (حظر)
                    continue
                if packet.dst_addr in blacklist:
                    continue
            
            # إعادة إرسال الحزمة
            self.windivert.send(packet)
            
            # تحديث كل 100 حزمة
            if self.packet_count % 100 == 0:
                self._broadcast_update()

    def _broadcast_update(self):
        """بث التحديثات للواجهة"""
        if self.main_loop and self.main_loop.is_running():
            try:
                from main import ws_connections
                data = {
                    "packets": self.packet_count,
                    "detections": self.detection_count,
                    "blocks": self.block_count,
                    "type": "stats"
                }
                
                async def send():
                    for ws in ws_connections[:]:
                        try:
                            await ws.send_json(data)
                        except:
                            if ws in ws_connections:
                                ws_connections.remove(ws)
                
                asyncio.run_coroutine_threadsafe(send(), self.main_loop)
            except Exception as e:
                logger.debug(f"Broadcast error: {e}")

    def _broadcast_alert(self, src_ip, dst_ip, attack_type):
        """بث تنبيه للواجهة"""
        if self.main_loop and self.main_loop.is_running():
            try:
                from main import ws_connections
                alert_data = {
                    "type": "alert",
                    "timestamp": datetime.now().strftime("%H:%M:%S"),
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "attack_type": attack_type,
                    "severity": "HIGH",
                    "confidence": 85
                }
                
                async def send():
                    for ws in ws_connections[:]:
                        try:
                            await ws.send_json(alert_data)
                        except:
                            pass
                
                asyncio.run_coroutine_threadsafe(send(), self.main_loop)
            except:
                pass

    def stop(self):
        self.running = False
        self._started = False
        if self.nfstreamer:
            try:
                self.nfstreamer.close()
            except:
                pass
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("[REAL IPS] Stopped")

    def block_ip(self, ip, reason="Manual"):
        if not ip or ip == "undefined" or ip == "-":
            return False
        if ip in WHITELIST:
            return False
        with blacklist_lock:
            if ip not in blacklist:
                blacklist.add(ip)
                self.block_count += 1
                self.detection_count += 1
                logger.warning(f"[BLOCK] {ip} - {reason}")
                self._broadcast_update()
                return True
        return False

    def unblock_ip(self, ip):
        with blacklist_lock:
            if ip in blacklist:
                blacklist.discard(ip)
                return True
        return False

    def get_blocked_ips(self):
        with blacklist_lock:
            return list(blacklist)

    def get_stats(self):
        with blacklist_lock:
            return {
                "total_packets": self.packet_count,
                "detections": self.detection_count,
                "blocks": self.block_count,
                "blocked_ips": len(blacklist),
                "is_running": self.running,
                "interface": self.current_interface
            }

def get_ips():
    return RealIPS()
