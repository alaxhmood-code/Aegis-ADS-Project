﻿"""
core/final_ips_fixed_v2.py - AEGIS-ADS FINAL IPS V2 - COMPLETE AI PIPELINE
"""

import threading
import asyncio
import logging
import time
import socket
import subprocess
import re
import numpy as np
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)

# Global State
blocked_ips = {}
blocked_ips_lock = threading.Lock()

# Track flows (5-tuple)
flows = {}
flows_lock = threading.Lock()

# ARP cache for device discovery
arp_cache = {}
arp_lock = threading.Lock()

WHITELIST = {"127.0.0.1", "8.8.8.8", "8.8.4.4"}

packet_count = 0
detection_count = 0
block_count = 0
flow_count = 0

# Thresholds for rule-based detection (fallback)
THRESHOLDS = {
    "ICMP_FLOOD": 150,
    "SYN_FLOOD": 100,
    "PORT_SCAN": 20
}


class FinalIPS:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self.running = False
        self.main_loop = None
        self.windivert = None
        self.model_loader = None
        self._started = False
        self.last_stats_time = 0

        # Dynamic subnet
        self.local_subnet = None
        self.local_subnet_prefix = None
        self.interface_ip = None

        # Pipeline state for UI
        self.pipeline_state = {
            "l1": "idle",
            "l2": "idle",
            "l3": "idle"
        }

        # Device tracker
        self.devices = {}

    def set_loop(self, loop):
        self.main_loop = loop
        logger.info("✅ Main loop set for WebSocket")

    def set_model_loader(self, model_loader):
        self.model_loader = model_loader
        logger.info("✅ AI Models connected")

    # ============================================================
    # SUBNET DETECTION
    # ============================================================

    def _get_interface_ip(self, interface_name):
        """Get IP address of a network interface"""
        try:
            import psutil
            for iface, addrs in psutil.net_if_addrs().items():
                if iface == interface_name:
                    for addr in addrs:
                        if addr.family == 2:  # IPv4
                            if not addr.address.startswith('169.254'):
                                return addr.address
                            apipa = addr.address
                    return apipa if 'apipa' in locals() else None
        except Exception as e:
            logger.debug(f"psutil error: {e}")

        # Fallback: ipconfig
        try:
            clean_name = interface_name.encode('ascii', errors='ignore').decode('ascii')
            result = subprocess.run(['ipconfig'], capture_output=True, text=True, encoding='utf-8', errors='ignore')
            lines = result.stdout.split('\n')
            in_target = False
            for line in lines:
                if interface_name in line or clean_name in line:
                    in_target = True
                if in_target and 'IPv4' in line:
                    match = re.search(r'(\d+\.\d+\.\d+\.\d+)', line)
                    if match:
                        ip = match.group(1)
                        if not ip.startswith('169.254'):
                            return ip
                if in_target and line.strip() and not line.startswith(' '):
                    in_target = False
        except Exception as e:
            logger.debug(f"ipconfig error: {e}")

        return None

    def _get_subnet_from_ip(self, ip):
        """Extract subnet prefix from IP"""
        if not ip:
            return None
        parts = ip.split('.')
        if len(parts) >= 3:
            return f"{parts[0]}.{parts[1]}.{parts[2]}."
        return None

    def _update_subnet_from_interface(self, interface_name):
        """Update local subnet based on interface IP"""
        self.interface_ip = self._get_interface_ip(interface_name)
        if self.interface_ip:
            self.local_subnet = self._get_subnet_from_ip(self.interface_ip)
            logger.info(f"📡 Detected interface IP: {self.interface_ip}")
            logger.info(f"📡 Monitoring subnet: {self.local_subnet}x")
            return True
        else:
            self.local_subnet = "192.168."
            logger.warning(f"⚠️ Could not detect IP for {interface_name}, using fallback: {self.local_subnet}x")
            return False

    def _is_local_ip(self, ip):
        """Check if IP belongs to local subnet"""
        if not ip or not self.local_subnet:
            return False
        return ip.startswith(self.local_subnet)

    # ============================================================
    # DEVICE DISCOVERY
    # ============================================================

    def _get_hostname(self, ip):
        try:
            hostname = socket.gethostbyaddr(ip)[0]
            return hostname.split('.')[0]
        except:
            return ip

    def _get_vendor_from_mac(self, mac):
        if not mac or len(mac) < 8:
            return "Unknown"
        oui = mac[:8].upper().replace(':', '').replace('-', '')
        vendors = {
            "7CB37B": "Apple Inc.", "B88A60": "Intel", "98E7F4": "Dell",
            "92A4F5": "HP Inc.", "001A11": "Samsung", "F01898": "Google",
            "508A06": "Huawei", "A4C138": "Xiaomi", "10DCF4": "Nokia",
            "00E04C": "Realtek", "0050C2": "Microsoft", "0022B0": "Asus",
            "00241D": "Acer", "001B24": "Lenovo"
        }
        if oui in vendors:
            return vendors[oui]
        for prefix, vendor in vendors.items():
            clean_prefix = prefix.replace(':', '').replace('-', '')
            if clean_prefix in oui or oui in clean_prefix:
                return vendor
        return "Unknown"

    def _update_arp_cache(self):
        try:
            result = subprocess.run(['arp', '-a'], capture_output=True, text=True, encoding='utf-8', errors='ignore')
            with arp_lock:
                for line in result.stdout.split('\n'):
                    match = re.search(r'(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F:-]+)', line)
                    if match:
                        ip = match.group(1)
                        mac = match.group(2).upper()
                        if self._is_local_ip(ip):
                            arp_cache[ip] = {
                                'mac': mac,
                                'hostname': self._get_hostname(ip),
                                'vendor': self._get_vendor_from_mac(mac),
                                'last_seen': time.time()
                            }
        except Exception as e:
            logger.debug(f"ARP update error: {e}")

    def _broadcast_devices(self):
        if not self.main_loop:
            return
        try:
            from main import ws_connections
            self._update_arp_cache()
            devices = []
            now = time.time()
            with arp_lock:
                for ip, info in arp_cache.items():
                    if now - info.get('last_seen', 0) < 60:
                        devices.append({
                            "ip": ip, "mac": info.get('mac', '-'),
                            "hostname": info.get('hostname', ip),
                            "vendor": info.get('vendor', 'Unknown'),
                            "status": "active"
                        })
            data = {"type": "devices", "devices": devices, "count": len(devices)}
            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        if ws in ws_connections:
                            ws_connections.remove(ws)
            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except Exception as e:
            logger.debug(f"Device broadcast error: {e}")

    # ============================================================
    # FLOW MANAGEMENT
    # ============================================================

    def _get_flow_key(self, src_ip, dst_ip, src_port, dst_port, protocol):
        """Create 5-tuple flow key (bidirectional)"""
        if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
            return (dst_ip, src_ip, dst_port, src_port, protocol)
        return (src_ip, dst_ip, src_port, dst_port, protocol)

    def _update_flow(self, flow_key, packet_size, is_icmp, is_syn):
        """Update flow statistics"""
        with flows_lock:
            if flow_key not in flows:
                flows[flow_key] = {
                    'packets': 0, 'bytes': 0, 'icmp_count': 0,
                    'syn_count': 0, 'first_seen': time.time(), 'last_seen': time.time()
                }
            flow = flows[flow_key]
            flow['packets'] += 1
            flow['bytes'] += packet_size
            flow['last_seen'] = time.time()
            if is_icmp:
                flow['icmp_count'] += 1
            if is_syn:
                flow['syn_count'] += 1
            return flow

    # ============================================================
    # AI PIPELINE
    # ============================================================

    def _run_ai_on_flow(self, src_ip, flow):
        """Run AI detection on flow using XGBoost"""
        if not self.model_loader:
            return None

        try:
            # Update pipeline state for UI
            self.pipeline_state["l1"] = "running"
            self._broadcast_stats()

            # Extract 10 features for XGBoost
            duration = flow['last_seen'] - flow['first_seen']
            packet_rate = flow['packets'] / duration if duration > 0 else 0
            byte_rate = flow['bytes'] / duration if duration > 0 else 0
            avg_packet_size = flow['bytes'] / flow['packets'] if flow['packets'] > 0 else 0

            features = np.array([[
                float(flow['packets']),
                float(flow['bytes']),
                float(duration * 1000),  # duration in ms
                float(packet_rate),
                float(byte_rate),
                float(flow.get('icmp_count', 0)),
                float(flow.get('syn_count', 0)),
                0.0,  # ack_count (placeholder)
                0.0,  # rst_count (placeholder)
                float(avg_packet_size)
            ]], dtype=np.float32)

            # Apply MinMaxScaler if available
            if self.model_loader.minmax_scaler:
                try:
                    features = self.model_loader.minmax_scaler.transform(features)
                except Exception as e:
                    logger.debug(f"Scaler error: {e}")

            self.pipeline_state["l2"] = "running"

            # L2: XGBoost Prediction
            result = self.model_loader.predict_l2(features)

            if isinstance(result, dict):
                attack_type = result.get('attack_type', 'Normal')
                confidence = result.get('confidence', 0)
                is_attack = attack_type.upper() not in ['NORMAL', 'BENIGN'] and confidence > 60
            else:
                is_attack = False
                attack_type = "Unknown"
                confidence = 0

            self.pipeline_state["l3"] = "running" if is_attack else "idle"

            if is_attack:
                logger.info(f"[AI] 🎯 Attack detected: {attack_type} from {src_ip} (confidence: {confidence:.1f}%)")

            # Reset pipeline state
            self.pipeline_state["l1"] = "idle"
            self.pipeline_state["l2"] = "idle"
            if not is_attack:
                self.pipeline_state["l3"] = "idle"

            return {
                'is_attack': is_attack,
                'attack_type': attack_type,
                'confidence': confidence
            }

        except Exception as e:
            logger.debug(f"AI pipeline error: {e}")
            self.pipeline_state["l1"] = "idle"
            self.pipeline_state["l2"] = "idle"
            return None

    # ============================================================
    # CAPTURE LOOP
    # ============================================================

    def start(self, interface_name=None):
        global packet_count, detection_count, block_count, flow_count

        if self._started:
            return True

        try:
            import pydivert

            logger.info("=" * 60)
            logger.info("🔥 AEGIS-ADS FINAL IPS V2 STARTING")
            logger.info("=" * 60)

            if interface_name:
                self._update_subnet_from_interface(interface_name)

            if not self.local_subnet:
                self.local_subnet = "192.168."
                logger.warning(f"⚠️ Using fallback subnet: {self.local_subnet}x")

            filter_str = "ip and not loopback and not impostor"
            self.windivert = pydivert.WinDivert(filter_str)
            self.windivert.open()

            self.running = True
            self._started = True

            packet_count = 0
            detection_count = 0
            block_count = 0
            flow_count = 0

            self.devices = {}
            with flows_lock:
                flows.clear()
            with arp_lock:
                arp_cache.clear()

            # Start threads
            threading.Thread(target=self._capture_loop, daemon=True).start()
            threading.Thread(target=self._stats_broadcast_loop, daemon=True).start()
            threading.Thread(target=self._arp_update_loop, daemon=True).start()

            logger.warning("🛡️ FINAL IPS V2 ACTIVE - Kernel Level")
            logger.info(f"   Interface: {interface_name}")
            logger.info(f"   Interface IP: {self.interface_ip}")
            logger.info(f"   Monitoring subnet: {self.local_subnet}x")
            logger.info("   AI Pipeline: ENABLED")
            logger.info("=" * 60)

            self._broadcast_stats()
            return True

        except Exception as e:
            logger.error(f"Start failed: {e}")
            return False

    def _arp_update_loop(self):
        """Periodically update ARP cache"""
        while self.running:
            time.sleep(10)
            self._update_arp_cache()
            self._broadcast_devices()

    def _stats_broadcast_loop(self):
        """Broadcast stats every second"""
        while self.running:
            time.sleep(1)
            self._broadcast_stats()

    def _capture_loop(self):
        global packet_count, detection_count, block_count, flow_count

        logger.info("📡 Capturing packets - AI Pipeline Active")

        try:
            for packet in self.windivert:
                if not self.running:
                    break

                try:
                    packet_count += 1

                    # Extract packet information
                    src_ip = packet.src_addr if hasattr(packet, 'src_addr') else None
                    dst_ip = packet.dst_addr if hasattr(packet, 'dst_addr') else None
                    src_port = packet.src_port if hasattr(packet, 'src_port') else 0
                    dst_port = packet.dst_port if hasattr(packet, 'dst_port') else 0
                    packet_size = len(packet.raw) if hasattr(packet, 'raw') else 64

                    is_icmp = hasattr(packet, 'icmp') and packet.icmp
                    is_syn = hasattr(packet, 'tcp') and packet.tcp and packet.tcp.syn
                    protocol = 1 if is_icmp else 6 if hasattr(packet, 'tcp') else 17 if hasattr(packet, 'udp') else 0

                    if not src_ip:
                        self.windivert.send(packet)
                        continue

                    # Check if local using dynamic subnet
                    if not self._is_local_ip(src_ip) and not self._is_local_ip(dst_ip):
                        self.windivert.send(packet)
                        continue

                    # Skip gateway
                    if self.interface_ip and src_ip == self.interface_ip:
                        self.windivert.send(packet)
                        continue

                    # Check if already blocked
                    with blocked_ips_lock:
                        if src_ip in blocked_ips:
                            continue

                    # Update flow
                    flow_key = self._get_flow_key(src_ip, dst_ip, src_port, dst_port, protocol)
                    flow = self._update_flow(flow_key, packet_size, is_icmp, is_syn)

                    with flows_lock:
                        flow_count = len(flows)

                    # =================================================
                    # ✅ AI PIPELINE - Every 10 packets per flow
                    # =================================================
                    if flow['packets'] >= 10 and flow['packets'] % 10 == 0:
                        ai_result = self._run_ai_on_flow(src_ip, flow)

                        if ai_result and ai_result.get('is_attack'):
                            detection_count += 1
                            block_count += 1

                            with blocked_ips_lock:
                                blocked_ips[src_ip] = {
                                    "timestamp": time.time(),
                                    "attack": ai_result.get('attack_type', 'UNKNOWN'),
                                    "confidence": ai_result.get('confidence', 0),
                                    "packets": flow['packets'],
                                    "bytes": flow['bytes']
                                }

                            logger.warning(f"🚨 AI BLOCKED: {src_ip} - {ai_result.get('attack_type', 'UNKNOWN')}")
                            logger.warning(f"   Confidence: {ai_result.get('confidence', 0):.1f}%")
                            logger.warning(f"   Packets: {flow['packets']} | Bytes: {flow['bytes']}")

                            self._broadcast_alert(src_ip, dst_ip, ai_result.get('attack_type', 'UNKNOWN'), ai_result.get('confidence', 0))
                            self._broadcast_stats()
                            continue

                    # Allow packet
                    self.windivert.send(packet)

                    # Periodic updates
                    if packet_count % 100 == 0:
                        self._broadcast_devices()
                        self._broadcast_stats()

                except Exception as e:
                    logger.error(f"Packet error: {e}")
                    try:
                        self.windivert.send(packet)
                    except:
                        pass

        except OSError as e:
            if hasattr(e, 'winerror') and e.winerror == 995:
                logger.info("✅ WinDivert stopped normally")
            else:
                logger.error(f"OS Error: {e}")
        except Exception as e:
            logger.error(f"Capture loop error: {e}")

    # ============================================================
    # WEBSOCKET BROADCAST
    # ============================================================

    def _broadcast_stats(self):
        """Broadcast stats to WebSocket clients"""
        global packet_count, detection_count, block_count, flow_count

        if not self.main_loop:
            return

        try:
            from main import ws_connections

            with blocked_ips_lock:
                blocked_list = list(blocked_ips.keys())

            data = {
                "type": "stats",
                "packets": packet_count,
                "detections": detection_count,
                "blocks": block_count,
                "blocked_ips": blocked_list,
                "flows": flow_count,
                "pipeline": self.pipeline_state,
                "subnet": self.local_subnet,
                "interface_ip": self.interface_ip
            }

            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(data)
                    except:
                        if ws in ws_connections:
                            ws_connections.remove(ws)

            asyncio.run_coroutine_threadsafe(send(), self.main_loop)

        except Exception as e:
            logger.debug(f"Broadcast error: {e}")

    def _broadcast_alert(self, src_ip, dst_ip, attack_type, confidence):
        """Broadcast alert to WebSocket clients"""
        if not self.main_loop:
            return

        try:
            from main import ws_connections

            alert = {
                "type": "alert",
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "attack_type": attack_type,
                "confidence": confidence,
                "severity": "CRITICAL"
            }

            async def send():
                for ws in ws_connections[:]:
                    try:
                        await ws.send_json(alert)
                    except:
                        pass

            asyncio.run_coroutine_threadsafe(send(), self.main_loop)
        except:
            pass

    # ============================================================
    # PUBLIC METHODS
    # ============================================================

    def stop(self):
        self.running = False
        if self.windivert:
            try:
                self.windivert.close()
            except:
                pass
        logger.info("🛑 IPS Stopped")

    def block_ip(self, ip, reason="Manual"):
        global block_count, detection_count

        if not ip or ip in ["undefined", "-", "None", ""]:
            return False

        if ip in WHITELIST:
            return False

        if not self._is_local_ip(ip):
            logger.warning(f"[BLOCK] Cannot block non-local IP: {ip}")
            return False

        with blocked_ips_lock:
            if ip not in blocked_ips:
                blocked_ips[ip] = {"timestamp": time.time(), "attack": "MANUAL_BLOCK", "confidence": 100}
                block_count += 1
                detection_count += 1
                logger.warning(f"✅ [MANUAL BLOCK] {ip}")
                self._broadcast_stats()
                self._broadcast_alert(ip, "manual", "MANUAL_BLOCK", 100)
                return True
        return False

    def unblock_ip(self, ip):
        with blocked_ips_lock:
            if ip in blocked_ips:
                del blocked_ips[ip]
                return True
        return False

    def get_blocked_ips(self):
        with blocked_ips_lock:
            return list(blocked_ips.keys())

    def get_stats(self):
        global packet_count, detection_count, block_count, flow_count
        with blocked_ips_lock:
            return {
                "total_packets": packet_count,
                "detections": detection_count,
                "blocks": block_count,
                "blocked_ips": len(blocked_ips),
                "blocked_ips_list": list(blocked_ips.keys()),
                "is_running": self.running,
                "active_flows": flow_count,
                "subnet": self.local_subnet,
                "interface_ip": self.interface_ip,
                "pipeline": self.pipeline_state
            }


def get_ips():
    return FinalIPS()