﻿# core/windivert_manager.py - Fixed with exceptions
import threading
import time
import logging
import subprocess
import sqlite3
import os
from datetime import datetime

logger = logging.getLogger(__name__)

# قائمة العناوين المحظورة
BLOCKED_IPS = set()
BLOCKED_RULES = []
_windivert_thread = None
_running = False

# استثناءات - لا يتم حظر هذه العناوين أبدا
EXEMPT_IPS = {
    "127.0.0.1",           # localhost
    "192.168.8.15",        # جهازك الحالي (Wi-Fi)
    "192.168.137.1",       # Hotspot Gateway
    "8.8.8.8",             # DNS
    "8.8.4.4",             # DNS
    "0.0.0.0",             # Any
}

# رقم واجهة Hotspot (الاتصال المحلي* 2)
HOTSPOT_INTERFACE_INDEX = 14

def init_database():
    """إنشاء قاعدة بيانات لقواعد الحظر"""
    os.makedirs("database", exist_ok=True)
    conn = sqlite3.connect("database/firewall.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS blocked_ips (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip TEXT NOT NULL,
            reason TEXT,
            created_at TEXT,
            blocked_by TEXT,
            kernel_enabled INTEGER DEFAULT 1
        )
    ''')
    conn.commit()
    conn.close()
    logger.info("✅ Firewall database initialized")

def save_blocked_ip(ip, reason, blocked_by="auto"):
    """حفظ IP محظور في قاعدة البيانات"""
    try:
        conn = sqlite3.connect("database/firewall.db")
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO blocked_ips (ip, reason, created_at, blocked_by)
            VALUES (?, ?, ?, ?)
        ''', (ip, reason, datetime.now().isoformat(), blocked_by))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Database error: {e}")
        return False

def delete_blocked_ip(ip):
    """حذف IP من قاعدة البيانات"""
    try:
        conn = sqlite3.connect("database/firewall.db")
        cursor = conn.cursor()
        cursor.execute("DELETE FROM blocked_ips WHERE ip = ?", (ip,))
        conn.commit()
        conn.close()
        return cursor.rowcount > 0
    except Exception as e:
        logger.error(f"Database error: {e}")
        return False

def get_blocked_ips_from_db():
    """جلب قائمة IPs المحظورة من قاعدة البيانات"""
    try:
        conn = sqlite3.connect("database/firewall.db")
        cursor = conn.cursor()
        cursor.execute("SELECT ip, reason, created_at, blocked_by FROM blocked_ips ORDER BY id DESC")
        rows = cursor.fetchall()
        conn.close()
        return [{"ip": r[0], "reason": r[1], "time": r[2], "blocked_by": r[3]} for r in rows]
    except:
        return []

def start_windivert():
    """بدء WinDivert مع فلتر صحيح"""
    global _running, _windivert_thread
    if _running:
        return
    _running = True
    _windivert_thread = threading.Thread(target=_windivert_worker, daemon=True)
    _windivert_thread.start()
    logger.info("✅ WinDivert thread started")

def _windivert_worker():
    """WinDivert worker - حظر الحزم على مستوى النواة مع استثناءات"""
    global _running
    try:
        import pydivert
        
        # فلتر متقدم - يراقب فقط واجهة Hotspot ويتجاهل الاستثناءات
        filter_string = f"outbound and ifIdx == {HOTSPOT_INTERFACE_INDEX}"
        # filter_string = "true"  # بديل إذا لم يعمل الفلتر السابق
        
        with pydivert.WinDivert(filter_string) as w:
            logger.info(f"✅ WinDivert Kernel Filter ACTIVE (filter: {filter_string})")
            
            while _running:
                try:
                    packet = w.recv(timeout=1)
                    
                    # استثناءات - لا تلمس هذه العناوين أبدا
                    if packet.src_addr in EXEMPT_IPS or packet.dst_addr in EXEMPT_IPS:
                        w.send(packet)
                        continue
                    
                    # حظر الحزم من أو إلى العناوين المحظورة
                    if packet.src_addr in BLOCKED_IPS:
                        logger.debug(f"🛡️ WinDivert DROPPED: {packet.src_addr}")
                        continue
                    if packet.dst_addr in BLOCKED_IPS:
                        logger.debug(f"🛡️ WinDivert DROPPED: {packet.dst_addr}")
                        continue
                    
                    # إعادة إرسال الحزم العادية
                    w.send(packet)
                    
                except pydivert.WinDivertException:
                    continue
                except Exception as e:
                    logger.error(f"WinDivert error: {e}")
                    
    except ImportError:
        logger.warning("⚠️ pydivert not installed - using Windows Firewall only")
    except Exception as e:
        logger.error(f"WinDivert init error: {e}")
    finally:
        _running = False

def stop_windivert():
    global _running
    _running = False

def block_ip_windivert(ip: str, reason: str = "Manual", blocked_by: str = "manual") -> dict:
    """حظر IP عبر WinDivert + Windows Firewall + Database"""
    if ip in EXEMPT_IPS:
        return {"status": "skipped", "reason": "IP is exempted", "kernel": False}
    
    if ip in BLOCKED_IPS:
        return {"status": "already_blocked", "kernel": True}
    
    # إضافة إلى قائمة الحظر
    BLOCKED_IPS.add(ip)
    
    # إضافة قاعدة Windows Firewall (Inbound + Outbound)
    rule_name_in = f"AEGIS_BLOCK_IN_{ip.replace('.', '_')}"
    rule_name_out = f"AEGIS_BLOCK_OUT_{ip.replace('.', '_')}"
    
    subprocess.run(f'netsh advfirewall firewall delete rule name="{rule_name_in}"', shell=True, capture_output=True)
    subprocess.run(f'netsh advfirewall firewall delete rule name="{rule_name_out}"', shell=True, capture_output=True)
    
    cmd_in = f'netsh advfirewall firewall add rule name="{rule_name_in}" dir=in action=block remoteip={ip} enable=yes'
    cmd_out = f'netsh advfirewall firewall add rule name="{rule_name_out}" dir=out action=block remoteip={ip} enable=yes'
    
    subprocess.run(cmd_in, shell=True, capture_output=True)
    subprocess.run(cmd_out, shell=True, capture_output=True)
    
    # حفظ في قاعدة البيانات
    save_blocked_ip(ip, reason, blocked_by)
    
    # تسجيل القاعدة
    rule_id = len(BLOCKED_RULES) + 1
    BLOCKED_RULES.append({
        "id": rule_id,
        "name": f"BLOCK_{ip}",
        "source": ip,
        "action": "BLOCK",
        "reason": reason,
        "kernel": True,
        "blocked_by": blocked_by
    })
    
    logger.warning(f"🚫 BLOCKED: {ip} - {reason} (WinDivert + Windows Firewall + DB)")
    return {"status": "blocked", "ip": ip, "kernel": True, "rule_id": rule_id}

def unblock_ip_windivert(ip: str) -> dict:
    """إلغاء حظر IP - حذف من كل المستويات"""
    if ip in BLOCKED_IPS:
        BLOCKED_IPS.remove(ip)
    
    # حذف قواعد Windows Firewall
    rule_name_in = f"AEGIS_BLOCK_IN_{ip.replace('.', '_')}"
    rule_name_out = f"AEGIS_BLOCK_OUT_{ip.replace('.', '_')}"
    subprocess.run(f'netsh advfirewall firewall delete rule name="{rule_name_in}"', shell=True, capture_output=True)
    subprocess.run(f'netsh advfirewall firewall delete rule name="{rule_name_out}"', shell=True, capture_output=True)
    
    # حذف من قاعدة البيانات
    delete_blocked_ip(ip)
    
    # حذف من القائمة
    global BLOCKED_RULES
    BLOCKED_RULES = [r for r in BLOCKED_RULES if r.get("source") != ip]
    
    logger.info(f"🔓 UNBLOCKED: {ip}")
    return {"status": "unblocked", "ip": ip}

def get_blocked_rules():
    """جلب القواعد من الذاكرة وقاعدة البيانات"""
    db_ips = get_blocked_ips_from_db()
    rules = BLOCKED_RULES.copy()
    
    # إضافة IPs من قاعدة البيانات غير الموجودة في الذاكرة
    for db_ip in db_ips:
        if not any(r.get("source") == db_ip["ip"] for r in rules):
            rules.append({
                "id": len(rules) + 1,
                "name": f"BLOCK_{db_ip['ip']}",
                "source": db_ip["ip"],
                "action": "BLOCK",
                "reason": db_ip["reason"],
                "kernel": True,
                "blocked_by": db_ip["blocked_by"],
                "created_at": db_ip["time"]
            })
    
    return rules

def is_blocked(ip: str) -> bool:
    return ip in BLOCKED_IPS

def is_exempt(ip: str) -> bool:
    return ip in EXEMPT_IPS

# تهيئة قاعدة البيانات
init_database()

# بدء التشغيل التلقائي
start_windivert()
