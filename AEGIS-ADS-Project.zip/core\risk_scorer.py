﻿"""
core/risk_scorer.py - Comprehensive Risk Scoring System
"""

import logging

logger = logging.getLogger(__name__)


class RiskScorer:
    """Multi-factor risk scoring for final decision"""
    
    def __init__(self):
        self.weights = {
            'xgb_confidence': 0.35,
            'dl_score': 0.35,
            'behavioral': 0.15,
            'threshold': 0.15
        }
        self.block_threshold = 0.75
        self.monitor_threshold = 0.50
    
    def calculate_risk(self, xgb_result, dl_score, flow_stats, is_manual=False):
        """Calculate comprehensive risk score"""
        if is_manual:
            return {'risk_score': 1.0, 'decision': 'block', 'factors': {'manual': 1.0}}
        
        xgb_confidence = xgb_result.get('confidence', 0) / 100
        xgb_factor = xgb_confidence ** 2
        dl_factor = dl_score ** 2 if dl_score else 0.3
        behavioral_factor = self._calculate_behavioral_factor(flow_stats)
        threshold_factor = self._calculate_threshold_factor(flow_stats)
        
        risk_score = (
            self.weights['xgb_confidence'] * xgb_factor +
            self.weights['dl_score'] * dl_factor +
            self.weights['behavioral'] * behavioral_factor +
            self.weights['threshold'] * threshold_factor
        )
        risk_score = max(0.0, min(1.0, risk_score))
        
        if risk_score >= self.block_threshold:
            decision = 'block'
        elif risk_score >= self.monitor_threshold:
            decision = 'monitor'
        else:
            decision = 'allow'
        
        return {
            'risk_score': risk_score,
            'decision': decision,
            'factors': {
                'xgb': round(xgb_factor, 3),
                'dl': round(dl_factor, 3),
                'behavioral': round(behavioral_factor, 3),
                'threshold': round(threshold_factor, 3)
            }
        }
    
    def _calculate_behavioral_factor(self, flow_stats):
        score = 0.0
        count = 0
        packets = flow_stats.get('packets', 0)
        icmp_count = flow_stats.get('icmp_count', 0)
        syn_count = flow_stats.get('syn_count', 0)
        duration = flow_stats.get('duration_ms', 1) / 1000
        
        if packets > 0:
            icmp_ratio = icmp_count / packets
            if icmp_ratio > 0.5:
                score += min(0.4, icmp_ratio * 0.5)
            count += 1
        
        if packets > 0:
            syn_ratio = syn_count / packets
            if syn_ratio > 0.5:
                score += min(0.4, syn_ratio * 0.5)
            count += 1
        
        if duration > 0:
            packet_rate = packets / duration
            if packet_rate > 50:
                score += min(0.3, packet_rate / 200)
            count += 1
        
        return score / max(count, 1)
    
    def _calculate_threshold_factor(self, flow_stats):
        score = 0.0
        count = 0
        icmp_count = flow_stats.get('icmp_count', 0)
        syn_count = flow_stats.get('syn_count', 0)
        packets = flow_stats.get('packets', 0)
        
        if icmp_count > 15:
            score += min(0.5, (icmp_count - 15) / 100)
            count += 1
        if syn_count > 30:
            score += min(0.5, (syn_count - 30) / 100)
            count += 1
        if packets > 100:
            score += min(0.3, (packets - 100) / 500)
            count += 1
        
        return score / max(count, 1)


def get_risk_scorer():
    """Create RiskScorer instance"""
    return RiskScorer()
