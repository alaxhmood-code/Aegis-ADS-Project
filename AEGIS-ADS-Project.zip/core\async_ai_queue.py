﻿"""
core/async_ai_queue.py - Async Queue with IMMEDIATE blocking
"""

import threading
import queue
import logging
from core.kernel_shield import add_to_blacklist

logger = logging.getLogger(__name__)


class AsyncAIQueue:
    def __init__(self, num_workers=2):
        self.task_queue = queue.Queue(maxsize=1000)
        self.workers = []
        self.num_workers = num_workers
        self.running = False
        self.callback = None
    
    def start(self):
        if self.running:
            return
        self.running = True
        for i in range(self.num_workers):
            worker = threading.Thread(target=self._worker_loop, name=f"AIWorker-{i}", daemon=True)
            worker.start()
            self.workers.append(worker)
        logger.info(f"✅ AI Queue started with {self.num_workers} workers")
    
    def set_callback(self, callback):
        self.callback = callback
    
    def submit(self, task):
        try:
            self.task_queue.put(task, timeout=0.1)
            return True
        except queue.Full:
            logger.warning("AI queue full, dropping task")
            return False
    
    def _worker_loop(self):
        while self.running:
            try:
                task = self.task_queue.get(timeout=0.5)
                if task is None:
                    continue
                
                result = self._process_task(task)
                if self.callback and result:
                    self.callback(result)
                
                self.task_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Worker error: {e}")
    
    def _process_task(self, task):
        try:
            src_ip = task.get('src_ip')
            dst_ip = task.get('dst_ip')
            flow_stats = task.get('flow_stats')
            xgb_detector = task.get('xgb_detector')
            
            if not xgb_detector:
                return None
            
            # Run XGBoost detection
            detection = xgb_detector.detect_from_flow(flow_stats)
            
            # ✅ IMMEDIATE BLOCK - No hesitation
            if detection and detection.get('should_block', False):
                add_to_blacklist(src_ip)
                logger.warning(f"🚨 IMMEDIATE KERNEL BLOCK: {src_ip} - {detection.get('attack_type')} ({detection.get('confidence', 0):.1f}%)")
                return {
                    'src_ip': src_ip,
                    'dst_ip': dst_ip,
                    'detection': detection,
                    'decision': {'action': 'block', 'reason': detection.get('attack_type')}
                }
            return None
        except Exception as e:
            logger.error(f"Task error: {e}")
            return None
    
    def stop(self):
        self.running = False
        for worker in self.workers:
            worker.join(timeout=2)
        logger.info("AI Queue stopped")


_ai_queue = None

def get_ai_queue():
    global _ai_queue
    if _ai_queue is None:
        _ai_queue = AsyncAIQueue(num_workers=2)
    return _ai_queue
