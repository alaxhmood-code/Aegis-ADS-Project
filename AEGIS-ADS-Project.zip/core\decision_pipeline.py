﻿"""
core/decision_pipeline.py - Hierarchical AI Decision Pipeline
L1: RandomForest (Fast Filter)
L2: XGBoost (Attack Classifier)
L3: Deep Learning (Final Decision)
"""

import logging
import numpy as np
from datetime import datetime

logger = logging.getLogger(__name__)


class DecisionPipeline:
    def __init__(self, model_loader, feature_extractor):
        self.model_loader = model_loader
        self.feature_extractor = feature_extractor
        
        # Thresholds
        self.rf_threshold = 0.3      # RF suspicion threshold
        self.xgb_threshold = 65       # XGB confidence for attack
        self.dl_block_threshold = 0.90   # DL block threshold
        self.dl_quarantine_threshold = 0.75  # DL quarantine threshold
        
        # Stats
        self.total_flows = 0
        self.rf_suspicious = 0
        self.xgb_attacks = 0
        self.dl_blocks = 0
        self.dl_quarantines = 0
    
    def _flow_to_text(self, flow, attack_type=None):
        """Convert flow to text for Deep Learning tokenization"""
        src_ip = flow.get('src_ip', '0.0.0.0')
        dst_ip = flow.get('dst_ip', '0.0.0.0')
        packets = flow.get('packets', 0)
        bytes_count = flow.get('bytes', 0)
        duration = flow.get('duration_ms', 0)
        syn = flow.get('syn_count', 0)
        icmp = flow.get('icmp_count', 0)
        attack = attack_type if attack_type else "Unknown"
        
        text = f"SRC={src_ip} DST={dst_ip} PROTO=TCP PACKETS={packets} BYTES={bytes_count} DURATION_MS={duration} SYN={syn} ICMP={icmp} ATTACK={attack}"
        return text
    
    def process_flow(self, flow):
        """
        Process a flow through all three models
        
        Returns:
            dict: {
                'action': 'block'/'quarantine'/'allow',
                'attack_type': str,
                'confidence': float,
                'reason': str
            }
        """
        self.total_flows += 1
        
        # =========================================================
        # L1: RandomForest - Fast Binary Filter
        # =========================================================
        features_78 = self.feature_extractor.extract_from_flow(flow)
        
        if self.model_loader.aegis_scaler:
            features_78 = self.model_loader.aegis_scaler.transform(features_78)
        
        is_suspicious, rf_confidence = self.model_loader.predict_l1(features_78)
        
        if not is_suspicious:
            return {
                'action': 'allow',
                'attack_type': 'Normal',
                'confidence': 100 - rf_confidence,
                'reason': 'L1: Normal traffic'
            }
        
        self.rf_suspicious += 1
        logger.debug(f"[L1] Suspicious flow from {flow.get('src_ip')} (RF: {rf_confidence:.1f}%)")
        
        # =========================================================
        # L2: XGBoost - Attack Type Classification
        # =========================================================
        features_10 = self.feature_extractor.extract_10_features_for_xgb(flow)
        
        if self.model_loader.minmax_scaler:
            features_10 = self.model_loader.minmax_scaler.transform(features_10)
        
        xgb_result = self.model_loader.predict_l2(features_10)
        attack_type = xgb_result.get('attack_type', 'Unknown')
        xgb_confidence = xgb_result.get('confidence', 0)
        
        if xgb_confidence < self.xgb_threshold:
            return {
                'action': 'allow',
                'attack_type': attack_type,
                'confidence': xgb_confidence,
                'reason': f'L2: Low confidence ({xgb_confidence:.1f}%)'
            }
        
        self.xgb_attacks += 1
        logger.info(f"[L2] Attack detected: {attack_type} ({xgb_confidence:.1f}%) from {flow.get('src_ip')}")
        
        # =========================================================
        # L3: Deep Learning - Final Decision
        # =========================================================
        text = self._flow_to_text(flow, attack_type)
        
        dl_result = self._run_deep_learning(text)
        
        if dl_result is None:
            # Fallback to XGBoost decision if DL unavailable
            if xgb_confidence > 80:
                self.dl_blocks += 1
                return {
                    'action': 'block',
                    'attack_type': attack_type,
                    'confidence': xgb_confidence,
                    'reason': f'L2: High confidence attack (DL fallback)'
                }
            else:
                return {
                    'action': 'monitor',
                    'attack_type': attack_type,
                    'confidence': xgb_confidence,
                    'reason': f'L2: Monitoring required'
                }
        
        dl_score = dl_result.get('score', 0.5)
        
        # Final decision based on DL score
        if dl_score >= self.dl_block_threshold:
            self.dl_blocks += 1
            return {
                'action': 'block',
                'attack_type': attack_type,
                'confidence': dl_score * 100,
                'reason': f'L3: Deep Learning block (score: {dl_score:.2f})'
            }
        elif dl_score >= self.dl_quarantine_threshold:
            self.dl_quarantines += 1
            return {
                'action': 'quarantine',
                'attack_type': attack_type,
                'confidence': dl_score * 100,
                'reason': f'L3: Quarantine recommended (score: {dl_score:.2f})'
            }
        else:
            return {
                'action': 'allow',
                'attack_type': attack_type,
                'confidence': (1 - dl_score) * 100,
                'reason': f'L3: Deep Learning allow (score: {dl_score:.2f})'
            }
    
    def _run_deep_learning(self, text):
        """Run Deep Learning inference on text"""
        if not self.model_loader.dl_model:
            return None
        
        try:
            # Simple simulation - in production, use actual transformer
            # This is a placeholder for the DistilBERT model
            import hashlib
            
            # Simulate DL score based on text hash (for testing)
            # Replace with actual model inference
            hash_val = int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
            simulated_score = (hash_val % 100) / 100
            
            return {
                'score': simulated_score,
                'model': 'distilbert',
                'tensors': len(self.model_loader.dl_model) if self.model_loader.dl_model else 0
            }
        except Exception as e:
            logger.debug(f"DL inference error: {e}")
            return None
    
    def get_stats(self):
        return {
            'total_flows': self.total_flows,
            'rf_suspicious': self.rf_suspicious,
            'xgb_attacks': self.xgb_attacks,
            'dl_blocks': self.dl_blocks,
            'dl_quarantines': self.dl_quarantines
        }


def get_decision_pipeline(model_loader, feature_extractor):
    return DecisionPipeline(model_loader, feature_extractor)
