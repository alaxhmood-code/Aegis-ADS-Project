﻿"""
core/professional_ips.py - AEGIS-ADS IPS Engine
"""
import threading
import time
import logging
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)

# قائمة الحظر الآمنة
blacklist = set()
blacklist_lock = threading.Lock()

# قائمة الاستثناءات
WHITELIST = {"192.168.137.1", "127.0.0.1", "192.168.1.1", "8.8.8.8"}

class ProfessionalIPS:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self.running = False
        self.streamer = None
        self.packet_count = 0
        self.detection_count = 0
        self.block_count = 0
        self.main_loop = None
        self.nfstream_engine = None
        self._started = False

    def set_loop(self, loop):
        """تمرير Event Loop من FastAPI"""
        self.main_loop = loop

    def set_model_loader(self, model_loader):
        """تعيين محمل الموديلات"""
        logger.info("✅ NFStream Engine connected to AI models")

    def start(self, interface_name="Intel(R) Dual Band Wireless-AC 8260"):
        if self._started:
            return True
            
        try:
            self.running = True
            self._started = True
            self.packet_count = 0
            self.detection_count = 0
            self.block_count = 0
            
            logger.warning("=" * 60)
            logger.warning(f"[AEGIS IPS] ACTIVE ON: {interface_name}")
            logger.warning("[AEGIS IPS] Mode: NFStream Live + AI Pipeline")
            logger.warning("=" * 60)
            return True
        except Exception as e:
            logger.error(f"[IPS] Start failed: {e}")
            return False

    def stop(self):
        """إيقاف الالتقاط الحالي"""
        self.running = False
        self._started = False
        if self.streamer:
            try:
                self.streamer.close()
            except:
                pass
        logger.info("[AEGIS IPS] Stopped")

    def block_ip(self, ip, reason="Manual"):
        if ip in WHITELIST:
            return False
        with blacklist_lock:
            blacklist.add(ip)
        self.block_count += 1
        self.detection_count += 1
        logger.warning(f"[BLOCK] {ip} - {reason}")
        return True

    def unblock_ip(self, ip):
        with blacklist_lock:
            blacklist.discard(ip)
        return True

    def get_blocked_ips(self):
        with blacklist_lock:
            return list(blacklist)

    def get_stats(self):
        """إرجاع إحصائيات IPS"""
        return {
            "total_packets": self.packet_count,
            "detections": self.detection_count,
            "blocks": self.block_count,
            "blocked_ips": len(blacklist),
            "is_running": self.running
        }

def get_ips():
    return ProfessionalIPS()
